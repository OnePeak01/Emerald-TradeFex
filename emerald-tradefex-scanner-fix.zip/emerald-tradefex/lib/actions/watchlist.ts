"use server";

import { revalidatePath } from "next/cache";
import { createClient, getCurrentUser } from "@/lib/supabase/server";

async function getOrCreateWatchlistId(): Promise<string | null> {
  const user = await getCurrentUser();
  if (!user) return null;

  const supabase = createClient();
  const { data: existing } = await supabase.from("watchlists").select("id").eq("user_id", user.id).limit(1).maybeSingle();

  if (existing) return existing.id;

  const { data: created, error } = await supabase
    .from("watchlists")
    .insert({ user_id: user.id, name: "My Markets" })
    .select("id")
    .single();

  if (error || !created) return null;
  return created.id;
}

export async function addToWatchlist(symbol: string) {
  const watchlistId = await getOrCreateWatchlistId();
  if (!watchlistId) return { error: "Sign in to save a watchlist." };

  const supabase = createClient();
  const { error } = await supabase.from("watchlist_items").upsert(
    { watchlist_id: watchlistId, symbol },
    { onConflict: "watchlist_id,symbol" }
  );

  if (error) return { error: error.message };
  revalidatePath("/dashboard/watchlist");
  return { error: null };
}

export async function removeFromWatchlist(symbol: string) {
  const watchlistId = await getOrCreateWatchlistId();
  if (!watchlistId) return { error: "Sign in to save a watchlist." };

  const supabase = createClient();
  const { error } = await supabase.from("watchlist_items").delete().eq("watchlist_id", watchlistId).eq("symbol", symbol);

  if (error) return { error: error.message };
  revalidatePath("/dashboard/watchlist");
  return { error: null };
}

export async function getWatchlistSymbols(): Promise<string[] | null> {
  const watchlistId = await getOrCreateWatchlistId();
  if (!watchlistId) return null;

  const supabase = createClient();
  const { data } = await supabase.from("watchlist_items").select("symbol").eq("watchlist_id", watchlistId);
  return (data ?? []).map((row) => row.symbol as string);
}
