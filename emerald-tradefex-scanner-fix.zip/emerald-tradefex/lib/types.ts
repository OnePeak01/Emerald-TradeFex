// Core domain types for Emerald TradeFeX.
// These mirror the Supabase schema in supabase/schema.sql and are the
// contract every service provider (mock or live) must satisfy.

export type AssetClass = "forex" | "commodities" | "indices" | "crypto";

export type Timeframe = "1S" | "15S" | "30S" | "1M" | "5M" | "15M" | "30M" | "1H" | "4H" | "12H" | "1D" | "1W";

export type Bias = "BULLISH" | "BEARISH" | "NEUTRAL";

export type RiskLevel = "LOW" | "MODERATE" | "HIGH" | "EXTREME";

export type MarketRegime = "Trending" | "Ranging" | "Volatile" | "Risk-On" | "Risk-Off";

export interface Asset {
  symbol: string; // e.g. "EUR/USD"
  name: string;
  assetClass: AssetClass;
}

export interface Candle {
  time: number; // unix seconds
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface Quote {
  symbol: string;
  price: number;
  changePercent24h: number;
  updatedAt: string;
}

export interface AssetSnapshot {
  asset: Asset;
  quote: Quote;
  bias: Bias;
  confidence: number; // 0-100
  momentum: "Weak" | "Moderate" | "Strong";
  volatility: "Low" | "Medium" | "High";
}

export interface ConfidenceBreakdown {
  technicalStructure: { score: number; max: number };
  momentum: { score: number; max: number };
  marketSentiment: { score: number; max: number };
  volatility: { score: number; max: number };
  macroConditions: { score: number; max: number };
  liquidity: { score: number; max: number };
}

export interface PredictionFactors {
  marketStructure: Bias;
  momentum: "WEAK" | "MODERATE" | "STRONG";
  rsiState: "POSITIVE" | "NEGATIVE" | "NEUTRAL";
  macdState: "BULLISH CROSSOVER" | "BEARISH CROSSOVER" | "NEUTRAL";
  supportStructure: "WEAK" | "MODERATE" | "STRONG";
  sentiment: "POSITIVE" | "NEGATIVE" | "NEUTRAL";
  macro: "POSITIVE" | "NEGATIVE" | "NEUTRAL";
  volatility: "LOW" | "MODERATE" | "HIGH";
}

export interface TradeScenario {
  direction: "LONG BIAS" | "SHORT BIAS" | "NO BIAS";
  entryZone: [number, number];
  target1: number;
  target2: number;
  invalidation: number;
  riskRewardRatio: number;
  confidence: number;
  status: "ACTIVE" | "INVALIDATED" | "TARGET_HIT" | "CLOSED";
}

export interface Prediction {
  id: string;
  symbol: string;
  timeframe: Timeframe;
  createdAt: string;
  currentPrice: number;
  direction: Bias;
  probability: number; // 0-100, probability of stated direction
  forecastHorizon: string; // human readable, e.g. "4 Hours"
  expectedRange: [number, number];
  confidence: number; // 0-100 composite score
  risk: RiskLevel;
  regime: MarketRegime;
  factors: PredictionFactors;
  explanation: string;
  confidenceBreakdown: ConfidenceBreakdown;
  scenario: TradeScenario;
}

export interface PredictionOutcome {
  predictionId: string;
  symbol: string;
  direction: Bias;
  confidence: number;
  resolvedAt: string;
  outcome: "CORRECT" | "INCORRECT" | "PENDING";
}

export interface TrackRecordStats {
  overallAccuracy: number;
  bullishAccuracy: number;
  bearishAccuracy: number;
  averageConfidence: number;
  predictionCount: number;
  simulatedPnlPercent: number;
  maxDrawdownPercent: number;
}

export interface SentimentBreakdown {
  symbol: string;
  bullishPercent: number;
  neutralPercent: number;
  bearishPercent: number;
  technical: Bias;
  news: Bias;
  retail: Bias;
  macro: Bias;
  aiComposite: Bias;
}

export interface EconomicEvent {
  id: string;
  time: string;
  currency: string;
  event: string;
  previous: string;
  forecast: string;
  actual: string | null;
  impact: "LOW" | "MEDIUM" | "HIGH";
  aiImpactNote: string;
}

export interface NewsItem {
  id: string;
  headline: string;
  source: string;
  publishedAt: string;
  affectedAssets: string[];
  sentiment: Bias;
  aiInterpretation: string;
  confidence: number;
}

export interface ScannerResult {
  rank: number;
  symbol: string;
  bias: Bias;
  confidence: number;
  signalType:
    | "Trend Continuation"
    | "Breakout"
    | "Reversal"
    | "Momentum"
    | "Support Bounce"
    | "Resistance Rejection";
}

export interface GlobalMarketState {
  marketsOpen: boolean;
  globalBias: Bias;
  globalConfidence: number;
  regime: MarketRegime;
  volatility: "Low" | "Moderate" | "High";
}
