import { createServerClient, CookieOptions } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";
import { isSupabaseConfigured } from "./config";

type CookieToSet = { name: string; value: string; options: CookieOptions };

export async function updateSession(request: NextRequest) {
  let response = NextResponse.next({ request });

  // No Supabase project connected yet (see .env.example) — let every
  // request through unauthenticated rather than crashing the whole site.
  if (!isSupabaseConfigured()) {
    return { response, user: null };
  }

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet: CookieToSet[]) {
          cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
          response = NextResponse.next({ request });
          cookiesToSet.forEach(({ name, value, options }) => response.cookies.set(name, value, options));
        }
      }
    }
  );

  // Touching getUser() is what actually refreshes the session token. This is
  // a network call to the Supabase Auth server, so it can fail for reasons
  // that have nothing to do with whether the user is logged in (timeout,
  // DNS hiccup, Supabase project paused/cold, transient 5xx). Treat any such
  // failure as "we couldn't confirm a session" rather than crashing the
  // middleware for every /dashboard request — the dashboard route itself
  // will fall back to the logged-out view rather than 500.
  let user = null;
  try {
    const {
      data: { user: fetchedUser }
    } = await supabase.auth.getUser();
    user = fetchedUser;
  } catch (error) {
    console.error("[middleware] Supabase getUser() failed, treating as logged out:", error);
  }

  return { response, user };
}
