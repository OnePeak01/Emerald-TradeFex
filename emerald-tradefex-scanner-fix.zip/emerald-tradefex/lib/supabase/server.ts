import { createServerClient, CookieOptions } from "@supabase/ssr";
import { cookies } from "next/headers";
import { isSupabaseConfigured } from "./config";

type CookieToSet = { name: string; value: string; options: CookieOptions };

// Server-only. Never import this file from a "use client" component.
// Uses the public anon key + the user's session cookie, so RLS still
// applies — this is NOT the service-role client.
export function createClient() {
  const cookieStore = cookies();

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet: CookieToSet[]) {
          try {
            cookiesToSet.forEach(({ name, value, options }) => cookieStore.set(name, value, options));
          } catch {
            // Called from a Server Component with no writable cookie store —
            // safe to ignore if you have middleware refreshing sessions.
          }
        }
      }
    }
  );
}

// Service-role client for privileged server-only operations (e.g. writing
// resolved prediction outcomes from a cron job). NEVER import this from
// anything that ships to the client, and never read SUPABASE_SERVICE_ROLE_KEY
// outside of a server file.
export function createServiceRoleClient() {
  const { createClient: createSupabaseClient } = require("@supabase/supabase-js");
  return createSupabaseClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
  );
}

// Safe to call from any Server Component. Returns null instead of throwing
// when no Supabase project is connected yet, so the app keeps working as a
// demo (see .env.example) until real auth is wired up. Also returns null
// (rather than throwing) if the call to Supabase itself fails — this runs
// in dashboard/layout.tsx on every fresh render of the dashboard shell, so
// an unhandled rejection here previously took down every /dashboard/* page
// with a generic server-side "Application error" whenever Supabase was
// briefly unreachable, timed out, or returned an unexpected response.
export async function getCurrentUser() {
  if (!isSupabaseConfigured()) return null;
  try {
    const supabase = createClient();
    const {
      data: { user }
    } = await supabase.auth.getUser();
    return user;
  } catch (error) {
    console.error("[getCurrentUser] Supabase getUser() failed, falling back to logged-out view:", error);
    return null;
  }
}
