import { computeTrackRecordStats, getPredictionOutcomes } from "./mock/mockAncillaryData";

/**
 * TrackRecordService
 * ------------------
 * getOutcomes() should read from the `prediction_outcomes` Supabase table
 * in production (see supabase/schema.sql) — every prediction the app ever
 * shows a user should be persisted there when it resolves. computeStats()
 * is provider-agnostic and works identically over mock or real rows, so
 * accuracy numbers are always calculated, never hardcoded.
 */
export const TrackRecordService = {
  getOutcomes() {
    return getPredictionOutcomes();
  },
  computeStats(outcomes = getPredictionOutcomes()) {
    return computeTrackRecordStats(outcomes);
  }
};
