import { AssetSnapshot, Candle, Quote, Timeframe } from "@/lib/types";
import { ASSET_UNIVERSE } from "./mock/assetUniverse";
import { generateCandles, getAllSnapshots, getAssetSnapshot, getQuote } from "./mock/mockMarketData";

/**
 * MarketDataService
 * ------------------
 * Every UI component reads market data through this module — never
 * directly from lib/services/mock. Today NEXT_PUBLIC_DATA_MODE is always
 * "mock" (or unset), so the mock provider below runs. To connect a real
 * feed (e.g. a broker API, Polygon, Twelve Data):
 *
 *   1. Implement the same function signatures against the live API in a
 *      new file, e.g. lib/services/live/liveMarketData.ts.
 *   2. Do the request server-side (API route or Server Component) so the
 *      provider's API key never reaches the client.
 *   3. Swap the branch below from "mock" to call your new module.
 *
 * No other file in the app needs to change.
 */

const DATA_MODE = process.env.NEXT_PUBLIC_DATA_MODE ?? "mock";

export const MarketDataService = {
  listAssets() {
    return ASSET_UNIVERSE.map(({ symbol, name, assetClass }) => ({ symbol, name, assetClass }));
  },

  getQuote(symbol: string): Quote {
    if (DATA_MODE === "live") {
      throw new Error("Live market data provider not yet configured. Set NEXT_PUBLIC_DATA_MODE=mock or implement lib/services/live/liveMarketData.ts");
    }
    return getQuote(symbol);
  },

  getSnapshot(symbol: string): AssetSnapshot | null {
    if (DATA_MODE === "live") {
      throw new Error("Live market data provider not yet configured.");
    }
    return getAssetSnapshot(symbol);
  },

  getAllSnapshots(): AssetSnapshot[] {
    if (DATA_MODE === "live") {
      throw new Error("Live market data provider not yet configured.");
    }
    return getAllSnapshots();
  },

  getCandles(symbol: string, timeframe: Timeframe, count?: number): Candle[] {
    if (DATA_MODE === "live") {
      throw new Error("Live market data provider not yet configured.");
    }
    return generateCandles(symbol, timeframe, count);
  }
};
