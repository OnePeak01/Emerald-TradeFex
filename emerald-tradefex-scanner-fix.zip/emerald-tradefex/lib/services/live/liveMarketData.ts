import "server-only";
import { ASSET_UNIVERSE } from "@/lib/services/mock/assetUniverse";

/**
 * Live market data via Twelve Data (https://twelvedata.com). Server-only —
 * MARKET_DATA_API_KEY must never reach the client (see .env.example).
 *
 * Twelve Data's free tier covers forex and crypto reliably. Commodities and
 * indices vary by plan, so every symbol is fetched in one batched request
 * and anything the provider can't serve (missing key, rate limit, invalid
 * symbol, plan restriction) is reported as unavailable per-symbol rather
 * than failing the whole request — callers fall back to the mock generator
 * for just that symbol. See MarketDataService.getLiveSnapshots().
 */

// Our display symbol -> the ticker Twelve Data expects, where they differ.
const LIVE_SYMBOL_MAP: Record<string, string> = {
  NASDAQ: "IXIC",
  "S&P 500": "GSPC",
  "DOW JONES": "DJI",
  "RUSSELL 2000": "RUT",
  "FTSE 100": "FTSE",
  DAX: "GDAXI",
  "CAC 40": "FCHI",
  "NIKKEI 225": "N225",
  "HANG SENG": "HSI",
  "ASX 200": "AXJO",
  WTI: "WTI/USD",
  BRENT: "BRENT/USD"
};

export interface LiveQuote {
  symbol: string; // our display symbol
  price: number;
  changePercent: number;
}

function toLiveSymbol(displaySymbol: string) {
  return LIVE_SYMBOL_MAP[displaySymbol] ?? displaySymbol;
}

function fromLiveSymbol(liveSymbol: string) {
  const entry = Object.entries(LIVE_SYMBOL_MAP).find(([, v]) => v === liveSymbol);
  return entry ? entry[0] : liveSymbol;
}

export async function fetchLiveQuotes(displaySymbols: string[]): Promise<Map<string, LiveQuote>> {
  const result = new Map<string, LiveQuote>();
  const apiKey = process.env.MARKET_DATA_API_KEY;
  if (!apiKey || displaySymbols.length === 0) return result;

  const liveSymbols = displaySymbols.map(toLiveSymbol);
  const url = `https://api.twelvedata.com/quote?symbol=${encodeURIComponent(liveSymbols.join(","))}&apikey=${apiKey}`;

  try {
    const res = await fetch(url, { cache: "no-store", signal: AbortSignal.timeout(6000) });
    if (!res.ok) return result;
    const data = await res.json();

    // Twelve Data returns a single object when one symbol was requested,
    // or an object keyed by symbol when multiple were requested.
    const entries: [string, any][] =
      liveSymbols.length === 1 ? [[liveSymbols[0], data]] : Object.entries(data ?? {});

    for (const [liveSymbol, quote] of entries) {
      if (!quote || quote.status === "error" || quote.code) continue;
      const price = Number(quote.close ?? quote.price);
      const changePercent = Number(quote.percent_change);
      if (!Number.isFinite(price)) continue;

      const displaySymbol = fromLiveSymbol(liveSymbol);
      result.set(displaySymbol, {
        symbol: displaySymbol,
        price,
        changePercent: Number.isFinite(changePercent) ? changePercent : 0
      });
    }
  } catch {
    // Network error, timeout, or rate limit — return whatever we have
    // (nothing), callers fall back to mock data for every symbol.
  }

  return result;
}

export async function fetchAllLiveQuotes(): Promise<Map<string, LiveQuote>> {
  return fetchLiveQuotes(ASSET_UNIVERSE.map((a) => a.symbol));
}
