import "server-only";
import { NewsService } from "@/lib/services/newsService";
import { SentimentService } from "@/lib/services/sentimentService";
import { Prediction } from "@/lib/types";

/**
 * Live AI Market Chat — wires the chat widget to a real Gemini model instead
 * of the deterministic template in AiMarketChat's local `answer()` fallback.
 *
 * Server-only: GEMINI_API_KEY must never reach the client. This is called
 * exclusively from app/api/ai/chat/route.ts.
 *
 * Requires:
 *   GEMINI_API_KEY        — get one free at https://aistudio.google.com/app/apikey
 *   GEMINI_MODEL           — optional, defaults to "gemini-flash-latest" (rolling
 *                            alias that always points to Google's current Flash
 *                            model — avoids hardcoding a version that gets
 *                            retired later, e.g. 2.5-flash → 3.6-flash → ...)
 *   GEMINI_MODEL_DEEP      — optional, defaults to "gemini-pro-latest" (same
 *                            idea, rolling alias for the Pro line)
 *
 * Hybrid model routing: most questions go to Flash (fast, generous free
 * quota). Questions that ask for deeper reasoning — "why", "explain",
 * "compare", "deep dive", conflicting-signal questions — are escalated to
 * Pro, which reasons more carefully but has a much smaller free daily quota
 * (~25 req/day at time of writing), so it's used sparingly by design.
 */

export type ChatTurn = { role: "user" | "assistant"; text: string };

const GEMINI_URL_BASE = "https://generativelanguage.googleapis.com/v1beta/models";
const DEFAULT_FLASH_MODEL = "gemini-flash-latest";
const DEFAULT_PRO_MODEL = "gemini-pro-latest";

// Heuristic for escalating to the deeper (and much more quota-limited) Pro
// model. Kept intentionally narrow so the free Pro quota isn't burned on
// routine questions like "what's my stop loss".
const DEEP_REASONING_PATTERN = /\bwhy\b|\bexplain\b|\bcompare\b|deep dive|conflict|trade-?off|reasoning/i;

export function isLiveAiChatConfigured(): boolean {
  return Boolean(process.env.GEMINI_API_KEY);
}

function buildSystemPrompt(prediction: Prediction): string {
  const { symbol } = prediction;
  const sentiment = SentimentService.getSentiment(symbol);
  const news = NewsService.getFeed()
    .filter((n) => n.affectedAssets.includes(symbol))
    .slice(0, 5);

  const newsBlock = news.length
    ? news.map((n) => `- [${n.sentiment}] ${n.headline} (${n.source}, ${n.publishedAt})`).join("\n")
    : "No recent headlines flagged for this symbol.";

  return `You are the AI Market Chat assistant embedded in Emerald TradeFeX, a forex/CFD forecasting dashboard.

You are analyzing ${symbol} on the ${prediction.timeframe} timeframe. Ground every answer in the data below — this is
the SAME forecast already rendered on the page the user is looking at, so numbers must match it exactly. Do not invent
prices, percentages, or indicators that are not in this context or standard technical/macro reasoning.

CURRENT PREDICTION SNAPSHOT
- Current price: ${prediction.currentPrice}
- Direction / bias: ${prediction.direction} (${prediction.probability}% probability)
- Market regime: ${prediction.regime}
- Forecast horizon: ${prediction.forecastHorizon}
- Expected range: ${prediction.expectedRange[0]} – ${prediction.expectedRange[1]}
- Composite confidence: ${prediction.confidence}/100
- Risk level: ${prediction.risk}
- Factors: structure=${prediction.factors.marketStructure}, momentum=${prediction.factors.momentum}, RSI=${prediction.factors.rsiState}, MACD=${prediction.factors.macdState}, support=${prediction.factors.supportStructure}, sentiment=${prediction.factors.sentiment}, macro=${prediction.factors.macro}, volatility=${prediction.factors.volatility}
- Model's own explanation: ${prediction.explanation}

TRADE SCENARIO
- Scenario direction: ${prediction.scenario.direction}
- Entry zone: ${prediction.scenario.entryZone[0]} – ${prediction.scenario.entryZone[1]}
- Stop loss (invalidation): ${prediction.scenario.invalidation}
- Take profit 1: ${prediction.scenario.target1}
- Take profit 2: ${prediction.scenario.target2}
- Risk/reward: 1:${prediction.scenario.riskRewardRatio}
- Scenario confidence: ${prediction.scenario.confidence}
- Status: ${prediction.scenario.status}

SENTIMENT BREAKDOWN
- Bullish/Neutral/Bearish split: ${sentiment.bullishPercent}% / ${sentiment.neutralPercent}% / ${sentiment.bearishPercent}%
- Technical: ${sentiment.technical}, News: ${sentiment.news}, Retail: ${sentiment.retail}, Macro: ${sentiment.macro}, AI composite: ${sentiment.aiComposite}

RECENT HEADLINES
${newsBlock}

HOW TO ANSWER
- Be direct and specific — cite the actual numbers above rather than vague hedging.
- You may reason about how these factors interact (e.g. momentum vs. macro conflict, why R:R favors one side) — this is
  genuine analysis, not just a lookup, so explain trade-offs and what would invalidate the view.
- Never claim certainty about future price action. Every response implicitly carries "this is a model-generated view,
  not guaranteed" — you don't need to repeat that disclaimer every single message, but don't state outcomes as fact.
- Keep answers tight: 2-5 sentences unless the user asks for a deeper breakdown.
- If asked something totally unrelated to markets/trading, gently redirect back to what you can help with.`;
}

function pickModel(latestUserMessage: string): string {
  const deep = DEEP_REASONING_PATTERN.test(latestUserMessage);
  return deep ? process.env.GEMINI_MODEL_DEEP || DEFAULT_PRO_MODEL : process.env.GEMINI_MODEL || DEFAULT_FLASH_MODEL;
}

export async function askLiveAiChat(prediction: Prediction, history: ChatTurn[]): Promise<string> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is not set");
  }

  const latestUserMessage = [...history].reverse().find((t) => t.role === "user")?.text ?? "";
  const model = pickModel(latestUserMessage);

  const response = await fetch(`${GEMINI_URL_BASE}/${model}:generateContent?key=${apiKey}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: buildSystemPrompt(prediction) }] },
      contents: history.map((turn) => ({
        role: turn.role === "assistant" ? "model" : "user",
        parts: [{ text: turn.text }]
      })),
      generationConfig: { maxOutputTokens: 500 }
    })
  });

  if (!response.ok) {
    const detail = await response.text().catch(() => "");
    throw new Error(`Gemini API error ${response.status}: ${detail.slice(0, 300)}`);
  }

  const data = await response.json();
  const text = (data.candidates?.[0]?.content?.parts ?? [])
    .map((part: { text?: string }) => part.text ?? "")
    .join("\n")
    .trim();

  if (!text) {
    throw new Error("Gemini API returned no text content");
  }

  return text;
}

