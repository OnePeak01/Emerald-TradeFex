import { getAlerts } from "./mock/mockAncillaryData";

/**
 * AlertService — in production, getRecent() reads the `alerts` table
 * filtered to auth.uid() via RLS (see supabase/schema.sql). Today it
 * returns a shared deterministic feed so the notifications UI has
 * something real to render before per-user alerts are wired up.
 */
export const AlertService = {
  getRecent() {
    return getAlerts();
  }
};
