import { getSentiment } from "./mock/mockAncillaryData";

export const SentimentService = {
  getSentiment(symbol: string) {
    return getSentiment(symbol);
  }
};
