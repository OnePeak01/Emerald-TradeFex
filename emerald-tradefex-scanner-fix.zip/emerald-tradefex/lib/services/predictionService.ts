import { GlobalMarketState, Prediction, Timeframe } from "@/lib/types";
import { generateMultiTimeframe, generatePrediction } from "./mock/mockPredictionProvider";
import { getAllSnapshots } from "./mock/mockMarketData";

/**
 * PredictionService
 * ------------------
 * The single entry point the UI uses to obtain AI forecasts. The mock
 * provider (lib/services/mock/mockPredictionProvider.ts) generates
 * deterministic, factor-driven predictions so the demo is stable and the
 * "why" explanation always matches the displayed scores.
 *
 * To connect a real model: implement generatePrediction/generateMultiTimeframe
 * against your model endpoint in lib/services/live/livePredictionProvider.ts
 * (server-side only — call it from a Next.js API route or Server Action so
 * model credentials stay off the client), then swap the calls below.
 */

export const PredictionService = {
  getPrediction(symbol: string, timeframe: Timeframe): Prediction | null {
    return generatePrediction(symbol, timeframe);
  },

  getMultiTimeframeConsensus(symbol: string) {
    return generateMultiTimeframe(symbol);
  },

  getGlobalMarketState(): GlobalMarketState {
    const snapshots = getAllSnapshots();
    const bullish = snapshots.filter((s) => s.bias === "BULLISH").length;
    const bearish = snapshots.filter((s) => s.bias === "BEARISH").length;
    const avgConfidence = Math.round(snapshots.reduce((s, x) => s + x.confidence, 0) / snapshots.length);

    return {
      marketsOpen: true,
      globalBias: bullish > bearish ? "BULLISH" : bearish > bullish ? "BEARISH" : "NEUTRAL",
      globalConfidence: avgConfidence,
      regime: bullish > bearish ? "Risk-On" : bearish > bullish ? "Risk-Off" : "Ranging",
      volatility: avgConfidence > 75 ? "High" : avgConfidence > 60 ? "Moderate" : "Low"
    };
  }
};
