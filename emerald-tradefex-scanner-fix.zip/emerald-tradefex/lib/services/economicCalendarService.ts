import { getEconomicCalendar } from "./mock/mockAncillaryData";

export const EconomicCalendarService = {
  getUpcomingEvents() {
    return getEconomicCalendar();
  }
};
