import { seededRandom } from "./mock/seededRandom";

export interface BacktestParams {
  symbol: string;
  strategy: string;
  timeframe: string;
  startingCapital: number;
}

export interface BacktestResult {
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  winRate: number;
  profitFactor: number;
  netReturnPercent: number;
  maxDrawdownPercent: number;
  averageRR: number;
  sharpeRatio: number;
  equityCurve: number[];
}

/**
 * BacktestService — runs against the mock AI Momentum strategy today.
 * A real deployment replaces runBacktest's internals with an actual
 * strategy engine over stored `candles` rows, keeping this signature.
 */
export const BacktestService = {
  runBacktest(params: BacktestParams): BacktestResult {
    const rand = seededRandom(`${params.symbol}:${params.strategy}:${params.timeframe}`);
    const totalTrades = 40 + Math.floor(rand() * 60);
    let equity = params.startingCapital;
    let peak = equity;
    let maxDrawdown = 0;
    const equityCurve: number[] = [equity];
    let wins = 0;

    for (let i = 0; i < totalTrades; i++) {
      const isWin = rand() < 0.56;
      if (isWin) wins++;
      const move = isWin ? rand() * 0.025 : -rand() * 0.014;
      equity *= 1 + move;
      peak = Math.max(peak, equity);
      maxDrawdown = Math.max(maxDrawdown, (peak - equity) / peak);
      equityCurve.push(Math.round(equity));
    }

    const losses = totalTrades - wins;
    const winRate = Math.round((wins / totalTrades) * 1000) / 10;
    const netReturnPercent = Math.round(((equity - params.startingCapital) / params.startingCapital) * 1000) / 10;

    return {
      totalTrades,
      winningTrades: wins,
      losingTrades: losses,
      winRate,
      profitFactor: Number((1.1 + rand() * 0.9).toFixed(2)),
      netReturnPercent,
      maxDrawdownPercent: Math.round(maxDrawdown * 1000) / 10,
      averageRR: Number((1.5 + rand() * 1.2).toFixed(1)),
      sharpeRatio: Number((0.8 + rand() * 1.1).toFixed(2)),
      equityCurve
    };
  }
};
