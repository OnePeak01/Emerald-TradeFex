import {
  Bias,
  EconomicEvent,
  NewsItem,
  PredictionOutcome,
  ScannerResult,
  SentimentBreakdown,
  TrackRecordStats
} from "@/lib/types";
import { seededRandom } from "./seededRandom";
import { ASSET_UNIVERSE } from "./assetUniverse";
import { getAssetSnapshot } from "./mockMarketData";

const daySalt = () => new Date().toISOString().slice(0, 10);

export function getSentiment(symbol: string): SentimentBreakdown {
  const rand = seededRandom(`${symbol}:sentiment:${daySalt()}`);
  const bullish = Math.round(30 + rand() * 55);
  const bearish = Math.round(rand() * (100 - bullish));
  const neutral = 100 - bullish - bearish;

  const pick = (): Bias => {
    const r = rand();
    return r > 0.6 ? "BULLISH" : r > 0.3 ? "NEUTRAL" : "BEARISH";
  };

  const composite: Bias = bullish > bearish && bullish > neutral ? "BULLISH" : bearish > bullish ? "BEARISH" : "NEUTRAL";

  return {
    symbol,
    bullishPercent: bullish,
    neutralPercent: Math.max(neutral, 0),
    bearishPercent: bearish,
    technical: pick(),
    news: pick(),
    retail: pick(),
    macro: pick(),
    aiComposite: composite
  };
}

const NEWS_TEMPLATES: { headline: string; source: string; assets: string[] }[] = [
  { headline: "ECB maintains restrictive policy stance", source: "Reuters", assets: ["EUR/USD"] },
  { headline: "US labor market data comes in stronger than forecast", source: "Bloomberg", assets: ["USD/JPY", "EUR/USD"] },
  { headline: "Gold demand rises as investors seek safe havens", source: "Financial Times", assets: ["XAU/USD"] },
  { headline: "Bank of Japan signals patience on rate normalization", source: "Nikkei", assets: ["USD/JPY"] },
  { headline: "OPEC+ output decision keeps crude in tight range", source: "Reuters", assets: ["WTI"] },
  { headline: "Tech earnings lift risk appetite across equity indices", source: "CNBC", assets: ["NASDAQ", "S&P 500"] },
  { headline: "UK inflation print surprises to the downside", source: "Bloomberg", assets: ["GBP/USD"] },
  { headline: "Crypto markets digest regulatory clarity in major economies", source: "CoinDesk", assets: ["BTC/USD", "ETH/USD"] }
];

export function getNewsFeed(): NewsItem[] {
  const rand = seededRandom(`news:${daySalt()}`);
  return NEWS_TEMPLATES.map((tpl, i) => {
    const sentimentRoll = rand();
    const sentiment: Bias = sentimentRoll > 0.6 ? "BULLISH" : sentimentRoll > 0.3 ? "NEUTRAL" : "BEARISH";
    const confidence = Math.round(55 + rand() * 35);
    const hoursAgo = Math.round(rand() * 10) + i;
    return {
      id: `news-${i}`,
      headline: tpl.headline,
      source: tpl.source,
      publishedAt: new Date(Date.now() - hoursAgo * 3600_000).toISOString(),
      affectedAssets: tpl.assets,
      sentiment,
      aiInterpretation: `Potential ${sentiment.toLowerCase()} pressure on ${tpl.assets.join(", ")} as markets price in the implications of this development.`,
      confidence
    };
  });
}

const EVENT_TEMPLATES: { currency: string; event: string; impact: EconomicEvent["impact"] }[] = [
  { currency: "USD", event: "CPI Inflation (YoY)", impact: "HIGH" },
  { currency: "USD", event: "Non-Farm Payrolls", impact: "HIGH" },
  { currency: "EUR", event: "ECB Interest Rate Decision", impact: "HIGH" },
  { currency: "GBP", event: "GDP Growth Rate (QoQ)", impact: "MEDIUM" },
  { currency: "JPY", event: "BoJ Policy Statement", impact: "MEDIUM" },
  { currency: "USD", event: "Retail Sales (MoM)", impact: "MEDIUM" },
  { currency: "AUD", event: "Employment Change", impact: "LOW" },
  { currency: "CAD", event: "Ivey PMI", impact: "LOW" }
];

export function getEconomicCalendar(): EconomicEvent[] {
  const rand = seededRandom(`calendar:${daySalt()}`);
  return EVENT_TEMPLATES.map((tpl, i) => {
    const prevVal = (rand() * 4).toFixed(1);
    const forecastVal = (Number(prevVal) + (rand() - 0.5)).toFixed(1);
    const hasActual = i < 2;
    const impactDirection = rand() > 0.5 ? "strengthen" : "weaken";
    const pairedCurrency = tpl.currency === "USD" ? "EUR/USD" : `${tpl.currency}/USD`;

    return {
      id: `event-${i}`,
      time: new Date(Date.now() + (i - 2) * 3600_000).toISOString(),
      currency: tpl.currency,
      event: tpl.event,
      previous: `${prevVal}%`,
      forecast: `${forecastVal}%`,
      actual: hasActual ? `${(Number(forecastVal) + (rand() - 0.5) * 0.3).toFixed(1)}%` : null,
      impact: tpl.impact,
      aiImpactNote: `An upside surprise may ${impactDirection} ${tpl.currency} and place short-term pressure on ${pairedCurrency}.`
    };
  });
}

const SIGNAL_TYPES: ScannerResult["signalType"][] = [
  "Trend Continuation",
  "Breakout",
  "Reversal",
  "Momentum",
  "Support Bounce",
  "Resistance Rejection"
];

export function getScannerResults(): ScannerResult[] {
  const rand = seededRandom(`scanner:${daySalt()}`);
  const results = ASSET_UNIVERSE.map((asset) => {
    const snapshot = getAssetSnapshot(asset.symbol)!;
    return {
      symbol: asset.symbol,
      bias: snapshot.bias,
      confidence: snapshot.confidence,
      signalType: SIGNAL_TYPES[Math.floor(rand() * SIGNAL_TYPES.length)]
    };
  });

  return results
    .filter((r) => r.bias !== "NEUTRAL")
    .sort((a, b) => b.confidence - a.confidence)
    .map((r, i) => ({ rank: i + 1, ...r }));
}

// Alerts: mirrors the shape of a row in the `alerts` table (see
// supabase/schema.sql). In production this becomes a query scoped to
// auth.uid() via RLS; here it's a deterministic feed shared by all visitors.
export interface AlertItem {
  id: string;
  symbol: string;
  alertType: "CONFIDENCE_CHANGE" | "TREND_CHANGE" | "BREAKOUT" | "PREDICTION_INVALIDATED" | "ECONOMIC_EVENT";
  message: string;
  createdAt: string;
}

const ALERT_TEMPLATES: (symbol: string) => Omit<AlertItem, "id" | "createdAt">[] = (symbol) => [
  { symbol, alertType: "CONFIDENCE_CHANGE", message: `${symbol} confidence increased to 86%.` },
  { symbol, alertType: "BREAKOUT", message: `${symbol} breakout detected.` },
  { symbol, alertType: "TREND_CHANGE", message: `${symbol} changed from Neutral → Bullish.` },
  { symbol, alertType: "ECONOMIC_EVENT", message: `High-impact event affecting ${symbol} in 30 minutes.` }
];

export function getAlerts(): AlertItem[] {
  const rand = seededRandom(`alerts:${daySalt()}`);
  const symbols = ["EUR/USD", "XAU/USD", "GBP/USD", "BTC/USD", "USD/JPY"];
  const alerts: AlertItem[] = [];

  symbols.forEach((symbol, si) => {
    const templates = ALERT_TEMPLATES(symbol);
    const template = templates[Math.floor(rand() * templates.length)];
    alerts.push({
      ...template,
      id: `alert-${si}`,
      createdAt: new Date(Date.now() - (si + 1) * 40 * 60_000).toISOString()
    });
  });

  return alerts.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
}
// below are always CALCULATED from stored rows, never hardcoded. A live
// deployment replaces this generator with a real read from the
// `predictions` + `prediction_outcomes` Supabase tables.
export function getPredictionOutcomes(): PredictionOutcome[] {
  const rand = seededRandom(`track-record:${daySalt()}`);
  const outcomes: PredictionOutcome[] = [];
  const symbols = ASSET_UNIVERSE.map((a) => a.symbol);

  for (let i = 0; i < 60; i++) {
    const symbol = symbols[Math.floor(rand() * symbols.length)];
    const direction: Bias = rand() > 0.5 ? "BULLISH" : "BEARISH";
    const confidence = Math.round(55 + rand() * 40);
    // Higher confidence predictions are modestly more likely to be correct —
    // this is what makes the accuracy stat meaningful rather than arbitrary.
    const correctProbability = 0.45 + (confidence / 100) * 0.35;
    const outcome = rand() < correctProbability ? "CORRECT" : "INCORRECT";
    outcomes.push({
      predictionId: `hist-${i}`,
      symbol,
      direction,
      confidence,
      resolvedAt: new Date(Date.now() - i * 6 * 3600_000).toISOString(),
      outcome
    });
  }
  return outcomes;
}

export function computeTrackRecordStats(outcomes: PredictionOutcome[]): TrackRecordStats {
  if (outcomes.length === 0) {
    return {
      overallAccuracy: 0,
      bullishAccuracy: 0,
      bearishAccuracy: 0,
      averageConfidence: 0,
      predictionCount: 0,
      simulatedPnlPercent: 0,
      maxDrawdownPercent: 0
    };
  }

  const accuracyOf = (rows: PredictionOutcome[]) =>
    rows.length === 0 ? 0 : Math.round((rows.filter((r) => r.outcome === "CORRECT").length / rows.length) * 1000) / 10;

  const bullish = outcomes.filter((o) => o.direction === "BULLISH");
  const bearish = outcomes.filter((o) => o.direction === "BEARISH");
  const averageConfidence = Math.round((outcomes.reduce((s, o) => s + o.confidence, 0) / outcomes.length) * 10) / 10;

  // Simple equity simulation: correct predictions earn a return proportional
  // to confidence, incorrect predictions lose a fixed unit risk.
  let equity = 100;
  let peak = 100;
  let maxDrawdown = 0;
  // Oldest first for a sensible equity curve.
  [...outcomes].reverse().forEach((o) => {
    const win = o.outcome === "CORRECT";
    const move = win ? o.confidence / 100 / 2.7 : -1 / 2.7;
    equity *= 1 + move * 0.02;
    peak = Math.max(peak, equity);
    maxDrawdown = Math.max(maxDrawdown, (peak - equity) / peak);
  });

  return {
    overallAccuracy: accuracyOf(outcomes),
    bullishAccuracy: accuracyOf(bullish),
    bearishAccuracy: accuracyOf(bearish),
    averageConfidence,
    predictionCount: outcomes.length,
    simulatedPnlPercent: Math.round((equity - 100) * 10) / 10,
    maxDrawdownPercent: Math.round(maxDrawdown * 1000) / 10
  };
}
