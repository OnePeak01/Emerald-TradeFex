import { Asset } from "@/lib/types";

// Reference basis for mock price generation. Not live prices — swap the
// live MarketDataService provider (lib/services/marketDataService.ts) for
// a real feed and this file becomes unused.
export const ASSET_UNIVERSE: (Asset & { basePrice: number; decimals: number })[] = [
  // --- Forex majors ---
  { symbol: "EUR/USD", name: "Euro / US Dollar", assetClass: "forex", basePrice: 1.1748, decimals: 5 },
  { symbol: "GBP/USD", name: "British Pound / US Dollar", assetClass: "forex", basePrice: 1.3412, decimals: 5 },
  { symbol: "USD/JPY", name: "US Dollar / Japanese Yen", assetClass: "forex", basePrice: 147.32, decimals: 3 },
  { symbol: "USD/CHF", name: "US Dollar / Swiss Franc", assetClass: "forex", basePrice: 0.8021, decimals: 5 },
  { symbol: "AUD/USD", name: "Australian Dollar / US Dollar", assetClass: "forex", basePrice: 0.6634, decimals: 5 },
  { symbol: "USD/CAD", name: "US Dollar / Canadian Dollar", assetClass: "forex", basePrice: 1.3789, decimals: 5 },
  { symbol: "NZD/USD", name: "New Zealand Dollar / US Dollar", assetClass: "forex", basePrice: 0.6012, decimals: 5 },
  // --- Forex crosses & majors-adjacent ---
  { symbol: "EUR/GBP", name: "Euro / British Pound", assetClass: "forex", basePrice: 0.876, decimals: 5 },
  { symbol: "EUR/JPY", name: "Euro / Japanese Yen", assetClass: "forex", basePrice: 173.1, decimals: 3 },
  { symbol: "GBP/JPY", name: "British Pound / Japanese Yen", assetClass: "forex", basePrice: 197.6, decimals: 3 },
  { symbol: "EUR/CHF", name: "Euro / Swiss Franc", assetClass: "forex", basePrice: 0.9425, decimals: 5 },
  { symbol: "AUD/JPY", name: "Australian Dollar / Japanese Yen", assetClass: "forex", basePrice: 97.75, decimals: 3 },
  { symbol: "NZD/JPY", name: "New Zealand Dollar / Japanese Yen", assetClass: "forex", basePrice: 88.6, decimals: 3 },
  { symbol: "EUR/AUD", name: "Euro / Australian Dollar", assetClass: "forex", basePrice: 1.771, decimals: 5 },
  { symbol: "GBP/AUD", name: "British Pound / Australian Dollar", assetClass: "forex", basePrice: 2.022, decimals: 5 },
  { symbol: "EUR/CAD", name: "Euro / Canadian Dollar", assetClass: "forex", basePrice: 1.62, decimals: 5 },
  { symbol: "GBP/CHF", name: "British Pound / Swiss Franc", assetClass: "forex", basePrice: 1.076, decimals: 5 },
  // --- Forex, broader / exotic ---
  { symbol: "USD/SGD", name: "US Dollar / Singapore Dollar", assetClass: "forex", basePrice: 1.312, decimals: 5 },
  { symbol: "USD/HKD", name: "US Dollar / Hong Kong Dollar", assetClass: "forex", basePrice: 7.81, decimals: 4 },
  { symbol: "USD/MXN", name: "US Dollar / Mexican Peso", assetClass: "forex", basePrice: 18.45, decimals: 4 },
  { symbol: "USD/ZAR", name: "US Dollar / South African Rand", assetClass: "forex", basePrice: 17.85, decimals: 4 },
  { symbol: "USD/TRY", name: "US Dollar / Turkish Lira", assetClass: "forex", basePrice: 34.2, decimals: 4 },

  // --- Commodities: metals ---
  { symbol: "XAU/USD", name: "Gold Spot", assetClass: "commodities", basePrice: 2478.5, decimals: 2 },
  { symbol: "XAG/USD", name: "Silver Spot", assetClass: "commodities", basePrice: 29.42, decimals: 3 },
  { symbol: "XPT/USD", name: "Platinum Spot", assetClass: "commodities", basePrice: 985.5, decimals: 2 },
  { symbol: "XPD/USD", name: "Palladium Spot", assetClass: "commodities", basePrice: 1020, decimals: 2 },
  { symbol: "COPPER", name: "Copper Futures", assetClass: "commodities", basePrice: 4.35, decimals: 3 },
  // --- Commodities: energy ---
  { symbol: "WTI", name: "WTI Crude Oil", assetClass: "commodities", basePrice: 71.85, decimals: 2 },
  { symbol: "BRENT", name: "Brent Crude Oil", assetClass: "commodities", basePrice: 75.4, decimals: 2 },
  { symbol: "NATGAS", name: "Natural Gas", assetClass: "commodities", basePrice: 2.85, decimals: 3 },

  // --- Indices ---
  { symbol: "NASDAQ", name: "Nasdaq 100", assetClass: "indices", basePrice: 19845, decimals: 1 },
  { symbol: "S&P 500", name: "S&P 500", assetClass: "indices", basePrice: 5632, decimals: 1 },
  { symbol: "DOW JONES", name: "Dow Jones Industrial Average", assetClass: "indices", basePrice: 41250, decimals: 0 },
  { symbol: "RUSSELL 2000", name: "Russell 2000", assetClass: "indices", basePrice: 2150, decimals: 1 },
  { symbol: "FTSE 100", name: "FTSE 100 (UK)", assetClass: "indices", basePrice: 8150, decimals: 1 },
  { symbol: "DAX", name: "DAX 40 (Germany)", assetClass: "indices", basePrice: 18700, decimals: 1 },
  { symbol: "CAC 40", name: "CAC 40 (France)", assetClass: "indices", basePrice: 7550, decimals: 1 },
  { symbol: "NIKKEI 225", name: "Nikkei 225 (Japan)", assetClass: "indices", basePrice: 38900, decimals: 0 },
  { symbol: "HANG SENG", name: "Hang Seng (Hong Kong)", assetClass: "indices", basePrice: 17600, decimals: 0 },
  { symbol: "ASX 200", name: "S&P/ASX 200 (Australia)", assetClass: "indices", basePrice: 8050, decimals: 1 },

  // --- Crypto ---
  { symbol: "BTC/USD", name: "Bitcoin", assetClass: "crypto", basePrice: 62340, decimals: 0 },
  { symbol: "ETH/USD", name: "Ethereum", assetClass: "crypto", basePrice: 2612, decimals: 1 },
  { symbol: "SOL/USD", name: "Solana", assetClass: "crypto", basePrice: 145.2, decimals: 2 },
  { symbol: "BNB/USD", name: "BNB", assetClass: "crypto", basePrice: 570, decimals: 1 },
  { symbol: "XRP/USD", name: "XRP", assetClass: "crypto", basePrice: 0.62, decimals: 4 },
  { symbol: "ADA/USD", name: "Cardano", assetClass: "crypto", basePrice: 0.45, decimals: 4 },
  { symbol: "DOGE/USD", name: "Dogecoin", assetClass: "crypto", basePrice: 0.14, decimals: 4 },
  { symbol: "AVAX/USD", name: "Avalanche", assetClass: "crypto", basePrice: 28.5, decimals: 2 },
  { symbol: "DOT/USD", name: "Polkadot", assetClass: "crypto", basePrice: 6.2, decimals: 3 },
  { symbol: "LINK/USD", name: "Chainlink", assetClass: "crypto", basePrice: 13.8, decimals: 2 },
  { symbol: "LTC/USD", name: "Litecoin", assetClass: "crypto", basePrice: 68.4, decimals: 2 },
  { symbol: "MATIC/USD", name: "Polygon", assetClass: "crypto", basePrice: 0.55, decimals: 4 },
  { symbol: "TON/USD", name: "Toncoin", assetClass: "crypto", basePrice: 5.4, decimals: 3 },
  { symbol: "UNI/USD", name: "Uniswap", assetClass: "crypto", basePrice: 8.2, decimals: 2 },
  { symbol: "ATOM/USD", name: "Cosmos", assetClass: "crypto", basePrice: 5.6, decimals: 3 },
  { symbol: "TRX/USD", name: "TRON", assetClass: "crypto", basePrice: 0.16, decimals: 4 },
  { symbol: "SHIB/USD", name: "Shiba Inu", assetClass: "crypto", basePrice: 0.0000185, decimals: 8 }
];

export function findAsset(symbol: string) {
  return ASSET_UNIVERSE.find((a) => a.symbol === symbol);
}
