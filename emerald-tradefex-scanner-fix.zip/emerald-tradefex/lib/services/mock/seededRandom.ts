// Deterministic PRNG (mulberry32) seeded from a string.
// Using real Math.random() in mock services would make server-rendered
// output differ from client re-renders and trigger hydration errors —
// every mock provider in this app derives its "randomness" from a seed
// tied to the query (symbol + timeframe + day) instead.

export function hashStringToSeed(input: string): number {
  let h = 1779033703 ^ input.length;
  for (let i = 0; i < input.length; i++) {
    h = Math.imul(h ^ input.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  return h >>> 0;
}

export function mulberry32(seed: number) {
  let a = seed;
  return function random() {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function seededRandom(seed: string) {
  return mulberry32(hashStringToSeed(seed));
}
