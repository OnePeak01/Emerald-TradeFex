import {
  Bias,
  ConfidenceBreakdown,
  MarketRegime,
  Prediction,
  PredictionFactors,
  RiskLevel,
  Timeframe,
  TradeScenario
} from "@/lib/types";
import { seededRandom } from "./seededRandom";
import { findAsset } from "./assetUniverse";
import { generateCandles } from "./mockMarketData";

const HORIZON_LABEL: Record<Timeframe, string> = {
  "1S": "15 Seconds",
  "15S": "1 Minute",
  "30S": "2 Minutes",
  "1M": "5 Minutes",
  "5M": "30 Minutes",
  "15M": "1 Hour",
  "30M": "2 Hours",
  "1H": "4 Hours",
  "4H": "12 Hours",
  "12H": "1 Day",
  "1D": "3 Days",
  "1W": "2 Weeks"
};

/**
 * Builds prediction factors from a rand() stream. In a real deployment
 * this function is replaced by an actual model call — everything downstream
 * (explanation, confidence, scenario) is derived FROM these factors so the
 * narrative always matches the numbers, whether they come from mock data
 * or a live model.
 */
function buildFactors(rand: () => number): { factors: PredictionFactors; leanScore: number } {
  const structureRoll = rand();
  const marketStructure: Bias = structureRoll > 0.55 ? "BULLISH" : structureRoll > 0.25 ? "NEUTRAL" : "BEARISH";

  const momentumRoll = rand();
  const momentum: PredictionFactors["momentum"] =
    momentumRoll > 0.66 ? "STRONG" : momentumRoll > 0.33 ? "MODERATE" : "WEAK";

  const rsiRoll = rand();
  const rsiState: PredictionFactors["rsiState"] =
    rsiRoll > 0.6 ? "POSITIVE" : rsiRoll > 0.3 ? "NEUTRAL" : "NEGATIVE";

  const macdRoll = rand();
  const macdState: PredictionFactors["macdState"] =
    macdRoll > 0.55 ? "BULLISH CROSSOVER" : macdRoll > 0.3 ? "NEUTRAL" : "BEARISH CROSSOVER";

  const supportRoll = rand();
  const supportStructure: PredictionFactors["supportStructure"] =
    supportRoll > 0.6 ? "STRONG" : supportRoll > 0.3 ? "MODERATE" : "WEAK";

  const sentimentRoll = rand();
  const sentiment: PredictionFactors["sentiment"] =
    sentimentRoll > 0.55 ? "POSITIVE" : sentimentRoll > 0.3 ? "NEUTRAL" : "NEGATIVE";

  const macroRoll = rand();
  const macro: PredictionFactors["macro"] =
    macroRoll > 0.6 ? "POSITIVE" : macroRoll > 0.3 ? "NEUTRAL" : "NEGATIVE";

  const volRoll = rand();
  const volatility: PredictionFactors["volatility"] = volRoll > 0.66 ? "HIGH" : volRoll > 0.33 ? "MODERATE" : "LOW";

  // Weighted lean: positive => bullish, negative => bearish.
  const weights: number[] = [
    marketStructure === "BULLISH" ? 1 : marketStructure === "BEARISH" ? -1 : 0,
    momentum === "STRONG" ? 1 : momentum === "WEAK" ? -0.5 : 0.2,
    rsiState === "POSITIVE" ? 0.6 : rsiState === "NEGATIVE" ? -0.6 : 0,
    macdState === "BULLISH CROSSOVER" ? 0.8 : macdState === "BEARISH CROSSOVER" ? -0.8 : 0,
    supportStructure === "STRONG" ? 0.4 : supportStructure === "WEAK" ? -0.3 : 0,
    sentiment === "POSITIVE" ? 0.5 : sentiment === "NEGATIVE" ? -0.5 : 0,
    macro === "POSITIVE" ? 0.3 : macro === "NEGATIVE" ? -0.3 : 0
  ];
  const leanScore = weights.reduce((a, b) => a + b, 0);

  return {
    factors: { marketStructure, momentum, rsiState, macdState, supportStructure, sentiment, macro, volatility },
    leanScore
  };
}

function buildConfidenceBreakdown(factors: PredictionFactors, rand: () => number): ConfidenceBreakdown {
  const structurePts = factors.marketStructure !== "NEUTRAL" ? 22 + rand() * 8 : 12 + rand() * 8;
  const momentumPts = factors.momentum === "STRONG" ? 15 + rand() * 5 : factors.momentum === "MODERATE" ? 10 + rand() * 5 : 5 + rand() * 5;
  const sentimentPts = factors.sentiment === "NEUTRAL" ? 8 + rand() * 6 : 13 + rand() * 7;
  const volatilityPts = factors.volatility === "MODERATE" ? 7 + rand() * 3 : 4 + rand() * 4;
  const macroPts = factors.macro === "NEUTRAL" ? 4 + rand() * 3 : 6 + rand() * 4;
  const liquidityPts = 5 + rand() * 5;

  return {
    technicalStructure: { score: Math.round(structurePts), max: 30 },
    momentum: { score: Math.round(momentumPts), max: 20 },
    marketSentiment: { score: Math.round(sentimentPts), max: 20 },
    volatility: { score: Math.round(volatilityPts), max: 10 },
    macroConditions: { score: Math.round(macroPts), max: 10 },
    liquidity: { score: Math.round(liquidityPts), max: 10 }
  };
}

function composeExplanation(symbol: string, direction: Bias, factors: PredictionFactors): string {
  if (direction === "NEUTRAL") {
    return `${symbol} is trading without a clear directional edge. Market structure and momentum are mixed, and the model prefers to wait for confirmation rather than assign a directional bias.`;
  }

  const structureClause =
    direction === "BULLISH"
      ? "showing a strengthening bullish structure"
      : "showing a weakening structure with bearish pressure building";

  const momentumClause =
    factors.momentum === "STRONG"
      ? "Momentum remains firmly positioned in the direction of the move"
      : factors.momentum === "MODERATE"
      ? "Momentum is moderately aligned with the move"
      : "Momentum is still tentative and not yet fully confirming the move";

  const structureLevelClause =
    direction === "BULLISH"
      ? factors.supportStructure === "STRONG"
        ? "while price is holding above a key support zone"
        : "although the supporting structure below price is not yet firmly established"
      : factors.supportStructure === "STRONG"
      ? "even though a nearby support zone may slow the decline"
      : "with limited support below to arrest the move";

  const macroClause =
    factors.macro === "NEUTRAL"
      ? "upcoming economic data introduces additional volatility"
      : factors.macro === "POSITIVE"
      ? "the broader macro backdrop is reinforcing the move"
      : "the broader macro backdrop is working against the move";

  const pressureClause =
    direction === "BULLISH" ? "increasing upside pressure" : "increasing downside pressure";

  return `${symbol} is ${structureClause}. ${momentumClause}, ${structureLevelClause}. The model detects ${pressureClause}, and ${macroClause}.`;
}

function buildScenario(
  direction: Bias,
  currentPrice: number,
  expectedRange: [number, number],
  confidence: number,
  decimals: number
): TradeScenario {
  const round = (n: number) => Number(n.toFixed(decimals));

  if (direction === "NEUTRAL") {
    return {
      direction: "NO BIAS",
      entryZone: [round(currentPrice * 0.998), round(currentPrice * 1.002)],
      target1: round(currentPrice),
      target2: round(currentPrice),
      invalidation: round(currentPrice),
      riskRewardRatio: 0,
      confidence,
      status: "CLOSED"
    };
  }

  const isBullish = direction === "BULLISH";
  const entryZone: [number, number] = isBullish
    ? [round(currentPrice * 0.9985), round(currentPrice * 0.9998)]
    : [round(currentPrice * 1.0002), round(currentPrice * 1.0015)];

  const target1 = round(expectedRange[isBullish ? 0 : 1]);
  const spread = Math.abs(expectedRange[1] - expectedRange[0]);
  const target2 = round(isBullish ? expectedRange[1] + spread * 0.6 : expectedRange[0] - spread * 0.6);
  const invalidation = round(isBullish ? currentPrice * 0.997 : currentPrice * 1.003);

  const risk = Math.abs(currentPrice - invalidation);
  const reward = Math.abs(target2 - currentPrice);
  const riskRewardRatio = risk > 0 ? Number((reward / risk).toFixed(1)) : 0;

  return {
    direction: isBullish ? "LONG BIAS" : "SHORT BIAS",
    entryZone,
    target1,
    target2,
    invalidation,
    riskRewardRatio,
    confidence,
    status: "ACTIVE"
  };
}

export function generatePrediction(symbol: string, timeframe: Timeframe): Prediction | null {
  const asset = findAsset(symbol);
  if (!asset) return null;

  const daySalt = new Date().toISOString().slice(0, 10);
  const rand = seededRandom(`${symbol}:${timeframe}:predict:${daySalt}`);

  const candles = generateCandles(symbol, timeframe, 40);
  const currentPrice = candles[candles.length - 1]?.close ?? asset.basePrice;

  const { factors, leanScore } = buildFactors(rand);
  const direction: Bias = leanScore > 0.6 ? "BULLISH" : leanScore < -0.6 ? "BEARISH" : "NEUTRAL";

  const probability = Math.max(52, Math.min(96, Math.round(62 + leanScore * 9 + rand() * 6)));
  const confidenceBreakdown = buildConfidenceBreakdown(factors, rand);
  const confidence = Object.values(confidenceBreakdown).reduce((sum, v) => sum + v.score, 0);

  const rangeSpreadPct = asset.assetClass === "crypto" ? 0.02 : 0.006;
  const rangeSpread = currentPrice * rangeSpreadPct * (0.7 + rand() * 0.6);
  const expectedRange: [number, number] =
    direction === "BEARISH"
      ? [Number((currentPrice - rangeSpread).toFixed(asset.decimals)), Number((currentPrice - rangeSpread * 0.15).toFixed(asset.decimals))]
      : [Number((currentPrice + rangeSpread * 0.15).toFixed(asset.decimals)), Number((currentPrice + rangeSpread).toFixed(asset.decimals))];

  const risk: RiskLevel =
    factors.volatility === "HIGH" ? "HIGH" : factors.volatility === "MODERATE" ? "MODERATE" : "LOW";

  const regime: MarketRegime =
    factors.momentum === "STRONG" ? "Trending" : factors.volatility === "HIGH" ? "Volatile" : "Ranging";

  return {
    id: `${symbol}-${timeframe}-${daySalt}`,
    symbol,
    timeframe,
    createdAt: new Date().toISOString(),
    currentPrice,
    direction,
    probability: direction === "NEUTRAL" ? 50 : probability,
    forecastHorizon: HORIZON_LABEL[timeframe],
    expectedRange,
    confidence,
    risk,
    regime,
    factors,
    explanation: composeExplanation(symbol, direction, factors),
    confidenceBreakdown,
    scenario: buildScenario(direction, currentPrice, expectedRange, confidence, asset.decimals)
  };
}

export function generateMultiTimeframe(symbol: string): Record<Timeframe, Bias> {
  const tfs: Timeframe[] = ["5M", "15M", "1H", "4H", "1D"];
  const result: Partial<Record<Timeframe, Bias>> = {};
  tfs.forEach((tf) => {
    result[tf] = generatePrediction(symbol, tf)?.direction ?? "NEUTRAL";
  });
  return result as Record<Timeframe, Bias>;
}
