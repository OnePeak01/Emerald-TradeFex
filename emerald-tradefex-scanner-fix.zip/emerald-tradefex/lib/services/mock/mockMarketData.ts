import { AssetSnapshot, Bias, Candle, Quote, Timeframe } from "@/lib/types";
import { seededRandom } from "./seededRandom";
import { ASSET_UNIVERSE, findAsset } from "./assetUniverse";

export const TIMEFRAME_SECONDS: Record<Timeframe, number> = {
  "1S": 1,
  "15S": 15,
  "30S": 30,
  "1M": 60,
  "5M": 300,
  "15M": 900,
  "30M": 1800,
  "1H": 3600,
  "4H": 14400,
  "12H": 43200,
  "1D": 86400,
  "1W": 604800
};

// Same-day seed so prices are stable across a render cycle but still feel
// "live" day to day. A real provider replaces this file entirely.
function daySalt() {
  return new Date().toISOString().slice(0, 10);
}

export function generateCandles(symbol: string, timeframe: Timeframe, count = 180): Candle[] {
  const asset = findAsset(symbol);
  if (!asset) return [];

  const rand = seededRandom(`${symbol}:${timeframe}:${daySalt()}`);
  const stepSeconds = TIMEFRAME_SECONDS[timeframe];
  const volatility = asset.basePrice * (asset.assetClass === "crypto" ? 0.012 : 0.0018);

  let price = asset.basePrice * (0.985 + rand() * 0.03);
  const now = Math.floor(Date.now() / 1000);
  const candles: Candle[] = [];

  // Gentle random walk with mild drift so charts feel like real structure
  // rather than pure noise.
  let drift = (rand() - 0.5) * 0.0006;

  for (let i = count; i >= 0; i--) {
    const time = now - i * stepSeconds;
    const open = price;
    if (i % 24 === 0) drift = (rand() - 0.5) * 0.0006;
    const change = (rand() - 0.5) * volatility * 2 + drift * asset.basePrice;
    const close = Math.max(open + change, asset.basePrice * 0.5);
    const high = Math.max(open, close) + rand() * volatility * 0.6;
    const low = Math.min(open, close) - rand() * volatility * 0.6;
    const volume = Math.round(1000 + rand() * 9000);
    candles.push({ time, open, high, low, close, volume });
    price = close;
  }

  return candles;
}

export function getQuote(symbol: string): Quote {
  const candles = generateCandles(symbol, "1H", 24);
  const last = candles[candles.length - 1];
  const first = candles[0];
  const changePercent24h = first ? ((last.close - first.open) / first.open) * 100 : 0;

  return {
    symbol,
    price: last?.close ?? findAsset(symbol)?.basePrice ?? 0,
    changePercent24h,
    updatedAt: new Date().toISOString()
  };
}

function biasFromDrift(changePercent: number): Bias {
  if (changePercent > 0.15) return "BULLISH";
  if (changePercent < -0.15) return "BEARISH";
  return "NEUTRAL";
}

export function getAssetSnapshot(symbol: string): AssetSnapshot | null {
  const asset = findAsset(symbol);
  if (!asset) return null;
  const quote = getQuote(symbol);
  const rand = seededRandom(`${symbol}:snapshot:${daySalt()}`);
  const bias = biasFromDrift(quote.changePercent24h);
  const confidence = Math.round(58 + rand() * 37);
  const momentum = confidence > 80 ? "Strong" : confidence > 65 ? "Moderate" : "Weak";
  const volatility = rand() > 0.66 ? "High" : rand() > 0.33 ? "Medium" : "Low";

  return {
    asset: { symbol: asset.symbol, name: asset.name, assetClass: asset.assetClass },
    quote,
    bias,
    confidence,
    momentum,
    volatility
  };
}

export function getAllSnapshots(): AssetSnapshot[] {
  return ASSET_UNIVERSE.map((a) => getAssetSnapshot(a.symbol)!).filter(Boolean);
}

export function formatPrice(price: number, symbol: string): string {
  const asset = findAsset(symbol);
  const decimals = asset?.decimals ?? 2;
  return price.toLocaleString(undefined, {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals
  });
}
