import { getScannerResults } from "./mock/mockAncillaryData";

export const ScannerService = {
  getTopSetups() {
    return getScannerResults();
  }
};
