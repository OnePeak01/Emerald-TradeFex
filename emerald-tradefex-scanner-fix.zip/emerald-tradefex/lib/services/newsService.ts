import { getNewsFeed } from "./mock/mockAncillaryData";

/**
 * NewsService — swap getNewsFeed for a live news API call server-side
 * (see .env.example NEWS_API_KEY) and run it through the same
 * sentiment/AI-interpretation pipeline used by the mock provider.
 */
export const NewsService = {
  getFeed() {
    return getNewsFeed();
  }
};
