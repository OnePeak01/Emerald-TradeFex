import "server-only";
import { AssetSnapshot, Quote } from "@/lib/types";
import { getAllSnapshots, getQuote } from "./mock/mockMarketData";
import { fetchAllLiveQuotes, fetchLiveQuotes } from "./live/liveMarketData";

/**
 * LiveMarketDataService
 * ----------------------
 * Merges real quotes from the live provider on top of mock snapshots
 * (bias/confidence/momentum are still the AI layer, not a price feed — see
 * lib/services/mock/mockPredictionProvider.ts). Any symbol the live
 * provider couldn't serve keeps its mock quote, so a page never shows a
 * gap. Safe to call with no MARKET_DATA_API_KEY set — everything just
 * stays on mock data, silently.
 *
 * Deliberately kept out of marketDataService.ts: this file (and the
 * `live/` provider underneath it) is server-only, and marketDataService.ts
 * is imported by client components too. Only call this from a Server
 * Component or a Route Handler.
 */
export const LiveMarketDataService = {
  async getLiveSnapshots(): Promise<AssetSnapshot[]> {
    const mockSnapshots = getAllSnapshots();
    const live = await fetchAllLiveQuotes();

    return mockSnapshots.map((snapshot) => {
      const liveQuote = live.get(snapshot.asset.symbol);
      if (!liveQuote) return snapshot;
      return {
        ...snapshot,
        quote: {
          ...snapshot.quote,
          price: liveQuote.price,
          changePercent24h: liveQuote.changePercent,
          updatedAt: new Date().toISOString()
        }
      };
    });
  },

  async getLiveQuote(symbol: string): Promise<Quote> {
    const mockQuote = getQuote(symbol);
    const live = await fetchLiveQuotes([symbol]);
    const liveQuote = live.get(symbol);
    if (!liveQuote) return mockQuote;
    return {
      symbol,
      price: liveQuote.price,
      changePercent24h: liveQuote.changePercent,
      updatedAt: new Date().toISOString()
    };
  }
};
