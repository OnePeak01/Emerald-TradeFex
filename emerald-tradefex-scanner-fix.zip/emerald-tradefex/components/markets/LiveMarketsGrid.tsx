"use client";

import Link from "next/link";
import clsx from "clsx";
import { AssetClass, AssetSnapshot } from "@/lib/types";
import { BiasBadge } from "@/components/ui/BiasBadge";
import { AnimatedValue } from "@/components/ui/AnimatedValue";
import { useLiveQuotes } from "@/hooks/useLiveQuotes";

const GROUPS: { label: string; assetClass: AssetClass }[] = [
  { label: "Forex", assetClass: "forex" },
  { label: "Commodities", assetClass: "commodities" },
  { label: "Indices", assetClass: "indices" },
  { label: "Crypto", assetClass: "crypto" }
];

export function LiveMarketsGrid({ snapshots }: { snapshots: AssetSnapshot[] }) {
  const initial = Object.fromEntries(
    snapshots.map((s) => [
      s.asset.symbol,
      { price: s.quote.price, changePercent24h: s.quote.changePercent24h, isLive: false }
    ])
  );
  const live = useLiveQuotes(initial);

  return (
    <>
      {GROUPS.map((group) => {
        const groupSnapshots = snapshots.filter((s) => s.asset.assetClass === group.assetClass);
        if (groupSnapshots.length === 0) return null;
        return (
          <section key={group.assetClass}>
            <h2 className="mb-3 font-display text-sm font-medium text-ink-muted">{group.label}</h2>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {groupSnapshots.map((snapshot) => {
                const quote = live[snapshot.asset.symbol] ?? {
                  price: snapshot.quote.price,
                  changePercent24h: snapshot.quote.changePercent24h,
                  isLive: false
                };
                const isUp = quote.changePercent24h >= 0;

                return (
                  <Link
                    key={snapshot.asset.symbol}
                    href={`/dashboard/predictions?symbol=${encodeURIComponent(snapshot.asset.symbol)}` as any}
                    className="group glass-panel block rounded-xl p-4 transition-all duration-300 hover:border-emerald/40 hover:shadow-glow-card"
                  >
                    <div className="mb-3 flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-display text-[15px] font-medium text-ink">
                            {snapshot.asset.symbol}
                          </span>
                          {quote.isLive && (
                            <span
                              title="Live price"
                              className="h-1.5 w-1.5 rounded-full bg-emerald shadow-glow"
                            />
                          )}
                        </div>
                        <div className="text-xs text-ink-faint">{snapshot.asset.name}</div>
                      </div>
                      <BiasBadge bias={snapshot.bias} size="sm" />
                    </div>

                    <div className="mb-3 flex items-baseline gap-2">
                      <span className="font-nums font-display text-xl font-semibold text-ink">
                        <AnimatedValue value={quote.price} formatType="price" symbol={snapshot.asset.symbol} />
                      </span>
                      <span
                        className={clsx(
                          "font-nums text-sm font-medium",
                          isUp ? "text-emerald" : "text-bearish"
                        )}
                      >
                        {isUp ? "+" : ""}
                        {quote.changePercent24h.toFixed(2)}%
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-xs text-ink-muted">
                      <span>
                        Momentum <span className="text-ink">{snapshot.momentum}</span>
                      </span>
                      <span>
                        Vol <span className="text-ink">{snapshot.volatility}</span>
                      </span>
                      <span className="font-nums text-emerald">{snapshot.confidence}%</span>
                    </div>
                  </Link>
                );
              })}
            </div>
          </section>
        );
      })}
    </>
  );
}
