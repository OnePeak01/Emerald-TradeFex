import Link from "next/link";
import clsx from "clsx";
import { AssetSnapshot } from "@/lib/types";
import { formatPrice } from "@/lib/services/mock/mockMarketData";
import { BiasBadge } from "@/components/ui/BiasBadge";

export function AssetCard({ snapshot }: { snapshot: AssetSnapshot }) {
  const { asset, quote, bias, confidence, momentum, volatility } = snapshot;
  const isUp = quote.changePercent24h >= 0;

  return (
    <Link
      href={`/dashboard/predictions?symbol=${encodeURIComponent(asset.symbol)}` as any}
      className="group glass-panel block rounded-xl p-4 transition-all duration-300 hover:border-emerald/40 hover:shadow-glow-card"
    >
      <div className="mb-3 flex items-start justify-between">
        <div>
          <div className="font-display text-[15px] font-medium text-ink">{asset.symbol}</div>
          <div className="text-xs text-ink-faint">{asset.name}</div>
        </div>
        <BiasBadge bias={bias} size="sm" />
      </div>

      <div className="mb-3 flex items-baseline gap-2">
        <span className="font-nums font-display text-xl font-semibold text-ink">
          {formatPrice(quote.price, asset.symbol)}
        </span>
        <span className={clsx("font-nums text-sm font-medium", isUp ? "text-emerald" : "text-bearish")}>
          {isUp ? "+" : ""}
          {quote.changePercent24h.toFixed(2)}%
        </span>
      </div>

      <div className="flex items-center justify-between text-xs text-ink-muted">
        <span>
          Momentum <span className="text-ink">{momentum}</span>
        </span>
        <span>
          Vol <span className="text-ink">{volatility}</span>
        </span>
        <span className="font-nums text-emerald">{confidence}%</span>
      </div>
    </Link>
  );
}
