"use client";

import { ReactNode, useEffect, useState } from "react";
import { AlertTriangle, TrendingUp, TrendingDown, Minus, Clock } from "lucide-react";
import { Card, CardBody } from "@/components/ui/Card";
import { AnimatedValue } from "@/components/ui/AnimatedValue";
import { Prediction } from "@/lib/types";
import clsx from "clsx";

function StatBlock({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <div className="text-[11px] uppercase tracking-wide text-ink-faint">{label}</div>
      <div className="font-nums text-sm font-semibold text-ink">{children}</div>
    </div>
  );
}

/**
 * Ticks every second and renders how long ago the signal was generated
 * (e.g. "12s ago", "4m 03s ago"). Previously this just printed a static
 * `toLocaleTimeString()` snapshot of createdAt once and never updated,
 * which read as a frozen/dead clock. Turns amber once the signal is stale
 * enough that its levels may no longer reflect current price action.
 */
function LiveSignalAge({ createdAt }: { createdAt: string }) {
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  const elapsedMs = Math.max(0, now - new Date(createdAt).getTime());
  const totalSeconds = Math.floor(elapsedMs / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  const label =
    minutes > 0 ? `${minutes}m ${seconds.toString().padStart(2, "0")}s ago` : `${seconds}s ago`;
  const isStale = totalSeconds > 300; // 5 minutes

  return (
    <span
      className={clsx("flex items-center gap-1 text-[11px]", isStale ? "text-gold" : "text-ink-faint")}
      title={new Date(createdAt).toLocaleString()}
    >
      <Clock size={11} className={clsx(!isStale && "animate-pulse")} /> {label}
    </span>
  );
}

/**
 * Premium AI signal card. Every field is read directly from the
 * already-computed Prediction/TradeScenario for this symbol+timeframe —
 * nothing here is invented independently of the model output shown
 * elsewhere on the page. When the model has no directional lean, it
 * renders a neutral "standing by" state instead of forcing a signal.
 */
export function SignalCard({ prediction }: { prediction: Prediction }) {
  const { scenario, symbol, direction, regime, createdAt } = prediction;
  const [entered, setEntered] = useState(false);

  useEffect(() => {
    setEntered(false);
    const raf = requestAnimationFrame(() => setEntered(true));
    return () => cancelAnimationFrame(raf);
    // Re-trigger the entrance animation whenever a new signal comes in.
  }, [prediction.id]);

  const isBuy = direction === "BULLISH" && scenario.direction === "LONG BIAS";
  const isSell = direction === "BEARISH" && scenario.direction === "SHORT BIAS";
  const isNeutral = !isBuy && !isSell;

  return (
    <Card
      className={clsx(
        "overflow-hidden border transition-all duration-500 ease-out",
        isBuy && "border-emerald/40 shadow-glow-card",
        isSell && "border-bearish/40",
        isNeutral && "border-surface-border",
        entered ? "translate-y-0 opacity-100" : "translate-y-2 opacity-0"
      )}
    >
      <div
        className={clsx(
          "flex items-center justify-between px-5 py-3",
          isBuy && "bg-emerald-dim",
          isSell && "bg-bearish-dim",
          isNeutral && "bg-surface-raised"
        )}
      >
        <div className="flex items-center gap-2">
          {isBuy && <TrendingUp size={16} className="text-emerald" />}
          {isSell && <TrendingDown size={16} className="text-bearish" />}
          {isNeutral && <Minus size={16} className="text-ink-muted" />}
          <span
            className={clsx(
              "font-display text-sm font-bold tracking-wide",
              isBuy && "text-emerald",
              isSell && "text-bearish",
              isNeutral && "text-ink-muted"
            )}
          >
            {isBuy && "AI BUY SIGNAL"}
            {isSell && "AI SELL SIGNAL"}
            {isNeutral && "AI STANDING BY"}
          </span>
        </div>
        <LiveSignalAge createdAt={createdAt} />
      </div>

      <CardBody className="pt-4">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <div className="font-display text-lg font-semibold text-ink">{symbol}</div>
            <div className="text-xs text-ink-faint">Market regime: {regime}</div>
          </div>
          <div className="text-right">
            <div className="text-[11px] uppercase tracking-wide text-ink-faint">Current Price</div>
            <div className="font-nums text-lg font-semibold text-ink">
              <AnimatedValue value={prediction.currentPrice} formatType="price" symbol={symbol} />
            </div>
          </div>
        </div>

        {isNeutral ? (
          <p className="rounded-lg bg-surface-raised p-3 text-sm text-ink-muted">
            No high-conviction setup right now — signals from structure, momentum and sentiment aren't aligned
            enough to suggest an entry. Check back as conditions develop.
          </p>
        ) : (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            <StatBlock label="Entry Zone">
              <AnimatedValue value={scenario.entryZone[0]} formatType="price" symbol={symbol} />
              {" – "}
              <AnimatedValue value={scenario.entryZone[1]} formatType="price" symbol={symbol} />
            </StatBlock>
            <StatBlock label="Stop Loss">
              <AnimatedValue value={scenario.invalidation} formatType="price" symbol={symbol} />
            </StatBlock>
            <StatBlock label="Take Profit 1">
              <AnimatedValue value={scenario.target1} formatType="price" symbol={symbol} />
            </StatBlock>
            <StatBlock label="Take Profit 2">
              <AnimatedValue value={scenario.target2} formatType="price" symbol={symbol} />
            </StatBlock>
            <StatBlock label="Confidence">
              <AnimatedValue value={scenario.confidence} formatType="percent" />
            </StatBlock>
            <StatBlock label="Risk / Reward">
              {scenario.riskRewardRatio > 0 ? `1 : ${scenario.riskRewardRatio}` : "—"}
            </StatBlock>
            <StatBlock label="Trend">{regime}</StatBlock>
            <StatBlock label="Status">{scenario.status.replace("_", " ")}</StatBlock>
          </div>
        )}

        {!isNeutral && (
          <p className="mt-4 rounded-lg bg-surface-raised p-3 text-xs leading-relaxed text-ink-muted">
            <span className="font-medium text-ink">Reasoning: </span>
            {prediction.explanation}
          </p>
        )}

        <div className="mt-4 flex items-start gap-2 rounded-lg border border-surface-border p-3 text-xs text-ink-muted">
          <AlertTriangle size={14} className="mt-0.5 shrink-0 text-gold" />
          <p>
            AI-generated suggestion, not a guaranteed outcome or executed trade — TradeFeX does not place trades on
            your behalf. Not financial advice. Markets involve risk.
          </p>
        </div>
      </CardBody>
    </Card>
  );
}
