import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/Card";
import { ConfidenceRing } from "@/components/ui/ConfidenceRing";
import { StatBar } from "@/components/ui/StatBar";
import { Prediction } from "@/lib/types";

export function ConfidenceEngine({ prediction }: { prediction: Prediction }) {
  const b = prediction.confidenceBreakdown;
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-ink text-base">TradeFeX AI Score</CardTitle>
      </CardHeader>
      <CardBody>
        <div className="mb-5 flex items-center gap-5">
          <ConfidenceRing value={prediction.confidence} size={104} label="/ 100" />
          <div className="text-sm text-ink-muted">
            Composite score across six weighted signal groups. A higher score reflects stronger agreement
            across structure, momentum, sentiment and macro conditions — not a guarantee of outcome.
          </div>
        </div>
        <div className="space-y-4">
          <StatBar label="Technical Structure" score={b.technicalStructure.score} max={b.technicalStructure.max} />
          <StatBar label="Momentum" score={b.momentum.score} max={b.momentum.max} />
          <StatBar label="Market Sentiment" score={b.marketSentiment.score} max={b.marketSentiment.max} />
          <StatBar label="Volatility" score={b.volatility.score} max={b.volatility.max} />
          <StatBar label="Macro Conditions" score={b.macroConditions.score} max={b.macroConditions.max} />
          <StatBar label="Liquidity" score={b.liquidity.score} max={b.liquidity.max} />
        </div>
      </CardBody>
    </Card>
  );
}
