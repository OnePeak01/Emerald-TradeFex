import { SentimentBreakdown } from "@/lib/types";

export function SentimentBars({ sentiment }: { sentiment: SentimentBreakdown }) {
  const segments = [
    { label: "Bullish", value: sentiment.bullishPercent, color: "#1FAE71" },
    { label: "Neutral", value: sentiment.neutralPercent, color: "#5B6360" },
    { label: "Bearish", value: sentiment.bearishPercent, color: "#D9605C" }
  ];

  return (
    <div>
      <div className="flex h-3 w-full overflow-hidden rounded-full bg-surface-raised">
        {segments.map((s) => (
          <div key={s.label} style={{ width: `${s.value}%`, backgroundColor: s.color }} />
        ))}
      </div>
      <div className="mt-3 flex flex-wrap gap-x-6 gap-y-1 text-sm">
        {segments.map((s) => (
          <span key={s.label} className="flex items-center gap-1.5 text-ink-muted">
            <span className="h-2 w-2 rounded-full" style={{ backgroundColor: s.color }} />
            {s.label} <span className="font-nums font-medium text-ink">{s.value}%</span>
          </span>
        ))}
      </div>
    </div>
  );
}
