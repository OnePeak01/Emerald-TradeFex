import { ArrowRight, ArrowUpRight, ArrowDownRight } from "lucide-react";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/Card";
import { Bias, Timeframe } from "@/lib/types";
import clsx from "clsx";

const ORDER: Timeframe[] = ["5M", "15M", "1H", "4H", "1D"];

function ArrowFor({ bias }: { bias: Bias }) {
  if (bias === "BULLISH") return <ArrowUpRight className="text-emerald" size={18} />;
  if (bias === "BEARISH") return <ArrowDownRight className="text-bearish" size={18} />;
  return <ArrowRight className="text-ink-faint" size={18} />;
}

export function MultiTimeframeMatrix({
  symbol,
  consensus,
  overallBias,
  overallConfidence
}: {
  symbol: string;
  consensus: Record<Timeframe, Bias>;
  overallBias: Bias;
  overallConfidence: number;
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-ink text-base">Multi-Timeframe Analysis</CardTitle>
      </CardHeader>
      <CardBody>
        <div className="grid grid-cols-6 items-center gap-2 text-center text-xs text-ink-faint">
          <div className="text-left text-sm text-ink">{symbol}</div>
          {ORDER.map((tf) => (
            <div key={tf}>{tf}</div>
          ))}
        </div>
        <div className="mt-2 grid grid-cols-6 items-center gap-2">
          <div />
          {ORDER.map((tf) => (
            <div key={tf} className="flex justify-center">
              <ArrowFor bias={consensus[tf]} />
            </div>
          ))}
        </div>

        <div
          className={clsx(
            "mt-5 flex items-center justify-between rounded-lg border p-3",
            overallBias === "BULLISH"
              ? "border-emerald/30 bg-emerald-dim"
              : overallBias === "BEARISH"
              ? "border-bearish/30 bg-bearish-dim"
              : "border-surface-border bg-surface-raised"
          )}
        >
          <span className="text-sm font-medium text-ink-muted">TradeFeX Consensus</span>
          <span className="font-display text-sm font-semibold text-ink">
            {overallBias} · {overallConfidence}%
          </span>
        </div>
      </CardBody>
    </Card>
  );
}
