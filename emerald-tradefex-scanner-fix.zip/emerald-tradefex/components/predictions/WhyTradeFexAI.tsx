import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/Card";
import { Prediction } from "@/lib/types";

function FactorRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between border-b border-surface-border py-2.5 last:border-0">
      <span className="text-sm text-ink-muted">{label}</span>
      <span className="text-sm font-medium text-ink">{value}</span>
    </div>
  );
}

export function WhyTradeFexAI({ prediction }: { prediction: Prediction }) {
  const { factors, symbol, direction } = prediction;
  const title =
    direction === "NEUTRAL" ? `Why TradeFeX AI is neutral on ${symbol}` : `Why TradeFeX AI is ${direction.toLowerCase()} on ${symbol}`;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-ink text-base">{title}</CardTitle>
      </CardHeader>
      <CardBody>
        <div className="mb-4">
          <FactorRow label="Market Structure" value={factors.marketStructure} />
          <FactorRow label="Momentum" value={factors.momentum} />
          <FactorRow label="RSI" value={factors.rsiState} />
          <FactorRow label="MACD" value={factors.macdState} />
          <FactorRow label="Support Structure" value={factors.supportStructure} />
          <FactorRow label="Market Sentiment" value={factors.sentiment} />
          <FactorRow label="Macro Environment" value={factors.macro} />
          <FactorRow label="Volatility" value={factors.volatility} />
        </div>
        <p className="rounded-lg bg-surface-raised p-4 text-sm leading-relaxed text-ink-muted">
          {prediction.explanation}
        </p>
      </CardBody>
    </Card>
  );
}
