"use client";

import { useEffect, useRef, useState } from "react";
import { ColorType, createChart, IChartApi, ISeriesApi } from "lightweight-charts";
import { Candle, Prediction, Timeframe } from "@/lib/types";
import { TIMEFRAME_SECONDS } from "@/lib/services/mock/mockMarketData";
import { useLiveQuote } from "@/hooks/useLiveQuotes";

// Below this granularity the chart should visibly move between full page
// refreshes, not just when the server sends new candles — so we drive the
// current (rightmost) bar off the same live/mock quote ticker the price
// figure already uses, bucketed into this timeframe's bar width.
const LIVE_BAR_THRESHOLD_SECONDS = 30;

export function ForecastChart({
  candles,
  prediction,
  timeframe
}: {
  candles: Candle[];
  prediction: Prediction;
  timeframe: Timeframe;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const candleSeriesRef = useRef<ISeriesApi<"Candlestick"> | null>(null);
  const volumeSeriesRef = useRef<ISeriesApi<"Histogram"> | null>(null);
  const forecastHighRef = useRef<ISeriesApi<"Line"> | null>(null);
  const forecastLowRef = useRef<ISeriesApi<"Line"> | null>(null);
  const invalidationRef = useRef<ISeriesApi<"Line"> | null>(null);
  const [settling, setSettling] = useState(false);
  const lastBarRef = useRef<{ time: number; open: number; high: number; low: number; close: number } | null>(null);

  const stepSeconds = TIMEFRAME_SECONDS[timeframe];
  const isFastTimeframe = stepSeconds <= LIVE_BAR_THRESHOLD_SECONDS;
  const lastCandle = candles[candles.length - 1];

  // Reuses the app's existing live/mock quote pipeline (same one behind
  // the price figure) — no separate fabricated data source.
  const liveQuote = useLiveQuote(prediction.symbol, {
    price: lastCandle?.close ?? prediction.currentPrice,
    changePercent24h: 0,
    isLive: false
  });

  // Create the chart + series exactly once. Every subsequent data change
  // (new timeframe, new symbol, new prediction) updates these same series
  // via setData rather than tearing the chart down, so the timescale/zoom
  // don't reset and the switch reads as an update, not a fresh mount.
  useEffect(() => {
    if (!containerRef.current) return;

    const chart = createChart(containerRef.current, {
      layout: {
        background: { type: ColorType.Solid, color: "transparent" },
        textColor: "#8B948E",
        fontFamily: "var(--font-inter)"
      },
      grid: {
        vertLines: { color: "rgba(35,42,38,0.6)" },
        horzLines: { color: "rgba(35,42,38,0.6)" }
      },
      rightPriceScale: { borderColor: "#232823" },
      timeScale: { borderColor: "#232823", timeVisible: true, secondsVisible: true },
      crosshair: { mode: 0 },
      height: 420,
      width: containerRef.current.clientWidth
    });
    chartRef.current = chart;

    candleSeriesRef.current = chart.addCandlestickSeries({
      upColor: "#1FAE71",
      downColor: "#D9605C",
      borderVisible: false,
      wickUpColor: "#1FAE71",
      wickDownColor: "#D9605C"
    });

    volumeSeriesRef.current = chart.addHistogramSeries({
      priceFormat: { type: "volume" },
      priceScaleId: "",
      color: "rgba(31,174,113,0.25)"
    });
    volumeSeriesRef.current.priceScale().applyOptions({ scaleMargins: { top: 0.85, bottom: 0 } });

    forecastHighRef.current = chart.addLineSeries({
      color: "rgba(31,174,113,0.55)",
      lineWidth: 1,
      lineStyle: 2,
      lastValueVisible: true,
      title: "Forecast High"
    });
    forecastLowRef.current = chart.addLineSeries({
      color: "rgba(31,174,113,0.55)",
      lineWidth: 1,
      lineStyle: 2,
      lastValueVisible: true,
      title: "Forecast Low"
    });
    invalidationRef.current = chart.addLineSeries({
      color: "rgba(217,96,92,0.6)",
      lineWidth: 1,
      lineStyle: 3,
      title: "Invalidation"
    });

    const resize = () => {
      if (containerRef.current) chart.applyOptions({ width: containerRef.current.clientWidth });
    };
    window.addEventListener("resize", resize);

    return () => {
      window.removeEventListener("resize", resize);
      chart.remove();
      chartRef.current = null;
    };
    // Intentionally created once — data updates are handled in the effect below.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Push new data into the existing series whenever candles/prediction
  // change (new symbol, new timeframe, or a refreshed forecast). A brief
  // opacity dip on the container makes the switch read as a deliberate
  // transition rather than an instant snap, without touching chart state.
  useEffect(() => {
    if (
      !candleSeriesRef.current ||
      !volumeSeriesRef.current ||
      !forecastHighRef.current ||
      !forecastLowRef.current ||
      !invalidationRef.current
    ) {
      return;
    }

    setSettling(true);
    const settleTimer = setTimeout(() => setSettling(false), 220);

    candleSeriesRef.current.setData(
      candles.map((c) => ({ time: c.time as any, open: c.open, high: c.high, low: c.low, close: c.close }))
    );
    volumeSeriesRef.current.setData(
      candles.map((c) => ({ time: c.time as any, value: c.volume, color: "rgba(139,148,142,0.3)" }))
    );

    const firstTime = candles[0]?.time as any;
    const lastTime = (candles[candles.length - 1]?.time as any) + 60 * 60 * 24 * 3;

    forecastHighRef.current.setData([
      { time: firstTime, value: prediction.expectedRange[1] },
      { time: lastTime, value: prediction.expectedRange[1] }
    ]);
    forecastLowRef.current.setData([
      { time: firstTime, value: prediction.expectedRange[0] },
      { time: lastTime, value: prediction.expectedRange[0] }
    ]);
    invalidationRef.current.setData([
      { time: firstTime, value: prediction.scenario.invalidation },
      { time: lastTime, value: prediction.scenario.invalidation }
    ]);

    chartRef.current?.timeScale().fitContent();

    lastBarRef.current = lastCandle
      ? { time: lastCandle.time, open: lastCandle.open, high: lastCandle.high, low: lastCandle.low, close: lastCandle.close }
      : null;

    return () => clearTimeout(settleTimer);
  }, [candles, prediction]);

  // For sub-30s timeframes, nudge the rightmost bar in real time using the
  // same live/mock price ticker the price figure uses — bucketed into this
  // timeframe's bar width — so the chart visibly moves instead of only
  // updating on full navigations. `.update()` either revises the current
  // bar in place (same bucket) or appends a new one (new bucket); it never
  // rewrites history.
  useEffect(() => {
    if (!isFastTimeframe || !candleSeriesRef.current || !lastBarRef.current) return;

    const bar = lastBarRef.current;
    const bucketStart = Math.floor(Date.now() / 1000 / stepSeconds) * stepSeconds;
    const price = liveQuote.price;

    if (bucketStart === bar.time) {
      // Same bar: revise its high/low/close in place.
      const updated = {
        time: bar.time,
        open: bar.open,
        high: Math.max(bar.high, price),
        low: Math.min(bar.low, price),
        close: price
      };
      lastBarRef.current = updated;
      candleSeriesRef.current.update({ ...updated, time: updated.time as any });
    } else if (bucketStart > bar.time) {
      // New bar: opens where the previous one closed.
      const open = bar.close;
      const updated = { time: bucketStart, open, high: Math.max(open, price), low: Math.min(open, price), close: price };
      lastBarRef.current = updated;
      candleSeriesRef.current.update({ ...updated, time: updated.time as any });
    }
  }, [liveQuote.price, isFastTimeframe, stepSeconds]);

  return (
    <div
      ref={containerRef}
      className="w-full transition-opacity duration-200 ease-out"
      style={{ opacity: settling ? 0.55 : 1 }}
    />
  );
}
