"use client";

import { useLiveQuote } from "@/hooks/useLiveQuotes";
import { AnimatedValue } from "@/components/ui/AnimatedValue";

export function LivePriceFigure({
  symbol,
  initialPrice,
  initialChangePercent24h
}: {
  symbol: string;
  initialPrice: number;
  initialChangePercent24h: number;
}) {
  const quote = useLiveQuote(symbol, {
    price: initialPrice,
    changePercent24h: initialChangePercent24h,
    isLive: false
  });

  return (
    <div>
      <div className="flex items-center gap-1.5 text-xs text-ink-faint">
        Current Price
        {quote.isLive && <span title="Live price" className="h-1.5 w-1.5 rounded-full bg-emerald shadow-glow" />}
      </div>
      <div className="font-nums font-display text-xl font-semibold text-ink">
        <AnimatedValue value={quote.price} formatType="price" symbol={symbol} />
      </div>
    </div>
  );
}
