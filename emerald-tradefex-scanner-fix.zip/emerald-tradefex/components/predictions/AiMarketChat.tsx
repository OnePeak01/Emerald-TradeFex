"use client";

import { useEffect, useRef, useState } from "react";
import { Send, Bot, Sparkles, Wifi, WifiOff } from "lucide-react";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/Card";
import { formatPrice } from "@/lib/services/mock/mockMarketData";
import { Prediction } from "@/lib/types";

type Message = { id: string; role: "user" | "ai"; text: string };

const QUICK_QUESTIONS = [
  "Should I buy this?",
  "What's the current trend?",
  "Give me an entry setup.",
  "Where should my SL and TP be?"
];

const HISTORY_LIMIT = 20; // turns sent to the model as context
const STORAGE_PREFIX = "tradefex:ai-chat:";

function storageKey(predictionId: string) {
  return `${STORAGE_PREFIX}${predictionId}`;
}

function introMessage(prediction: Prediction): Message {
  return {
    id: "intro",
    role: "ai",
    text: `Ask me about ${prediction.symbol}'s current AI forecast — trend, entry setup, or SL/TP levels.`
  };
}

function loadHistory(prediction: Prediction): Message[] {
  if (typeof window === "undefined") return [introMessage(prediction)];
  try {
    const raw = window.localStorage.getItem(storageKey(prediction.id));
    if (!raw) return [introMessage(prediction)];
    const parsed = JSON.parse(raw) as Message[];
    if (!Array.isArray(parsed) || parsed.length === 0) return [introMessage(prediction)];
    return parsed;
  } catch {
    return [introMessage(prediction)];
  }
}

function saveHistory(prediction: Prediction, messages: Message[]) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(storageKey(prediction.id), JSON.stringify(messages));
  } catch {
    // localStorage can throw in private-browsing/quota-exceeded cases —
    // chat still works for the session, it just won't survive a refresh.
  }
}

/**
 * Deterministic fallback used when the live model isn't configured (no
 * ANTHROPIC_API_KEY on the server) or a live request fails — so the widget
 * degrades gracefully instead of breaking. Every field is read directly off
 * the same Prediction object rendered elsewhere on the page.
 */
function templateAnswer(question: string, prediction: Prediction): string {
  const q = question.toLowerCase();
  const { symbol, direction, probability, scenario, regime, explanation, forecastHorizon } = prediction;
  const fmt = (n: number) => formatPrice(n, symbol);
  const biasWord = direction === "BULLISH" ? "bullish" : direction === "BEARISH" ? "bearish" : "neutral";

  if (/buy|long|should i/.test(q) && !/sell|short/.test(q)) {
    if (direction === "BULLISH") {
      return `The model is leaning bullish on ${symbol} with ${probability}% probability over the next ${forecastHorizon.toLowerCase()}. Scenario suggests a potential entry zone around ${fmt(
        scenario.entryZone[0]
      )}–${fmt(scenario.entryZone[1])} with confidence ${scenario.confidence}%. This is a model-generated view, not a guaranteed outcome — size and risk are your call.`;
    }
    if (direction === "BEARISH") {
      return `Right now the AI is leaning bearish on ${symbol} (${probability}% probability), so the current setup doesn't support a buy case. See the AI Sell/Signal card for the short-bias scenario instead.`;
    }
    return `The model doesn't see a clear directional edge on ${symbol} at the moment — factors are mixed, so there's no high-conviction buy setup to show.`;
  }

  if (/sell|short/.test(q)) {
    if (direction === "BEARISH") {
      return `The AI is leaning bearish on ${symbol} with ${probability}% probability. Scenario suggests a potential entry zone around ${fmt(
        scenario.entryZone[0]
      )}–${fmt(scenario.entryZone[1])}, invalidation near ${fmt(scenario.invalidation)}.`;
    }
    return `Current bias on ${symbol} is ${biasWord}, not bearish, so there's no sell setup being suggested right now.`;
  }

  if (/trend|regime|bias/.test(q)) {
    return `${symbol} is currently in a "${regime}" regime with a ${biasWord} bias (${probability}% probability). ${explanation}`;
  }

  if (/entry/.test(q)) {
    return scenario.riskRewardRatio > 0
      ? `Suggested entry zone for ${symbol}: ${fmt(scenario.entryZone[0])}–${fmt(scenario.entryZone[1])}, targeting ${fmt(
          scenario.target1
        )} (T1) and ${fmt(scenario.target2)} (T2), risk/reward roughly 1:${scenario.riskRewardRatio}.`
      : `There isn't a well-defined entry setup for ${symbol} right now — risk/reward doesn't clear the bar the model uses to suggest one.`;
  }

  if (/sl|stop|tp|take profit|target/.test(q)) {
    return `For the current ${symbol} scenario: Stop Loss (invalidation) is around ${fmt(
      scenario.invalidation
    )}, Take Profit 1 at ${fmt(scenario.target1)}, and Take Profit 2 at ${fmt(scenario.target2)}. These are AI-suggested levels, not guarantees.`;
  }

  if (/confiden/.test(q)) {
    return `Composite AI confidence on ${symbol} is ${scenario.confidence}/100, blending technical structure, momentum, sentiment, volatility, macro and liquidity signals.`;
  }

  return `I can answer questions grounded in ${symbol}'s current forecast — try asking about the trend, an entry setup, or SL/TP levels. For the full breakdown, see the Scenario and Confidence cards above.`;
}

export function AiMarketChat({ prediction }: { prediction: Prediction }) {
  const [messages, setMessages] = useState<Message[]>(() => loadHistory(prediction));
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const [live, setLive] = useState<boolean | null>(null); // null = unknown yet, true/false once we've tried
  const scrollRef = useRef<HTMLDivElement>(null);
  const loadedForId = useRef(prediction.id);

  // Only reset the thread when the loaded symbol/timeframe actually changes
  // (a fresh Prediction id) — reloading the saved thread for that id from
  // storage rather than always wiping it, so a page refresh on the same
  // symbol/timeframe keeps the conversation instead of losing it.
  useEffect(() => {
    if (loadedForId.current === prediction.id) return;
    loadedForId.current = prediction.id;
    setMessages(loadHistory(prediction));
  }, [prediction]);

  useEffect(() => {
    saveHistory(prediction, messages);
  }, [prediction, messages]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, thinking]);

  const send = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || thinking) return;
    const userMsg: Message = { id: `${Date.now()}-u`, role: "user", text: trimmed };
    const nextMessages = [...messages, userMsg];
    setMessages(nextMessages);
    setInput("");
    setThinking(true);

    try {
      const history = nextMessages
        .filter((m) => m.id !== "intro")
        .slice(-HISTORY_LIMIT)
        .map((m) => ({ role: m.role === "ai" ? ("assistant" as const) : ("user" as const), text: m.text }));

      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prediction, history })
      });

      if (!res.ok) throw new Error(`status ${res.status}`);
      const data = await res.json();
      setLive(true);
      setMessages((m) => [...m, { id: `${Date.now()}-a`, role: "ai", text: data.reply }]);
    } catch {
      // Live model unavailable (no API key configured, network error, rate
      // limit, etc.) — fall back to the deterministic template answer so
      // the widget still responds usefully.
      setLive(false);
      setMessages((m) => [...m, { id: `${Date.now()}-a`, role: "ai", text: templateAnswer(trimmed, prediction) }]);
    } finally {
      setThinking(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base text-ink">
          <Sparkles size={15} className="text-emerald" /> AI Market Chat
        </CardTitle>
        {live !== null && (
          <span
            className={`flex items-center gap-1 text-[11px] ${live ? "text-emerald" : "text-ink-faint"}`}
            title={live ? "Answered by the live model" : "Offline — using template answers"}
          >
            {live ? <Wifi size={12} /> : <WifiOff size={12} />}
            {live ? "Live" : "Offline mode"}
          </span>
        )}
      </CardHeader>
      <CardBody className="flex flex-col gap-3 pt-3">
        <div ref={scrollRef} className="flex max-h-72 flex-col gap-2.5 overflow-y-auto pr-1">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex items-start gap-2 text-sm ${m.role === "user" ? "flex-row-reverse text-right" : ""}`}
            >
              {m.role === "ai" && (
                <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-dim text-emerald">
                  <Bot size={13} />
                </span>
              )}
              <div
                className={`max-w-[85%] rounded-xl px-3 py-2 leading-relaxed transition-opacity duration-200 ${
                  m.role === "user" ? "bg-emerald text-base" : "bg-surface-raised text-ink"
                }`}
              >
                {m.text}
              </div>
            </div>
          ))}
          {thinking && (
            <div className="flex items-center gap-2 text-xs text-ink-faint">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-dim text-emerald">
                <Bot size={13} />
              </span>
              <span className="animate-pulse">Analyzing forecast…</span>
            </div>
          )}
        </div>

        <div className="flex flex-wrap gap-1.5">
          {QUICK_QUESTIONS.map((q) => (
            <button
              key={q}
              onClick={() => send(q)}
              disabled={thinking}
              className="rounded-full border border-surface-border px-2.5 py-1 text-xs text-ink-muted transition-colors hover:border-emerald/40 hover:text-emerald disabled:opacity-50"
            >
              {q}
            </button>
          ))}
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            send(input);
          }}
          className="flex items-center gap-2"
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={`Ask about ${prediction.symbol}…`}
            className="flex-1 rounded-lg border border-surface-border bg-surface-raised px-3 py-2 text-sm text-ink outline-none focus-visible:border-emerald"
          />
          <button
            type="submit"
            aria-label="Send"
            disabled={thinking}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald text-base transition-transform duration-150 hover:scale-105 active:scale-95 disabled:opacity-50"
          >
            <Send size={15} />
          </button>
        </form>
      </CardBody>
    </Card>
  );
}
