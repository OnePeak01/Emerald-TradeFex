"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import clsx from "clsx";
import { Wifi, WifiOff } from "lucide-react";
import { ScannerResult, AssetClass } from "@/lib/types";
import { BiasBadge } from "@/components/ui/BiasBadge";
import { Card, CardBody } from "@/components/ui/Card";
import { findAsset } from "@/lib/services/mock/assetUniverse";

const ASSET_FILTERS: { label: string; value: AssetClass | "all" }[] = [
  { label: "All", value: "all" },
  { label: "Forex", value: "forex" },
  { label: "Commodities", value: "commodities" },
  { label: "Indices", value: "indices" },
  { label: "Crypto", value: "crypto" }
];

const SIGNAL_TYPES: ScannerResult["signalType"][] = [
  "Trend Continuation",
  "Breakout",
  "Reversal",
  "Momentum",
  "Support Bounce",
  "Resistance Rejection"
];

const REFRESH_INTERVAL_MS = 15000;

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={clsx(
        "shrink-0 whitespace-nowrap rounded-full border px-3 py-1.5 text-xs font-medium transition-colors",
        active ? "border-emerald/40 bg-emerald-dim text-emerald" : "border-surface-border text-ink-muted hover:text-ink"
      )}
    >
      {children}
    </button>
  );
}

/**
 * TradingView-style single-row, horizontally scrollable pill strip. Plain
 * flex-wrap let long labels like "Resistance Rejection" wrap awkwardly next
 * to short ones ("All"), producing an uneven, "not coordinated" look and —
 * on some rows — text wrapping to 2 lines mid-render, which nudges page
 * height and is what likely made the bottom nav appear to shift on scroll.
 * A fixed-height, no-wrap, scrollable row removes both problems at once.
 */
function ChipRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-1.5 text-[11px] font-medium uppercase tracking-wide text-ink-faint">{label}</div>
      <div className="scrollbar-none flex gap-2 overflow-x-auto pb-1">{children}</div>
    </div>
  );
}

function LiveRefreshBadge({ live, lastUpdated }: { live: boolean; lastUpdated: Date | null }) {
  const [, forceTick] = useState(0);

  // Re-render every second purely to keep the "Xs ago" label current.
  useEffect(() => {
    const id = setInterval(() => forceTick((n) => n + 1), 1000);
    return () => clearInterval(id);
  }, []);

  const secondsAgo = lastUpdated ? Math.max(0, Math.floor((Date.now() - lastUpdated.getTime()) / 1000)) : null;

  return (
    <span className={clsx("flex items-center gap-1.5 text-xs", live ? "text-emerald" : "text-ink-faint")}>
      {live ? <Wifi size={13} className="animate-pulse" /> : <WifiOff size={13} />}
      {live ? (secondsAgo !== null ? `Updated ${secondsAgo}s ago` : "Live") : "Reconnecting…"}
    </span>
  );
}

export function ScannerClient({ results }: { results: ScannerResult[] }) {
  const [assetFilter, setAssetFilter] = useState<AssetClass | "all">("all");
  const [signalFilter, setSignalFilter] = useState<ScannerResult["signalType"] | "all">("all");
  const [liveResults, setLiveResults] = useState<ScannerResult[]>(results);
  const [live, setLive] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(new Date());
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Poll for fresh rankings instead of leaving the server-rendered snapshot
  // frozen for the lifetime of the page — this was the actual source of the
  // scanner feeling "offline": it never updated after first load.
  useEffect(() => {
    async function poll() {
      try {
        const res = await fetch("/api/scanner", { cache: "no-store" });
        if (!res.ok) throw new Error(String(res.status));
        const data = await res.json();
        setLiveResults(data.results);
        setLastUpdated(new Date(data.generatedAt));
        setLive(true);
      } catch {
        setLive(false);
      }
    }
    pollRef.current = setInterval(poll, REFRESH_INTERVAL_MS);
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, []);

  const filtered = liveResults.filter((r) => {
    const asset = findAsset(r.symbol);
    const matchesAsset = assetFilter === "all" || asset?.assetClass === assetFilter;
    const matchesSignal = signalFilter === "all" || r.signalType === signalFilter;
    return matchesAsset && matchesSignal;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <span className="text-xs text-ink-faint">Continuously ranked market opportunities</span>
        <LiveRefreshBadge live={live} lastUpdated={lastUpdated} />
      </div>

      <div className="space-y-3">
        <ChipRow label="Asset Class">
          {ASSET_FILTERS.map((f) => (
            <Chip key={f.value} active={assetFilter === f.value} onClick={() => setAssetFilter(f.value)}>
              {f.label}
            </Chip>
          ))}
        </ChipRow>

        <ChipRow label="Signal Type">
          <Chip active={signalFilter === "all"} onClick={() => setSignalFilter("all")}>
            All Signals
          </Chip>
          {SIGNAL_TYPES.map((s) => (
            <Chip key={s} active={signalFilter === s} onClick={() => setSignalFilter(s)}>
              {s}
            </Chip>
          ))}
        </ChipRow>
      </div>

      <Card>
        <CardBody className="pt-5">
          {/* Desktop/tablet: aligned grid header + rows */}
          <div className="hidden grid-cols-[2.5rem_1fr_auto_auto_auto] items-center gap-4 border-b border-surface-border pb-3 text-xs text-ink-faint sm:grid">
            <span>Rank</span>
            <span>Asset</span>
            <span>Signal</span>
            <span>Bias</span>
            <span className="text-right">Confidence</span>
          </div>

          {filtered.length === 0 && <p className="py-8 text-center text-sm text-ink-muted">No setups match these filters.</p>}

          <div className="divide-y divide-surface-border">
            {filtered.map((r) => (
              <Link
                key={r.symbol}
                href={`/dashboard/predictions?symbol=${encodeURIComponent(r.symbol)}` as any}
                className="block py-3.5 transition-colors hover:bg-surface-raised"
              >
                {/* Desktop/tablet row */}
                <div className="hidden grid-cols-[2.5rem_1fr_auto_auto_auto] items-center gap-4 sm:grid">
                  <span className="font-nums text-sm text-ink-faint">{String(r.rank).padStart(2, "0")}</span>
                  <span className="font-display text-sm font-medium text-ink">{r.symbol}</span>
                  <span className="text-xs text-ink-muted">{r.signalType}</span>
                  <BiasBadge bias={r.bias} size="sm" />
                  <span className="text-right font-nums text-sm font-medium text-emerald">{r.confidence}%</span>
                </div>

                {/* Mobile: stacked card row — avoids cramming 5 columns (and
                    long signal labels like "Resistance Rejection") into a
                    narrow width, which was causing uneven wraps. */}
                <div className="flex items-center justify-between gap-3 sm:hidden">
                  <div className="flex min-w-0 items-center gap-3">
                    <span className="font-nums shrink-0 text-sm text-ink-faint">{String(r.rank).padStart(2, "0")}</span>
                    <div className="min-w-0">
                      <div className="font-display text-sm font-medium text-ink">{r.symbol}</div>
                      <div className="truncate text-xs text-ink-muted">{r.signalType}</div>
                    </div>
                  </div>
                  <div className="flex shrink-0 flex-col items-end gap-1">
                    <BiasBadge bias={r.bias} size="sm" />
                    <span className="font-nums text-xs font-medium text-emerald">{r.confidence}%</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
