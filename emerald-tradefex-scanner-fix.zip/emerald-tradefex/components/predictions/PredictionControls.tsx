"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { Timeframe } from "@/lib/types";
import { MarketDataService } from "@/lib/services/marketDataService";

const TIMEFRAMES: Timeframe[] = ["1S", "15S", "30S", "1M", "5M", "15M", "30M", "1H", "4H", "12H", "1D", "1W"];

export function PredictionControls({ symbol, timeframe }: { symbol: string; timeframe: Timeframe }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const assets = MarketDataService.listAssets();

  const update = (key: "symbol" | "timeframe", value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set(key, value);
    router.push(`/dashboard/predictions?${params.toString()}`);
  };

  return (
    <div className="flex flex-wrap items-center gap-3">
      <select
        value={symbol}
        onChange={(e) => update("symbol", e.target.value)}
        className="rounded-lg border border-surface-border bg-surface-raised px-3 py-2 text-sm text-ink outline-none focus-visible:border-emerald"
      >
        {assets.map((a) => (
          <option key={a.symbol} value={a.symbol}>
            {a.symbol}
          </option>
        ))}
      </select>

      <div className="flex max-w-full gap-1 overflow-x-auto rounded-lg border border-surface-border bg-surface-raised p-1">
        {TIMEFRAMES.map((tf) => (
          <button
            key={tf}
            onClick={() => update("timeframe", tf)}
            className={`shrink-0 rounded-md px-2.5 py-1.5 text-xs font-medium transition-all duration-200 ease-out ${
              tf === timeframe ? "bg-emerald text-base shadow-[0_0_0_1px_rgba(31,174,113,0.4)]" : "text-ink-muted hover:text-ink hover:bg-surface-border/50"
            }`}
          >
            {tf}
          </button>
        ))}
      </div>
    </div>
  );
}
