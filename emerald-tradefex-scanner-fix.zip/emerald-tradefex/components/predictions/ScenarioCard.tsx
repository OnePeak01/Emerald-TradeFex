import { ReactNode } from "react";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/Card";
import { Prediction } from "@/lib/types";
import { AlertTriangle } from "lucide-react";
import { AnimatedValue } from "@/components/ui/AnimatedValue";

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <div className="text-xs text-ink-faint">{label}</div>
      <div className="font-nums text-[15px] font-medium text-ink">{children}</div>
    </div>
  );
}

export function ScenarioCard({ prediction }: { prediction: Prediction }) {
  const { scenario, symbol } = prediction;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-ink text-base">AI Market Scenario</CardTitle>
        <span className="rounded-full border border-emerald/30 bg-emerald-dim px-2.5 py-0.5 text-xs font-medium text-emerald">
          {scenario.status}
        </span>
      </CardHeader>
      <CardBody>
        <div className="mb-4 text-lg font-display font-semibold text-ink">{scenario.direction}</div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
          <Field label="Potential Entry Zone">
            <AnimatedValue value={scenario.entryZone[0]} formatType="price" symbol={symbol} />
            {" – "}
            <AnimatedValue value={scenario.entryZone[1]} formatType="price" symbol={symbol} />
          </Field>
          <Field label="Potential Target">
            <AnimatedValue value={scenario.target1} formatType="price" symbol={symbol} />
          </Field>
          <Field label="Secondary Target">
            <AnimatedValue value={scenario.target2} formatType="price" symbol={symbol} />
          </Field>
          <Field label="Invalidation">
            <AnimatedValue value={scenario.invalidation} formatType="price" symbol={symbol} />
          </Field>
          <Field label="Risk / Reward">
            {scenario.riskRewardRatio > 0 ? (
              <>
                1 : <AnimatedValue value={scenario.riskRewardRatio} formatType="ratio1" />
              </>
            ) : (
              "—"
            )}
          </Field>
          <Field label="Confidence">
            <AnimatedValue value={scenario.confidence} formatType="percent" />
          </Field>
        </div>
        <div className="mt-5 flex items-start gap-2 rounded-lg border border-surface-border bg-surface-raised p-3 text-xs text-ink-muted">
          <AlertTriangle size={14} className="mt-0.5 shrink-0 text-gold" />
          <p>
            This is a model-generated market scenario, not a guaranteed trade. AI-generated analysis — not
            financial advice. Markets involve risk.
          </p>
        </div>
      </CardBody>
    </Card>
  );
}
