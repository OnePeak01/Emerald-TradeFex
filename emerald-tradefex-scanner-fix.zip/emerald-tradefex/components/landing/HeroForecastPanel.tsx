"use client";

import { AreaChart, Area, ResponsiveContainer, YAxis, ReferenceArea, ReferenceLine } from "recharts";
import { Prediction, Candle } from "@/lib/types";
import { formatPrice } from "@/lib/services/mock/mockMarketData";
import { BiasBadge } from "@/components/ui/BiasBadge";
import { AnimatedValue } from "@/components/ui/AnimatedValue";
import { useLiveQuote } from "@/hooks/useLiveQuotes";

export function HeroForecastPanel({ candles, prediction }: { candles: Candle[]; prediction: Prediction }) {
  const data = candles.map((c, i) => ({ i, close: c.close }));
  const lastIndex = data.length - 1;
  const forecastStartIndex = Math.round(lastIndex * 0.82);
  const quote = useLiveQuote(prediction.symbol, {
    price: prediction.currentPrice,
    changePercent24h: 0,
    isLive: false
  });

  return (
    <div className="glass-panel relative overflow-hidden rounded-2xl p-6 shadow-panel">
      <div className="absolute inset-0 bg-grid-fade" />
      <div className="relative">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-1.5 font-display text-sm text-ink-muted">
              {prediction.symbol}
              {quote.isLive && <span title="Live price" className="h-1.5 w-1.5 rounded-full bg-emerald shadow-glow" />}
            </div>
            <div className="font-nums font-display text-3xl font-semibold text-ink">
              <AnimatedValue value={quote.price} formatType="price" symbol={prediction.symbol} />
            </div>
          </div>
          <BiasBadge bias={prediction.direction} />
        </div>

        <div className="mt-6 h-[180px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 4, right: 0, bottom: 0, left: 0 }}>
              <defs>
                <linearGradient id="heroFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#1FAE71" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="#1FAE71" stopOpacity={0} />
                </linearGradient>
              </defs>
              <YAxis hide domain={["dataMin - 0.001", "dataMax + 0.001"]} />
              <ReferenceArea
                x1={forecastStartIndex}
                x2={lastIndex}
                y1={prediction.expectedRange[0]}
                y2={prediction.expectedRange[1]}
                fill="#1FAE71"
                fillOpacity={0.12}
                stroke="#1FAE71"
                strokeOpacity={0.3}
                strokeDasharray="3 3"
              />
              <ReferenceLine x={forecastStartIndex} stroke="#232823" strokeDasharray="2 4" />
              <Area
                type="monotone"
                dataKey="close"
                stroke="#1FAE71"
                strokeWidth={2}
                fill="url(#heroFill)"
                isAnimationActive
                animationDuration={1200}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="mt-2 grid grid-cols-3 gap-4 border-t border-surface-border pt-4 text-sm">
          <div>
            <div className="text-xs text-ink-faint">Confidence</div>
            <div className="font-nums font-medium text-ink">{prediction.probability}%</div>
          </div>
          <div>
            <div className="text-xs text-ink-faint">Potential Range</div>
            <div className="font-nums font-medium text-ink">
              {formatPrice(prediction.expectedRange[0], prediction.symbol)} –{" "}
              {formatPrice(prediction.expectedRange[1], prediction.symbol)}
            </div>
          </div>
          <div>
            <div className="text-xs text-ink-faint">Risk</div>
            <div className="font-medium text-ink">{prediction.risk}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
