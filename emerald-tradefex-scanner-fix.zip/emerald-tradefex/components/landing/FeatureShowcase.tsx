const FEATURES = [
  {
    title: "Probability, not prophecy",
    body: "Every forecast ships as an expected range and a confidence score, not a single guaranteed line — because that's how markets actually behave."
  },
  {
    title: "An explanation for every call",
    body: "Structure, momentum, RSI, MACD, sentiment and macro conditions are scored individually, then translated into plain language you can check against the chart yourself."
  },
  {
    title: "A scanner that never sleeps",
    body: "The AI Scanner continuously re-ranks the full market universe by setup quality, so you see where conviction is building before it's obvious."
  },
  {
    title: "Accuracy you can audit",
    body: "Every prediction is stored and graded against what actually happened. The track record page shows real accuracy — never a marketing number."
  }
];

export function FeatureShowcase() {
  return (
    <section className="mx-auto max-w-[1200px] px-6 py-20">
      <div className="mb-12 max-w-lg">
        <h2 className="font-display text-3xl font-semibold text-ink">Built like a terminal, reasoned like an analyst</h2>
        <p className="mt-3 text-ink-muted">
          Emerald TradeFeX combines live market structure with an AI research layer that shows its work.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-px overflow-hidden rounded-2xl border border-surface-border bg-surface-border md:grid-cols-2">
        {FEATURES.map((f) => (
          <div key={f.title} className="bg-base p-8">
            <h3 className="font-display text-lg font-medium text-ink">{f.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-ink-muted">{f.body}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
