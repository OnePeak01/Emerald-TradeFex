"use client";

import { AssetSnapshot } from "@/lib/types";
import { AnimatedValue } from "@/components/ui/AnimatedValue";
import { useLiveQuotes } from "@/hooks/useLiveQuotes";

export function LiveTickerStrip({ snapshots }: { snapshots: AssetSnapshot[] }) {
  const initial = Object.fromEntries(
    snapshots.map((s) => [
      s.asset.symbol,
      { price: s.quote.price, changePercent24h: s.quote.changePercent24h, isLive: false }
    ])
  );
  const live = useLiveQuotes(initial);
  const doubled = [...snapshots, ...snapshots];

  return (
    <div className="overflow-hidden border-y border-surface-border bg-surface/50 py-3">
      <div className="flex w-max animate-[scroll_38s_linear_infinite] gap-10 px-6">
        {doubled.map((s, i) => {
          const quote = live[s.asset.symbol] ?? {
            price: s.quote.price,
            changePercent24h: s.quote.changePercent24h,
            isLive: false
          };
          const isUp = quote.changePercent24h >= 0;

          return (
            <div key={`${s.asset.symbol}-${i}`} className="flex items-center gap-2 whitespace-nowrap text-sm">
              <span className="font-medium text-ink-muted">{s.asset.symbol}</span>
              <span className="font-nums text-ink">
                <AnimatedValue value={quote.price} formatType="price" symbol={s.asset.symbol} />
              </span>
              <span className={`font-nums text-xs ${isUp ? "text-emerald" : "text-bearish"}`}>
                {isUp ? "+" : ""}
                {quote.changePercent24h.toFixed(2)}%
              </span>
            </div>
          );
        })}
      </div>
      <style>{`
        @keyframes scroll {
          from { transform: translateX(0); }
          to { transform: translateX(-50%); }
        }
      `}</style>
    </div>
  );
}
