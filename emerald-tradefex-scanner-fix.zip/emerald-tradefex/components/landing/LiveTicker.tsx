import { MarketDataService } from "@/lib/services/marketDataService";
import { LiveTickerStrip } from "@/components/landing/LiveTickerStrip";

export function LiveTicker() {
  const snapshots = MarketDataService.getAllSnapshots();
  return <LiveTickerStrip snapshots={snapshots} />;
}
