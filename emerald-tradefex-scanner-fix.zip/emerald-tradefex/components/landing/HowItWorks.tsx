const STEPS = [
  { n: "01", title: "Live market data", body: "Price, volume and structure stream in across forex, commodities, indices and crypto." },
  { n: "02", title: "AI analysis", body: "Technicals, sentiment and macro events are scored and weighted against historical patterns." },
  { n: "03", title: "Probability forecast", body: "The model outputs a direction, a confidence score and an expected range — with its reasoning attached." },
  { n: "04", title: "Your decision", body: "You weigh the scenario against your own read of the market. The AI informs; it doesn't decide for you." }
];

export function HowItWorks() {
  return (
    <section className="border-y border-surface-border bg-surface/40">
      <div className="mx-auto max-w-[1200px] px-6 py-20">
        <h2 className="mb-12 font-display text-3xl font-semibold text-ink">From raw data to a reasoned forecast</h2>
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {STEPS.map((step) => (
            <div key={step.n}>
              <div className="font-display text-sm text-emerald">{step.n}</div>
              <h3 className="mt-3 font-display text-base font-medium text-ink">{step.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-ink-muted">{step.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
