import Link from "next/link";

export function Footer() {
  return (
    <footer className="border-t border-surface-border">
      <div className="mx-auto max-w-[1200px] px-6 py-10">
        <div className="flex flex-col justify-between gap-6 sm:flex-row sm:items-center">
          <div className="flex items-center gap-2 font-display text-sm font-semibold text-ink">
            <span className="h-2 w-2 rounded-full bg-emerald" />
            Emerald TradeFeX
          </div>
          <Link href="/dashboard" className="text-sm text-ink-muted hover:text-ink">
            Enter the platform →
          </Link>
        </div>
        <p className="mt-6 max-w-2xl text-xs leading-relaxed text-ink-faint">
          Emerald TradeFeX provides AI-generated market analysis and probability-based forecasts. It does not
          guarantee profits, accuracy, or risk-free outcomes. Trading involves risk, including the risk of loss.
          AI-generated analysis. Not financial advice.
        </p>
      </div>
    </footer>
  );
}
