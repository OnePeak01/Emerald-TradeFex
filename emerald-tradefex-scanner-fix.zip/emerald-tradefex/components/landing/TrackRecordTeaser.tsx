import { TrackRecordService } from "@/lib/services/trackRecordService";

export function TrackRecordTeaser() {
  const stats = TrackRecordService.computeStats();

  return (
    <section className="mx-auto max-w-[1200px] px-6 py-20">
      <div className="grid grid-cols-1 gap-10 lg:grid-cols-[1fr_1.1fr] lg:items-center">
        <div>
          <h2 className="font-display text-3xl font-semibold text-ink">A track record, not a promise</h2>
          <p className="mt-3 max-w-md text-ink-muted">
            Every prediction Emerald TradeFeX has made is stored and graded once the outcome is known. These
            numbers are calculated from that history, updated continuously — not a fixed claim.
          </p>
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          {[
            { label: "Overall Accuracy", value: `${stats.overallAccuracy}%` },
            { label: "Avg. Confidence", value: `${stats.averageConfidence}%` },
            { label: "Predictions Tracked", value: `${stats.predictionCount}` },
            { label: "Max Drawdown", value: `${stats.maxDrawdownPercent}%` }
          ].map((s) => (
            <div key={s.label} className="glass-panel rounded-xl p-5">
              <div className="font-nums font-display text-2xl font-semibold text-ink">{s.value}</div>
              <div className="mt-1 text-xs text-ink-faint">{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
