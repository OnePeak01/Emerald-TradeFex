"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Bell, X } from "lucide-react";
import { AlertItem } from "@/lib/services/mock/mockAncillaryData";

function timeAgo(iso: string) {
  const minutes = Math.round((Date.now() - +new Date(iso)) / 60_000);
  if (minutes < 60) return `${minutes}m ago`;
  return `${Math.round(minutes / 60)}h ago`;
}

export function NotificationsMenu({ alerts }: { alerts: AlertItem[] }) {
  const [open, setOpen] = useState(false);
  // Kept mounted slightly longer than `open` so the closing transition can
  // finish before the panel leaves the DOM, instead of snapping away.
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    if (open) {
      setMounted(true);
      return;
    }
    const t = setTimeout(() => setMounted(false), 250);
    return () => clearTimeout(t);
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open]);

  const unread = alerts.length;

  return (
    <>
      <button
        aria-label="Notifications"
        onClick={() => setOpen(true)}
        className="relative text-ink-muted transition-colors hover:text-ink"
      >
        <Bell size={18} />
        {unread > 0 && (
          <span className="absolute -right-1.5 -top-1.5 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-emerald px-1 font-nums text-[10px] font-semibold leading-none text-base shadow-glow">
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </button>

      {mounted && (
        <div
          className={`fixed inset-0 z-50 flex justify-end bg-black/60 transition-opacity duration-200 ease-out ${
            open ? "opacity-100" : "opacity-0"
          }`}
          onClick={() => setOpen(false)}
        >
          <div
            className={`flex h-full w-full flex-col border-l border-surface-border bg-base transition-transform duration-250 ease-signature sm:max-w-md ${
              open ? "translate-x-0" : "translate-x-full"
            }`}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-surface-border px-5 py-4">
              <div>
                <h2 className="font-display text-lg font-semibold text-ink">Alert Center</h2>
                <p className="text-xs text-ink-faint">Confidence changes, breakouts, and events across your markets.</p>
              </div>
              <button
                aria-label="Close"
                onClick={() => setOpen(false)}
                className="flex h-9 w-9 items-center justify-center rounded-full border border-surface-border text-ink-muted transition-all duration-150 hover:rotate-90 hover:text-ink"
              >
                <X size={16} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-3">
              {alerts.length === 0 && (
                <p className="py-12 text-center text-sm text-ink-muted">No alerts right now.</p>
              )}
              {alerts.map((alert, i) => (
                <Link
                  key={alert.id}
                  href={`/dashboard/predictions?symbol=${encodeURIComponent(alert.symbol)}` as any}
                  onClick={() => setOpen(false)}
                  style={{ transitionDelay: open ? `${Math.min(i, 8) * 35}ms` : "0ms" }}
                  className={`block rounded-xl px-3 py-3.5 text-sm transition-all duration-300 ease-signature hover:bg-surface-raised ${
                    open ? "translate-y-0 opacity-100" : "translate-y-1.5 opacity-0"
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <span className="font-display text-xs font-medium text-emerald">{alert.symbol}</span>
                    <span className="shrink-0 text-xs text-ink-faint">{timeAgo(alert.createdAt)}</span>
                  </div>
                  <div className="mt-1 text-[15px] text-ink">{alert.message}</div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
