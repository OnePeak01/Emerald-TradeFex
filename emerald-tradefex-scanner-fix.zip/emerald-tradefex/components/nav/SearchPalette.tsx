"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Search, X } from "lucide-react";
import { MarketDataService } from "@/lib/services/marketDataService";

export function SearchPalette() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const router = useRouter();
  const assets = useMemo(() => MarketDataService.listAssets(), []);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return assets.slice(0, 8);
    return assets.filter((a) => a.symbol.toLowerCase().includes(q) || a.name.toLowerCase().includes(q)).slice(0, 8);
  }, [assets, query]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setOpen((v) => !v);
      }
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);

  const go = (symbol: string) => {
    setOpen(false);
    setQuery("");
    router.push(`/dashboard/predictions?symbol=${encodeURIComponent(symbol)}`);
  };

  return (
    <>
      <button
        aria-label="Search"
        onClick={() => setOpen(true)}
        className="text-ink-muted transition-colors hover:text-ink"
      >
        <Search size={18} />
      </button>

      {open && (
        <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/60 pt-24" onClick={() => setOpen(false)}>
          <div
            className="glass-panel w-full max-w-lg overflow-hidden rounded-xl shadow-panel"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3 border-b border-surface-border px-4 py-3">
              <Search size={16} className="text-ink-faint" />
              <input
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search assets — EUR/USD, Gold, Bitcoin…"
                className="flex-1 bg-transparent text-sm text-ink outline-none placeholder:text-ink-faint"
              />
              <button onClick={() => setOpen(false)} className="text-ink-faint hover:text-ink">
                <X size={16} />
              </button>
            </div>
            <div className="max-h-80 overflow-y-auto p-1.5">
              {results.length === 0 && <div className="px-3 py-6 text-center text-sm text-ink-muted">No matches.</div>}
              {results.map((a) => (
                <button
                  key={a.symbol}
                  onClick={() => go(a.symbol)}
                  className="flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-left text-sm transition-colors hover:bg-surface-raised"
                >
                  <span className="font-medium text-ink">{a.symbol}</span>
                  <span className="text-xs text-ink-faint">{a.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
