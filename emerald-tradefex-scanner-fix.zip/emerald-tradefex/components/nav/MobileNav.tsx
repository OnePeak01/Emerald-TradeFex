import Link from "next/link";
import { Bell, Home, LineChart, Sparkles, User } from "lucide-react";

const ITEMS = [
  { href: "/dashboard", label: "Home", icon: Home },
  { href: "/dashboard/scanner", label: "Markets", icon: LineChart },
  { href: "/dashboard/predictions", label: "AI", icon: Sparkles },
  { href: "/dashboard/watchlist", label: "Alerts", icon: Bell },
  { href: "/dashboard/profile", label: "Profile", icon: User }
];

export function MobileNav() {
  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-40 flex justify-around border-t border-surface-border bg-base/95 py-2 backdrop-blur lg:hidden"
      style={{ paddingBottom: "max(0.5rem, env(safe-area-inset-bottom))" }}
    >
      {ITEMS.map(({ href, label, icon: Icon }) => (
        <Link key={href} href={href as any} className="flex flex-col items-center gap-1 px-3 py-1 text-ink-muted">
          <Icon size={20} />
          <span className="text-[10px]">{label}</span>
        </Link>
      ))}
    </nav>
  );
}
