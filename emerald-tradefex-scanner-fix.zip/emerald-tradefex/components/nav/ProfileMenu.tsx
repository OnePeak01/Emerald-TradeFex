"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { LogOut, User } from "lucide-react";
import { signOut } from "@/lib/actions/auth";

export function ProfileMenu({ user }: { user: { email: string; displayName: string } | null }) {
  const [open, setOpen] = useState(false);
  const [mounted, setMounted] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open) {
      setMounted(true);
      return;
    }
    const t = setTimeout(() => setMounted(false), 150);
    return () => clearTimeout(t);
  }, [open]);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  return (
    <div className="relative" ref={ref}>
      <button
        aria-label="Profile"
        onClick={() => setOpen((v) => !v)}
        className="relative flex h-8 w-8 items-center justify-center rounded-full border border-surface-border bg-surface-raised text-ink-muted transition-all duration-150 hover:scale-105 hover:text-ink"
      >
        <User size={16} />
        {user && <span className="absolute -bottom-0.5 -right-0.5 h-2 w-2 rounded-full border border-base bg-emerald" />}
      </button>

      {mounted && (
        <div
          className={`glass-panel absolute right-0 top-11 z-50 w-56 origin-top-right rounded-xl p-1.5 shadow-panel transition-all duration-150 ease-signature ${
            open ? "translate-y-0 scale-100 opacity-100" : "-translate-y-1 scale-95 opacity-0"
          }`}
        >
          {user ? (
            <>
              <div className="px-3 py-2">
                <div className="truncate text-sm font-medium text-ink">{user.displayName}</div>
                <div className="truncate text-xs text-ink-faint">{user.email}</div>
              </div>
              <div className="my-1 h-px bg-surface-border" />
              <Link
                href="/dashboard/profile"
                onClick={() => setOpen(false)}
                className="block rounded-lg px-3 py-2 text-sm text-ink-muted transition-colors hover:bg-surface-raised hover:text-ink"
              >
                View profile
              </Link>
              <form action={signOut}>
                <button
                  type="submit"
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm text-ink-muted transition-colors hover:bg-surface-raised hover:text-ink"
                >
                  <LogOut size={14} /> Sign out
                </button>
              </form>
            </>
          ) : (
            <div className="p-1.5">
              <div className="px-3 pb-2 pt-1 text-xs text-ink-faint">Sign in to save your watchlist and alerts.</div>
              <Link
                href="/auth/login"
                onClick={() => setOpen(false)}
                className="block rounded-lg px-3 py-2 text-sm text-ink transition-colors hover:bg-surface-raised"
              >
                Sign in
              </Link>
              <Link
                href="/auth/signup"
                onClick={() => setOpen(false)}
                className="block rounded-lg px-3 py-2 text-sm font-medium text-emerald transition-colors hover:bg-surface-raised"
              >
                Create an account
              </Link>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
