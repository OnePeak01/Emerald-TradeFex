import Link from "next/link";
import { AlertItem } from "@/lib/services/mock/mockAncillaryData";
import { SearchPalette } from "@/components/nav/SearchPalette";
import { NotificationsMenu } from "@/components/nav/NotificationsMenu";
import { ProfileMenu } from "@/components/nav/ProfileMenu";
import { BrandLogo } from "@/components/ui/BrandLogo";

const LINKS = [
  { href: "/dashboard", label: "Markets" },
  { href: "/dashboard/predictions", label: "AI Predictions" },
  { href: "/dashboard/scanner", label: "AI Scanner" },
  { href: "/dashboard/sentiment", label: "Sentiment" },
  { href: "/dashboard/calendar", label: "Economic Calendar" },
  { href: "/dashboard/backtesting", label: "Backtesting" },
  { href: "/dashboard/watchlist", label: "Watchlist" },
  { href: "/dashboard/track-record", label: "Track Record" }
];

export function TopNav({
  user,
  alerts
}: {
  user: { email: string; displayName: string } | null;
  alerts: AlertItem[];
}) {
  return (
    <header className="sticky top-0 z-40 border-b border-surface-border bg-base/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-[1600px] items-center gap-8 px-6">
        <BrandLogo href="/dashboard" />

        <nav className="hidden flex-1 items-center gap-6 lg:flex">
          {LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href as any}
              className="text-[13px] font-medium text-ink-muted transition-colors hover:text-ink"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-4 text-ink-muted">
          <SearchPalette />
          <NotificationsMenu alerts={alerts} />
          <ProfileMenu user={user} />
        </div>
      </div>
    </header>
  );
}
