"use client";

import { useEffect, useRef } from "react";

// Trading-flavoured glyphs: compact enough to read as data rather than
// a literal hacker effect. The renderer is intentionally sparse and dim.
const GLYPHS = "01ABCDEFGHJKLMNPQRSTUVWXYZ$€¥£%+-×÷=<>[]{}";

export function MatrixRain() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d", { alpha: true });
    if (!ctx) return;

    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let raf = 0;
    let lastTime = 0;
    let width = 0;
    let height = 0;
    let dpr = 1;
    let fontSize = 16;
    let columns = 0;
    let drops: number[] = [];
    let speeds: number[] = [];
    let lengths: number[] = [];
    let accents: boolean[] = [];
    let mobile = false;
    // Pointer position in CSS px, used to brighten + subtly speed up nearby
    // columns — a cheap way to make the rain feel responsive to the visitor
    // without any extra draw calls or DOM elements.
    let pointerX = -9999;
    let pointerY = -9999;
    let pointerActive = false;
    const POINTER_RADIUS = 220;

    const resize = () => {
      mobile = window.innerWidth < 768;
      width = window.innerWidth;
      height = window.innerHeight;
      fontSize = mobile ? 22 : 16;
      dpr = Math.min(window.devicePixelRatio || 1, mobile ? 1.5 : 2);

      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      // Wider spacing keeps the effect atmospheric and reduces work.
      columns = Math.ceil(width / fontSize);
      drops = Array.from({ length: columns }, () => Math.random() * -(height / fontSize));
      speeds = Array.from({ length: columns }, () => 0.35 + Math.random() * 0.45);
      lengths = Array.from({ length: columns }, () => 3 + Math.floor(Math.random() * 7));
      accents = Array.from({ length: columns }, () => Math.random() > 0.94);

      ctx.clearRect(0, 0, width, height);
    };

    const drawStatic = () => {
      ctx.clearRect(0, 0, width, height);
      ctx.font = `${fontSize}px ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace`;
      for (let i = 0; i < columns; i += mobile ? 2 : 1) {
        const y = Math.random() * height;
        ctx.fillStyle = accents[i] ? "rgba(79, 209, 197, 0.20)" : "rgba(31, 174, 113, 0.16)";
        ctx.fillText(GLYPHS[Math.floor(Math.random() * GLYPHS.length)], i * fontSize, y);
      }
    };

    const handlePointerMove = (e: PointerEvent) => {
      pointerX = e.clientX;
      pointerY = e.clientY;
      pointerActive = true;
    };
    const handlePointerLeave = () => {
      pointerActive = false;
    };

    resize();
    window.addEventListener("resize", resize);

    if (reduceMotion) {
      drawStatic();
      return () => window.removeEventListener("resize", resize);
    }

    if (!mobile) {
      window.addEventListener("pointermove", handlePointerMove, { passive: true });
      window.addEventListener("pointerleave", handlePointerLeave);
    }

    const frameInterval = mobile ? 90 : 72;

    const step = (time: number) => {
      raf = requestAnimationFrame(step);
      if (time - lastTime < frameInterval) return;
      lastTime = time;

      // Transparent fade keeps trails without painting a dark rectangle over
      // the other ambient layers.
      ctx.fillStyle = "rgba(10, 12, 11, 0.075)";
      ctx.fillRect(0, 0, width, height);
      ctx.font = `${fontSize}px ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace`;

      for (let i = 0; i < columns; i++) {
        if (mobile && i % 2 === 1) continue;

        const x = i * fontSize;
        const headY = drops[i] * fontSize;
        const length = lengths[i];
        const accent = accents[i];

        // Columns near the pointer glow brighter, as if the field reacts
        // to the visitor — purely additive opacity, no extra geometry.
        let boost = 0;
        if (pointerActive) {
          const dist = Math.hypot(x - pointerX, headY - pointerY);
          if (dist < POINTER_RADIUS) boost = (1 - dist / POINTER_RADIUS) * 0.55;
        }

        // Only a small fraction of columns are brighter, creating depth.
        ctx.fillStyle = accent
          ? `rgba(164, 255, 221, ${0.34 + boost})`
          : `rgba(77, 220, 150, ${0.2 + boost})`;
        ctx.fillText(GLYPHS[Math.floor(Math.random() * GLYPHS.length)], x, headY);

        for (let trail = 1; trail < length; trail++) {
          const alpha = Math.max(0.015, (length - trail) / (length * 20)) + boost * 0.4;
          ctx.fillStyle = accent
            ? `rgba(79, 209, 197, ${alpha})`
            : `rgba(31, 174, 113, ${alpha})`;
          ctx.fillText(GLYPHS[Math.floor(Math.random() * GLYPHS.length)], x, headY - trail * fontSize);
        }

        // Nearby columns fall very slightly faster, as if the pointer is
        // pulling the stream — subtle enough to read as alive, not gimmicky.
        drops[i] += speeds[i] * (1 + boost * 0.6);

        if (headY - length * fontSize > height && Math.random() > 0.965) {
          drops[i] = Math.random() * -8;
          lengths[i] = 3 + Math.floor(Math.random() * 7);
          accents[i] = Math.random() > 0.94;
          speeds[i] = 0.35 + Math.random() * 0.45;
        }
      }
    };

    raf = requestAnimationFrame(step);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("pointermove", handlePointerMove);
      window.removeEventListener("pointerleave", handlePointerLeave);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 h-full w-full opacity-100"
      style={{
        WebkitMaskImage:
          "radial-gradient(90% 90% at 50% 12%, black 0%, rgba(0,0,0,.92) 45%, transparent 100%)",
        maskImage:
          "radial-gradient(90% 90% at 50% 12%, black 0%, rgba(0,0,0,.92) 45%, transparent 100%)",
      }}
    />
  );
}
