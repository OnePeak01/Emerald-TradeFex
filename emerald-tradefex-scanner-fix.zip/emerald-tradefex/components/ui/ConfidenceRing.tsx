"use client";

import { useEffect, useState } from "react";

export function ConfidenceRing({
  value,
  size = 96,
  label
}: {
  value: number;
  size?: number;
  label?: string;
}) {
  const [animated, setAnimated] = useState(0);
  const radius = size / 2 - 8;
  const circumference = 2 * Math.PI * radius;

  useEffect(() => {
    const raf = requestAnimationFrame(() => setAnimated(value));
    return () => cancelAnimationFrame(raf);
  }, [value]);

  const offset = circumference - (animated / 100) * circumference;
  const color = value >= 75 ? "#1FAE71" : value >= 50 ? "#C9A65B" : "#D9605C";

  return (
    <div className="relative inline-flex flex-col items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="#232823" strokeWidth={7} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={7}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 900ms cubic-bezier(0.22, 1, 0.36, 1)" }}
        />
      </svg>
      <div className="absolute flex flex-col items-center">
        <span className="font-display font-nums text-2xl font-semibold text-ink">{Math.round(animated)}</span>
        {label && <span className="text-[10px] text-ink-muted">{label}</span>}
      </div>
    </div>
  );
}
