import type { CSSProperties } from "react";

// Sparse, elegant "AI data node" dots plus a faint scanline sweep.
// Pure CSS transforms/opacity (see .ambient-node / .ambient-scanline in
// globals.css) — no canvas, no rAF loop, negligible CPU cost, and
// automatically disabled under prefers-reduced-motion.
const NODES = [
  { x: "12%", y: "18%", size: 2.5, o: 0.4, dur: 13, delay: 0, dx: 8, dy: -6, color: "emerald" },
  { x: "78%", y: "10%", size: 2, o: 0.3, dur: 16, delay: 1.2, dx: -6, dy: 8, color: "cyan" },
  { x: "34%", y: "62%", size: 1.5, o: 0.28, dur: 19, delay: 2.5, dx: 5, dy: 5, color: "emerald" },
  { x: "88%", y: "48%", size: 2, o: 0.32, dur: 15, delay: 0.6, dx: -8, dy: -4, color: "emerald" },
  { x: "58%", y: "80%", size: 1.5, o: 0.25, dur: 21, delay: 3.4, dx: 4, dy: -7, color: "cyan" },
  { x: "6%", y: "76%", size: 2, o: 0.3, dur: 17, delay: 1.8, dx: 6, dy: 6, color: "emerald" },
  { x: "48%", y: "30%", size: 1.5, o: 0.22, dur: 20, delay: 4.1, dx: -5, dy: 5, color: "emerald" },
];

const DOT_COLOR: Record<string, string> = {
  emerald: "rgba(79,209,168,0.9)",
  cyan: "rgba(79,209,197,0.9)",
};

export function DataNodes() {
  return (
    <div aria-hidden className="absolute inset-0">
      {NODES.map((n, i) => (
        <span
          key={i}
          className="ambient-node absolute rounded-full"
          style={
            {
              left: n.x,
              top: n.y,
              width: n.size,
              height: n.size,
              backgroundColor: DOT_COLOR[n.color],
              boxShadow: `0 0 ${n.size * 3}px ${DOT_COLOR[n.color]}`,
              "--node-o": n.o,
              "--node-dur": `${n.dur}s`,
              "--node-delay": `${n.delay}s`,
              "--node-dx": `${n.dx}px`,
              "--node-dy": `${n.dy}px`,
            } as CSSProperties
          }
        />
      ))}
      {/* Faint horizontal scan-line, barely visible, slow vertical sweep */}
      <div
        className="ambient-scanline absolute inset-x-0 h-px opacity-[0.06]"
        style={{
          background:
            "linear-gradient(90deg, transparent, rgba(79,209,197,0.9), transparent)",
        }}
      />
    </div>
  );
}
