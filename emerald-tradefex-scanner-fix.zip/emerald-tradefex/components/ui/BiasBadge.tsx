import clsx from "clsx";
import { TrendingDown, TrendingUp, Minus } from "lucide-react";
import { Bias } from "@/lib/types";

const STYLES: Record<Bias, string> = {
  BULLISH: "bg-emerald-dim text-emerald border-emerald/30",
  BEARISH: "bg-bearish-dim text-bearish border-bearish/30",
  NEUTRAL: "bg-surface-raised text-ink-muted border-surface-border"
};

const ICONS: Record<Bias, typeof TrendingUp> = {
  BULLISH: TrendingUp,
  BEARISH: TrendingDown,
  NEUTRAL: Minus
};

export function BiasBadge({ bias, size = "md" }: { bias: Bias; size?: "sm" | "md" }) {
  const Icon = ICONS[bias];
  return (
    <span
      className={clsx(
        "inline-flex items-center gap-1.5 rounded-full border font-medium",
        STYLES[bias],
        size === "sm" ? "px-2 py-0.5 text-xs" : "px-3 py-1 text-sm"
      )}
    >
      <Icon size={size === "sm" ? 12 : 14} strokeWidth={2.5} />
      {bias}
    </span>
  );
}
