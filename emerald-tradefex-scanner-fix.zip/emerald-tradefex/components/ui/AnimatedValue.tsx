"use client";

import { useEffect, useRef, useState } from "react";
import { formatPrice } from "@/lib/services/mock/mockMarketData";

const EASE_DURATION_MS = 500;

function easeOutCubic(t: number) {
  return 1 - Math.pow(1 - t, 3);
}

export type AnimatedValueFormat = "percent" | "price" | "ratio1" | "raw";

/**
 * Renders a formatted numeric value that smoothly tweens from its previous
 * value to the next one (a "count-up/down" feel for prices, balances, P/L,
 * confidence, etc.) and briefly tints green/red while it's moving — the
 * "numbers feel alive" treatment. Purely visual: no layout shift.
 *
 * Falls back to an instant snap on first mount (nothing to animate from)
 * and respects prefers-reduced-motion via the tint transition already
 * defined in globals.css; the tween itself is skipped when the OS setting
 * is on, since rAF loops aren't covered by the CSS media query.
 *
 * `formatType` (a plain string) + `symbol` replace what used to be a
 * `format` function prop. This component is a Client Component, and a
 * handful of its callers (the AI Predictions page and ScenarioCard) are
 * Server Components — React/Next.js cannot serialize a function across
 * that server → client boundary ("Functions cannot be passed directly to
 * Client Components"), which was crashing the AI Predictions page in
 * production. Every formatting need in this app reduces to one of a few
 * known kinds, so we pass the *kind* (a string) instead of the function
 * itself, and do the actual formatting in here, client-side.
 */
function formatValue(value: number, formatType: AnimatedValueFormat, symbol?: string): string {
  switch (formatType) {
    case "percent":
      return `${Math.round(value)}%`;
    case "price":
      return formatPrice(value, symbol ?? "");
    case "ratio1":
      return value.toFixed(1);
    case "raw":
    default:
      return String(value);
  }
}

export function AnimatedValue({
  value,
  formatType = "raw",
  symbol,
  className = ""
}: {
  value: number;
  formatType?: AnimatedValueFormat;
  symbol?: string;
  className?: string;
}) {
  const previous = useRef<number | null>(null);
  const [flash, setFlash] = useState<"up" | "down" | null>(null);
  const [displayed, setDisplayed] = useState(value);
  const resetTimeout = useRef<ReturnType<typeof setTimeout>>();
  const rafRef = useRef<number>();
  const reducedMotion = useRef(false);

  useEffect(() => {
    reducedMotion.current =
      typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }, []);

  useEffect(() => {
    const prev = previous.current;

    if (prev === null) {
      // First render: nothing to tween from, just show it.
      setDisplayed(value);
      previous.current = value;
      return;
    }

    if (value === prev) return;

    setFlash(value > prev ? "up" : "down");
    if (resetTimeout.current) clearTimeout(resetTimeout.current);
    resetTimeout.current = setTimeout(() => setFlash(null), 900);

    if (rafRef.current) cancelAnimationFrame(rafRef.current);

    if (reducedMotion.current || !Number.isFinite(prev) || !Number.isFinite(value)) {
      setDisplayed(value);
      previous.current = value;
      return;
    }

    const start = performance.now();
    const from = prev;
    const to = value;

    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / EASE_DURATION_MS);
      const eased = easeOutCubic(t);
      setDisplayed(from + (to - from) * eased);
      if (t < 1) {
        rafRef.current = requestAnimationFrame(tick);
      } else {
        setDisplayed(to);
      }
    };
    rafRef.current = requestAnimationFrame(tick);
    previous.current = value;

    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  useEffect(() => {
    return () => {
      if (resetTimeout.current) clearTimeout(resetTimeout.current);
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  return (
    <span className={`value-flash inline-block px-1 -mx-1 font-nums ${flash ? `flash-${flash}` : ""} ${className}`}>
      {formatValue(displayed, formatType, symbol)}
    </span>
  );
}
