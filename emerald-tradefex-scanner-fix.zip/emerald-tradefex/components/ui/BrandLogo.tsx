"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";

const SIZE_CLASSES: Record<"sm" | "md" | "lg", string> = {
  sm: "text-[15px] gap-2",
  md: "text-[17px] gap-2.5",
  lg: "text-2xl sm:text-3xl gap-3"
};

const GLITCH_INTERVAL_MS = 7000;
const GLITCH_DURATION_MS = 650;

interface BrandLogoProps {
  /** Link destination. Pass null to render as a non-interactive brand mark. */
  href?: string | null;
  size?: "sm" | "md" | "lg";
  className?: string;
}

/**
 * The "Emerald TradeFeX" wordmark. Shared across the landing page, dashboard
 * nav and auth screens so the brand + glitch behaviour stays in one place.
 *
 * "TradeFeX" performs a short, automatic digital glitch every ~7s using
 * GPU-friendly transform/opacity/clip-path animations only (no layout
 * thrashing), and fully respects prefers-reduced-motion via the global rule
 * in globals.css.
 */
export function BrandLogo({ href = "/", size = "sm", className = "" }: BrandLogoProps) {
  const [glitching, setGlitching] = useState(false);
  const resetTimeout = useRef<ReturnType<typeof setTimeout>>();

  useEffect(() => {
    const trigger = () => {
      setGlitching(true);
      resetTimeout.current = setTimeout(() => setGlitching(false), GLITCH_DURATION_MS);
    };

    const interval = setInterval(trigger, GLITCH_INTERVAL_MS);

    return () => {
      clearInterval(interval);
      if (resetTimeout.current) clearTimeout(resetTimeout.current);
    };
  }, []);

  const mark = (
    <span
      className={`inline-flex items-center font-display font-semibold ${SIZE_CLASSES[size]} ${className}`}
    >
      <span className="relative flex h-2 w-2 shrink-0">
        <span className="absolute inset-0 rounded-full bg-emerald opacity-60 animate-ping" />
        <span className="relative h-2 w-2 rounded-full bg-emerald shadow-glow" />
      </span>
      <span className="brand-wordmark whitespace-nowrap">
        <span className="brand-emerald">Emerald</span>{" "}
        <span
          data-text="TradeFeX"
          className={`brand-tradefex${glitching ? " is-glitching" : ""}`}
        >
          TradeFeX
          <span className="brand-tradefex-scan" aria-hidden="true" />
        </span>
      </span>
    </span>
  );

  if (href) {
    return (
      <Link href={href as any} className="brand-logo-link">
        {mark}
      </Link>
    );
  }

  return mark;
}
