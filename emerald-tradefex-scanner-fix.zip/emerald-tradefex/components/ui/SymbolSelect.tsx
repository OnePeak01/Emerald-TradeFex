"use client";

import { useRouter, useSearchParams, usePathname } from "next/navigation";
import { MarketDataService } from "@/lib/services/marketDataService";

export function SymbolSelect({ symbol }: { symbol: string }) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const assets = MarketDataService.listAssets();

  return (
    <select
      value={symbol}
      onChange={(e) => {
        const params = new URLSearchParams(searchParams.toString());
        params.set("symbol", e.target.value);
        router.push(`${pathname}?${params.toString()}`);
      }}
      className="rounded-lg border border-surface-border bg-surface-raised px-3 py-2 text-sm text-ink outline-none focus-visible:border-emerald"
    >
      {assets.map((a) => (
        <option key={a.symbol} value={a.symbol}>
          {a.symbol}
        </option>
      ))}
    </select>
  );
}
