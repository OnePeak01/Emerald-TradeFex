"use client";

import { useEffect, useState } from "react";

export function StatBar({ label, score, max }: { label: string; score: number; max: number }) {
  const [width, setWidth] = useState(0);
  const pct = Math.min(100, Math.round((score / max) * 100));

  useEffect(() => {
    const raf = requestAnimationFrame(() => setWidth(pct));
    return () => cancelAnimationFrame(raf);
  }, [pct]);

  return (
    <div>
      <div className="mb-1.5 flex items-baseline justify-between text-sm">
        <span className="text-ink-muted">{label}</span>
        <span className="font-nums text-ink">
          {score} / {max}
        </span>
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-surface-raised">
        <div
          className="h-full rounded-full bg-emerald"
          style={{ width: `${width}%`, transition: "width 800ms cubic-bezier(0.22, 1, 0.36, 1)" }}
        />
      </div>
    </div>
  );
}
