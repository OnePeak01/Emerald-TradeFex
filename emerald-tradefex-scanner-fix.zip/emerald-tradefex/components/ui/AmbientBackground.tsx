import { MatrixRain } from "./MatrixRain";
import { DataNodes } from "./DataNodes";
import type { Bias } from "@/lib/types";

const SENTIMENT_TINT: Record<Bias, string> = {
  BULLISH: "rgba(31,174,113,0.16)",
  BEARISH: "rgba(217,96,92,0.13)",
  NEUTRAL: "rgba(201,166,91,0.08)"
};

/**
 * Shared ambient backdrop. This layer is deliberately independent from the
 * application UI so the trading interface remains untouched and clickable.
 *
 * `sentiment` is optional and lets a page (e.g. the landing hero) tint the
 * ambient glow toward the featured prediction's bias — a quiet signature
 * touch rather than a literal status color.
 */
export function AmbientBackground({ matrix = false, sentiment }: { matrix?: boolean; sentiment?: Bias }) {
  return (
    <div
      aria-hidden
      className="pointer-events-none fixed inset-0 -z-10 overflow-hidden bg-base"
    >
      {/* Deep atmospheric base */}
      <div className="absolute inset-0 bg-[radial-gradient(100%_70%_at_50%_-10%,rgba(31,174,113,0.10),transparent_62%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(55%_55%_at_8%_8%,rgba(31,174,113,0.11),transparent_72%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(50%_50%_at_92%_18%,rgba(79,209,197,0.07),transparent_72%)]" />

      {/* Precision grid: deliberately finer and quieter than the foreground UI. */}
      <div
        className="absolute inset-0 opacity-70"
        style={{
          backgroundImage:
            "linear-gradient(rgba(233,236,233,0.035) 1px, transparent 1px), linear-gradient(90deg, rgba(233,236,233,0.035) 1px, transparent 1px)",
          backgroundSize: "48px 48px",
          maskImage: "linear-gradient(to bottom, black, transparent 92%)",
          WebkitMaskImage: "linear-gradient(to bottom, black, transparent 92%)",
        }}
      />

      {/* Matrix code layer — behind every interactive element. */}
      {matrix && <MatrixRain />}

      {matrix && (
        <div className="absolute inset-0 bg-gradient-to-b from-base/15 via-transparent to-base/70" />
      )}

      {matrix && <DataNodes />}

      {/* Sentiment tint — a slow-breathing wash keyed to the featured
          prediction's bias, sitting well behind all UI and charts. */}
      {sentiment && (
        <div
          className="absolute inset-0 animate-drift mix-blend-screen transition-[background] duration-1000"
          style={{
            background: `radial-gradient(60% 45% at 50% 8%, ${SENTIMENT_TINT[sentiment]}, transparent 70%)`
          }}
        />
      )}

      {/* Slow ambient light movement adds depth without distracting from charts. */}
      <div className="absolute inset-0 bg-aurora-1 animate-drift mix-blend-screen opacity-70" />
      <div className="absolute inset-0 bg-aurora-2 animate-drift-slow mix-blend-screen opacity-60" />
      <div className="absolute inset-0 bg-aurora-3 opacity-70" />
      <div className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-base via-base/50 to-transparent" />

      {/* A final readability veil keeps the premium background subordinate. */}
      {matrix && (
        <div className="absolute inset-0 bg-[radial-gradient(75%_65%_at_50%_35%,transparent_35%,rgba(10,12,11,0.32)_100%)]" />
      )}
    </div>
  );
}
