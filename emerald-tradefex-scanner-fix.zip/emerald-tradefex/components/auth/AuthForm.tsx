"use client";

import { useFormState, useFormStatus } from "react-dom";
import { Mail, Lock, User } from "lucide-react";
import { signIn, signUp, AuthFormState } from "@/lib/actions/auth";

const initialState: AuthFormState = { error: null };

function SubmitButton({ label }: { label: string }) {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      disabled={pending}
      className="w-full rounded-xl bg-gradient-to-r from-emerald to-emerald-deep px-4 py-3 text-sm font-semibold text-base shadow-glow transition-all hover:shadow-glow-ring disabled:opacity-50"
    >
      {pending ? "Please wait…" : label}
    </button>
  );
}

function FieldIcon({ icon: Icon }: { icon: typeof Mail }) {
  return <Icon size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-faint" />;
}

const inputClass =
  "w-full rounded-xl border border-white/[0.08] bg-white/[0.03] py-3 pl-10 pr-3.5 text-sm text-ink outline-none transition-all placeholder:text-ink-faint/70 focus-visible:border-emerald/60 focus-visible:bg-white/[0.05] focus-visible:shadow-[0_0_0_3px_rgba(31,174,113,0.12)]";

export function AuthForm({ mode, next }: { mode: "login" | "signup"; next: string }) {
  const action = mode === "login" ? signIn : signUp;
  const [state, formAction] = useFormState(action, initialState);

  return (
    <form action={formAction} className="space-y-4">
      <input type="hidden" name="next" value={next} />

      {mode === "signup" && (
        <div>
          <label className="mb-1.5 block text-xs font-medium text-ink-faint">Display name</label>
          <div className="relative">
            <FieldIcon icon={User} />
            <input name="displayName" type="text" placeholder="Jordan Rivera" className={inputClass} />
          </div>
        </div>
      )}

      <div>
        <label className="mb-1.5 block text-xs font-medium text-ink-faint">Email</label>
        <div className="relative">
          <FieldIcon icon={Mail} />
          <input
            name="email"
            type="email"
            required
            placeholder="you@example.com"
            className={inputClass}
          />
        </div>
      </div>

      <div>
        <label className="mb-1.5 block text-xs font-medium text-ink-faint">Password</label>
        <div className="relative">
          <FieldIcon icon={Lock} />
          <input
            name="password"
            type="password"
            required
            minLength={8}
            placeholder="••••••••"
            className={inputClass}
          />
        </div>
        {mode === "signup" && <p className="mt-1.5 text-xs text-ink-faint">At least 8 characters.</p>}
      </div>

      {state.error && (
        <div className="rounded-xl border border-bearish/30 bg-bearish-dim px-3.5 py-2.5 text-sm text-bearish">
          {state.error}
        </div>
      )}

      <SubmitButton label={mode === "login" ? "Sign In" : "Create Account"} />
    </form>
  );
}
