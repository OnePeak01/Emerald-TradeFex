import Link from "next/link";
import clsx from "clsx";

export function AuthTabs({ active, next }: { active: "login" | "signup"; next: string }) {
  const suffix = next && next !== "/dashboard" ? `?next=${encodeURIComponent(next)}` : "";
  const isSignup = active === "signup";

  return (
    <div className="relative mb-7 flex rounded-full border border-white/[0.07] bg-white/[0.03] p-1 backdrop-blur-sm">
      {/* Positioned with explicit left/width (not transform), so it lines up with the
          flex track exactly regardless of engine — translate-x-full was measuring
          against the pill's own width rather than the track, which threw it off. */}
      <span
        aria-hidden
        className={clsx(
          "absolute inset-y-1 w-[calc(50%-4px)] rounded-full bg-gradient-to-r from-emerald to-emerald-deep shadow-glow transition-[left] duration-300 ease-out",
          isSignup ? "left-1/2" : "left-1"
        )}
      />
      <Link
        href={`/auth/login${suffix}` as any}
        className={clsx(
          "relative z-10 flex-1 rounded-full py-2.5 text-center text-sm font-medium transition-colors",
          !isSignup ? "text-base" : "text-ink-muted hover:text-ink"
        )}
      >
        Sign In
      </Link>
      <Link
        href={`/auth/signup${suffix}` as any}
        className={clsx(
          "relative z-10 flex-1 rounded-full py-2.5 text-center text-sm font-medium transition-colors",
          isSignup ? "text-base" : "text-ink-muted hover:text-ink"
        )}
      >
        Sign Up
      </Link>
    </div>
  );
}
