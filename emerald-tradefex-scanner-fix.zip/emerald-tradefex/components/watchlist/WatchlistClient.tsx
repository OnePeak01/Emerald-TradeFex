"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { X } from "lucide-react";
import { MarketDataService } from "@/lib/services/marketDataService";
import { formatPrice } from "@/lib/services/mock/mockMarketData";
import { Card, CardBody } from "@/components/ui/Card";
import { BiasBadge } from "@/components/ui/BiasBadge";
import { addToWatchlist, removeFromWatchlist } from "@/lib/actions/watchlist";
import { useLiveQuotes } from "@/hooks/useLiveQuotes";

export function WatchlistClient({
  initialSymbols,
  isPersisted,
  isSupabaseConfigured
}: {
  initialSymbols: string[];
  isPersisted: boolean;
  isSupabaseConfigured: boolean;
}) {
  const [symbols, setSymbols] = useState<string[]>(initialSymbols);
  const [isPending, startTransition] = useTransition();
  const allAssets = MarketDataService.listAssets();
  const addable = allAssets.filter((a) => !symbols.includes(a.symbol));

  const initialQuotes = Object.fromEntries(
    initialSymbols.map((symbol) => {
      const snapshot = MarketDataService.getSnapshot(symbol);
      return [
        symbol,
        {
          price: snapshot?.quote.price ?? 0,
          changePercent24h: snapshot?.quote.changePercent24h ?? 0,
          isLive: false
        }
      ];
    })
  );
  const live = useLiveQuotes(initialQuotes);

  const add = (symbol: string) => {
    setSymbols((s) => [...s, symbol]);
    if (isPersisted)
      startTransition(() => {
        void addToWatchlist(symbol);
      });
  };

  const remove = (symbol: string) => {
    setSymbols((s) => s.filter((sym) => sym !== symbol));
    if (isPersisted)
      startTransition(() => {
        void removeFromWatchlist(symbol);
      });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="font-display text-2xl font-semibold text-ink">My Markets</h1>
          <p className="text-sm text-ink-muted">
            Track the assets you care about. Signed-in users get alerts on confidence and trend changes.
          </p>
        </div>
        {addable.length > 0 && (
          <select
            value=""
            onChange={(e) => e.target.value && add(e.target.value)}
            className="rounded-lg border border-surface-border bg-surface-raised px-3 py-2 text-sm text-ink"
          >
            <option value="">+ Add asset</option>
            {addable.map((a) => (
              <option key={a.symbol} value={a.symbol}>
                {a.symbol}
              </option>
            ))}
          </select>
        )}
      </div>

      {!isPersisted && (
        <div className="rounded-lg border border-surface-border bg-surface-raised px-4 py-3 text-sm text-ink-muted">
          {isSupabaseConfigured ? (
            <>
              <Link href="/auth/signup" className="font-medium text-emerald hover:underline">
                Create an account
              </Link>{" "}
              to save this watchlist and get alerts across devices. For now it's stored only in this browser tab.
            </>
          ) : (
            "This watchlist is a local demo — connect Supabase to persist it per user."
          )}
        </div>
      )}

      <Card>
        <CardBody className="divide-y divide-surface-border pt-3">
          {symbols.length === 0 && <p className="py-8 text-center text-sm text-ink-muted">Your watchlist is empty.</p>}
          {symbols.map((symbol) => {
            const snapshot = MarketDataService.getSnapshot(symbol);
            if (!snapshot) return null;
            const quote = live[symbol] ?? { price: snapshot.quote.price, changePercent24h: snapshot.quote.changePercent24h, isLive: false };
            return (
              <div key={symbol} className="flex items-center justify-between py-4 first:pt-1 last:pb-1">
                <Link
                  href={`/dashboard/predictions?symbol=${encodeURIComponent(symbol)}` as any}
                  className="flex items-center gap-4"
                >
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-display text-sm font-medium text-ink">{symbol}</span>
                      {quote.isLive && <span className="h-1.5 w-1.5 rounded-full bg-emerald shadow-glow" />}
                    </div>
                    <div className="font-nums text-xs text-ink-faint">{formatPrice(quote.price, symbol)}</div>
                  </div>
                </Link>
                <div className="flex items-center gap-4">
                  <BiasBadge bias={snapshot.bias} size="sm" />
                  <span className="font-nums text-sm text-emerald">{snapshot.confidence}%</span>
                  <button
                    aria-label={`Remove ${symbol}`}
                    disabled={isPending}
                    onClick={() => remove(symbol)}
                    className="text-ink-faint transition-colors hover:text-bearish disabled:opacity-50"
                  >
                    <X size={16} />
                  </button>
                </div>
              </div>
            );
          })}
        </CardBody>
      </Card>
    </div>
  );
}
