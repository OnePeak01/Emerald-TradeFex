import { PredictionService } from "@/lib/services/predictionService";
import { formatPrice } from "@/lib/services/mock/mockMarketData";
import { BiasBadge } from "@/components/ui/BiasBadge";
import { AmbientBackground } from "@/components/ui/AmbientBackground";
import { BrandLogo } from "@/components/ui/BrandLogo";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  const prediction = PredictionService.getPrediction("XAU/USD", "4H");

  return (
    <div className="relative isolate min-h-screen overflow-hidden">
      <AmbientBackground />

      <div className="relative grid min-h-screen lg:grid-cols-[1.1fr_1fr]">
        {/* Decorative brand panel — desktop only */}
        <div className="relative hidden overflow-hidden border-r border-white/[0.06] lg:flex lg:flex-col lg:justify-between lg:p-14">
          <BrandLogo href="/" />

          <div className="max-w-md">
            <span className="mb-5 inline-block h-px w-10 bg-gradient-to-r from-emerald to-cyan" />
            <h2 className="font-display text-4xl font-semibold leading-[1.15] text-ink">
              Probability-based forecasts, reasoned in the open.
            </h2>
            <p className="mt-4 text-[15px] leading-relaxed text-ink-muted">
              Every prediction ships with the factors behind it — market structure, momentum, sentiment, and
              macro conditions — so you can check the AI's reasoning against your own.
            </p>
          </div>

          {prediction && (
            <div className="relative overflow-hidden rounded-2xl border border-white/[0.07] bg-surface/60 p-5 shadow-glow-card backdrop-blur-xl">
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-xs text-ink-faint">{prediction.symbol}</div>
                  <div className="font-nums font-display text-2xl font-semibold text-ink">
                    {formatPrice(prediction.currentPrice, prediction.symbol)}
                  </div>
                </div>
                <BiasBadge bias={prediction.direction} size="sm" />
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 border-t border-white/[0.06] pt-4 text-sm">
                <div>
                  <div className="text-xs text-ink-faint">Confidence</div>
                  <div className="font-nums font-medium text-ink">{prediction.probability}%</div>
                </div>
                <div>
                  <div className="text-xs text-ink-faint">Horizon</div>
                  <div className="font-medium text-ink">{prediction.forecastHorizon}</div>
                </div>
                <div>
                  <div className="text-xs text-ink-faint">Risk</div>
                  <div className="font-medium text-ink">{prediction.risk}</div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Auth content */}
        <div className="flex flex-col">
          <header className="px-6 py-7 lg:hidden">
            <BrandLogo href="/" />
          </header>
          <main className="flex flex-1 items-center justify-center px-6 pb-16">{children}</main>
        </div>
      </div>
    </div>
  );
}
