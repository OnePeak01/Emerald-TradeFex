import { AuthTabs } from "@/components/auth/AuthTabs";
import { AuthForm } from "@/components/auth/AuthForm";
import { GoogleAuthButton } from "@/components/auth/GoogleAuthButton";

export default function SignupPage({ searchParams }: { searchParams: { next?: string } }) {
  const next = searchParams.next ?? "/dashboard";

  return (
    <div className="w-full max-w-[400px] animate-rise-in">
      <AuthTabs active="signup" next={next} />

      <div className="relative overflow-hidden rounded-2xl border border-white/[0.08] bg-surface/50 shadow-glow-card backdrop-blur-2xl">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-emerald/70 to-transparent" />
        <div className="pointer-events-none absolute -top-24 left-1/2 h-48 w-48 -translate-x-1/2 rounded-full bg-emerald/20 blur-3xl" />

        <div className="relative px-7 pb-8 pt-8">
          <h1 className="mb-1.5 font-display text-2xl font-semibold tracking-tight text-ink">Create your account</h1>
          <p className="mb-7 text-sm leading-relaxed text-ink-muted">
            Get AI predictions, watchlists, and alerts across the full market universe.
          </p>

          <GoogleAuthButton next={next} />

          <div className="my-6 flex items-center gap-3">
            <div className="h-px flex-1 bg-gradient-to-r from-transparent via-white/10 to-white/10" />
            <span className="text-xs text-ink-faint">or continue with email</span>
            <div className="h-px flex-1 bg-gradient-to-l from-transparent via-white/10 to-white/10" />
          </div>

          <AuthForm mode="signup" next={next} />

          <p className="mt-6 text-xs leading-relaxed text-ink-faint">
            By creating an account you agree that Emerald TradeFeX provides AI-generated market analysis, not
            financial advice.
          </p>
        </div>
      </div>
    </div>
  );
}
