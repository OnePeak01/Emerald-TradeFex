import Link from "next/link";
import { MarketDataService } from "@/lib/services/marketDataService";
import { PredictionService } from "@/lib/services/predictionService";
import { HeroForecastPanel } from "@/components/landing/HeroForecastPanel";
import { LiveTicker } from "@/components/landing/LiveTicker";
import { FeatureShowcase } from "@/components/landing/FeatureShowcase";
import { HowItWorks } from "@/components/landing/HowItWorks";
import { TrackRecordTeaser } from "@/components/landing/TrackRecordTeaser";
import { Footer } from "@/components/landing/Footer";
import { AmbientBackground } from "@/components/ui/AmbientBackground";
import { BrandLogo } from "@/components/ui/BrandLogo";

export default function LandingPage() {
  const symbol = "EUR/USD";
  const prediction = PredictionService.getPrediction(symbol, "4H")!;
  const candles = MarketDataService.getCandles(symbol, "4H", 60);

  return (
    <div className="relative isolate min-h-screen">
      <AmbientBackground matrix sentiment={prediction.direction} />
      <header className="mx-auto flex max-w-[1200px] items-center justify-between px-6 py-6">
        <BrandLogo href={null} size="md" />

        <Link
          href="/auth/login"
          className="rounded-lg border border-surface-border px-4 py-2 text-sm font-medium text-ink transition-colors hover:border-emerald/40"
        >
          Sign in
        </Link>
      </header>

      <section className="mx-auto grid max-w-[1200px] grid-cols-1 items-center gap-12 px-6 pb-16 pt-8 lg:grid-cols-[1.1fr_1fr]">
        <div className="boot-sequence">
          <h1 className="font-display text-4xl font-semibold leading-[1.1] text-ink sm:text-5xl">
            AI-powered market intelligence.
          </h1>
          <p className="mt-5 max-w-lg text-[17px] leading-relaxed text-ink-muted">
            Emerald TradeFeX analyzes market structure, momentum, sentiment and macroeconomic conditions to
            generate probability-based market forecasts.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              href="/dashboard/predictions"
              className="rounded-lg bg-emerald px-5 py-3 text-sm font-medium text-base transition-opacity hover:opacity-90"
            >
              Explore AI Predictions
            </Link>
            <Link
              href="/dashboard"
              className="rounded-lg border border-surface-border px-5 py-3 text-sm font-medium text-ink transition-colors hover:border-emerald/40"
            >
              View Live Markets
            </Link>
          </div>
          <p className="mt-6 text-xs text-ink-faint">AI-generated analysis. Not financial advice. Markets involve risk.</p>
        </div>

        <div className="animate-rise-in" style={{ animationDelay: "480ms", animationFillMode: "backwards" }}>
          <HeroForecastPanel candles={candles} prediction={prediction} />
        </div>
      </section>

      <LiveTicker />
      <FeatureShowcase />
      <HowItWorks />
      <TrackRecordTeaser />
      <Footer />
    </div>
  );
}
