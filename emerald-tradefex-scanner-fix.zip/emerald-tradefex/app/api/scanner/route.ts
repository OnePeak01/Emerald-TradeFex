import { NextResponse } from "next/server";
import { ScannerService } from "@/lib/services/scannerService";

export const dynamic = "force-dynamic";

export async function GET() {
  const results = ScannerService.getTopSetups();
  return NextResponse.json({ results, generatedAt: new Date().toISOString() });
}
