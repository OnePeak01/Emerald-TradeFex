import { NextResponse } from "next/server";
import { ASSET_UNIVERSE } from "@/lib/services/mock/assetUniverse";
import { getQuote } from "@/lib/services/mock/mockMarketData";
import { fetchAllLiveQuotes } from "@/lib/services/live/liveMarketData";

export const dynamic = "force-dynamic";

export async function GET() {
  const live = await fetchAllLiveQuotes();

  const quotes = ASSET_UNIVERSE.map((asset) => {
    const liveQuote = live.get(asset.symbol);
    if (liveQuote) {
      return {
        symbol: asset.symbol,
        price: liveQuote.price,
        changePercent24h: liveQuote.changePercent,
        isLive: true
      };
    }
    const mock = getQuote(asset.symbol);
    return { symbol: asset.symbol, price: mock.price, changePercent24h: mock.changePercent24h, isLive: false };
  });

  return NextResponse.json({ quotes, fetchedAt: new Date().toISOString() });
}
