import { NextResponse } from "next/server";
import { getQuote } from "@/lib/services/mock/mockMarketData";
import { fetchLiveQuotes } from "@/lib/services/live/liveMarketData";
import { findAsset } from "@/lib/services/mock/assetUniverse";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const symbol = searchParams.get("symbol") ?? "";

  if (!findAsset(symbol)) {
    return NextResponse.json({ error: "Unknown symbol" }, { status: 404 });
  }

  const live = await fetchLiveQuotes([symbol]);
  const liveQuote = live.get(symbol);

  if (liveQuote) {
    return NextResponse.json({
      symbol,
      price: liveQuote.price,
      changePercent24h: liveQuote.changePercent,
      isLive: true,
      fetchedAt: new Date().toISOString()
    });
  }

  const mock = getQuote(symbol);
  return NextResponse.json({
    symbol,
    price: mock.price,
    changePercent24h: mock.changePercent24h,
    isLive: false,
    fetchedAt: new Date().toISOString()
  });
}
