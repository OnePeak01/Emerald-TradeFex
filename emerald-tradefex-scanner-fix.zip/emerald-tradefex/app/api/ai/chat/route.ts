import { NextResponse } from "next/server";
import { askLiveAiChat, isLiveAiChatConfigured, ChatTurn } from "@/lib/services/live/liveAiChat";
import { Prediction } from "@/lib/types";

export const dynamic = "force-dynamic";

interface ChatRequestBody {
  prediction: Prediction;
  history: ChatTurn[];
}

export async function POST(request: Request) {
  let body: ChatRequestBody;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const { prediction, history } = body;

  if (!prediction || !Array.isArray(history) || history.length === 0) {
    return NextResponse.json({ error: "Missing prediction or history" }, { status: 400 });
  }

  if (!isLiveAiChatConfigured()) {
    return NextResponse.json(
      { error: "Live AI chat is not configured. Set GEMINI_API_KEY on the server.", live: false },
      { status: 501 }
    );
  }

  try {
    const reply = await askLiveAiChat(prediction, history);
    return NextResponse.json({ reply, live: true });
  } catch (err) {
    console.error("[api/ai/chat] live AI call failed:", err);
    return NextResponse.json({ error: "AI request failed", live: false }, { status: 502 });
  }
}
