import { LiveMarketDataService } from "@/lib/services/marketDataService.server";
import { PredictionService } from "@/lib/services/predictionService";
import { LiveMarketsGrid } from "@/components/markets/LiveMarketsGrid";
import { Card, CardBody } from "@/components/ui/Card";
import { BiasBadge } from "@/components/ui/BiasBadge";
import clsx from "clsx";

export default async function CommandCenterPage() {
  const snapshots = await LiveMarketDataService.getLiveSnapshots();
  const global = PredictionService.getGlobalMarketState();

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-2xl font-semibold text-ink">TradeFeX Command Center</h1>
        <p className="text-sm text-ink-muted">Everything happening in the market right now, in one view.</p>
      </div>

      {/* Market status strip */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        <Card>
          <CardBody className="pt-5">
            <div className="text-xs text-ink-faint">Markets</div>
            <div className={clsx("mt-1 text-[15px] font-medium", global.marketsOpen ? "text-emerald" : "text-bearish")}>
              {global.marketsOpen ? "Open" : "Closed"}
            </div>
          </CardBody>
        </Card>
        <Card>
          <CardBody className="pt-5">
            <div className="text-xs text-ink-faint">Global AI Bias</div>
            <div className="mt-1.5">
              <BiasBadge bias={global.globalBias} size="sm" />
            </div>
          </CardBody>
        </Card>
        <Card>
          <CardBody className="pt-5">
            <div className="text-xs text-ink-faint">Confidence</div>
            <div className="font-nums mt-1 text-[15px] font-medium text-ink">{global.globalConfidence}%</div>
          </CardBody>
        </Card>
        <Card>
          <CardBody className="pt-5">
            <div className="text-xs text-ink-faint">Market Regime</div>
            <div className="mt-1 text-[15px] font-medium text-ink">{global.regime}</div>
          </CardBody>
        </Card>
        <Card>
          <CardBody className="pt-5">
            <div className="text-xs text-ink-faint">Volatility</div>
            <div className="mt-1 text-[15px] font-medium text-ink">{global.volatility}</div>
          </CardBody>
        </Card>
      </div>

      <LiveMarketsGrid snapshots={snapshots} />

      <p className="pt-2 text-xs text-ink-faint">
        AI-generated market analysis. Not financial advice. Markets involve risk. A green dot marks a live
        price from a real market data feed; everything else is a demo price.
      </p>
    </div>
  );
}
