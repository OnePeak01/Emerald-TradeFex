import { TrackRecordService } from "@/lib/services/trackRecordService";
import { Card, CardBody } from "@/components/ui/Card";
import { BiasBadge } from "@/components/ui/BiasBadge";

function StatCard({ label, value }: { label: string; value: string }) {
  return (
    <Card>
      <CardBody className="pt-5">
        <div className="text-xs text-ink-faint">{label}</div>
        <div className="font-nums font-display text-2xl font-semibold text-ink">{value}</div>
      </CardBody>
    </Card>
  );
}

export default function TrackRecordPage() {
  const outcomes = TrackRecordService.getOutcomes();
  const stats = TrackRecordService.computeStats(outcomes);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-ink">AI Track Record</h1>
        <p className="text-sm text-ink-muted">
          Every prediction is stored and graded once resolved. These figures are calculated from that history —
          never a fixed marketing number.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        <StatCard label="Overall Accuracy" value={`${stats.overallAccuracy}%`} />
        <StatCard label="Bullish Accuracy" value={`${stats.bullishAccuracy}%`} />
        <StatCard label="Bearish Accuracy" value={`${stats.bearishAccuracy}%`} />
        <StatCard label="Avg. Confidence" value={`${stats.averageConfidence}%`} />
        <StatCard label="Predictions Tracked" value={`${stats.predictionCount}`} />
        <StatCard label="Max Drawdown" value={`${stats.maxDrawdownPercent}%`} />
      </div>

      <Card>
        <CardBody className="pt-5">
          <div className="grid grid-cols-4 gap-4 border-b border-surface-border pb-3 text-xs text-ink-faint">
            <span>Asset</span>
            <span>Direction</span>
            <span>Confidence</span>
            <span>Outcome</span>
          </div>
          <div className="divide-y divide-surface-border">
            {outcomes.slice(0, 20).map((o) => (
              <div key={o.predictionId} className="grid grid-cols-4 items-center gap-4 py-3">
                <span className="font-display text-sm font-medium text-ink">{o.symbol}</span>
                <BiasBadge bias={o.direction} size="sm" />
                <span className="font-nums text-sm text-ink">{o.confidence}%</span>
                <span className={`text-sm font-medium ${o.outcome === "CORRECT" ? "text-emerald" : "text-bearish"}`}>
                  {o.outcome}
                </span>
              </div>
            ))}
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
