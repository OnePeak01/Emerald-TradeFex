import { EconomicCalendarService } from "@/lib/services/economicCalendarService";
import { Card, CardBody } from "@/components/ui/Card";

const IMPACT_STYLES: Record<string, string> = {
  HIGH: "text-bearish border-bearish/30 bg-bearish-dim",
  MEDIUM: "text-gold border-gold/30 bg-surface-raised",
  LOW: "text-ink-muted border-surface-border bg-surface-raised"
};

export default function EconomicCalendarPage() {
  const events = EconomicCalendarService.getUpcomingEvents();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-ink">Economic Intelligence</h1>
        <p className="text-sm text-ink-muted">Upcoming events, expected impact, and how the AI reads them.</p>
      </div>

      <div className="space-y-3">
        {events.map((event) => (
          <Card key={event.id}>
            <CardBody className="pt-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <div className="text-xs text-ink-faint">
                    {new Date(event.time).toLocaleString(undefined, {
                      weekday: "short",
                      hour: "2-digit",
                      minute: "2-digit"
                    })}{" "}
                    · {event.currency}
                  </div>
                  <h3 className="mt-1 font-display text-[15px] font-medium text-ink">{event.event}</h3>
                </div>
                <span className={`rounded-full border px-2.5 py-0.5 text-xs font-medium ${IMPACT_STYLES[event.impact]}`}>
                  {event.impact} IMPACT
                </span>
              </div>

              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div>
                  <div className="text-xs text-ink-faint">Previous</div>
                  <div className="font-nums text-ink">{event.previous}</div>
                </div>
                <div>
                  <div className="text-xs text-ink-faint">Forecast</div>
                  <div className="font-nums text-ink">{event.forecast}</div>
                </div>
                <div>
                  <div className="text-xs text-ink-faint">Actual</div>
                  <div className="font-nums text-ink">{event.actual ?? "—"}</div>
                </div>
              </div>

              <div className="mt-4 rounded-lg bg-surface-raised p-3 text-sm text-ink-muted">
                <span className="mr-2 font-medium text-cyan">AI Market Impact</span>
                {event.aiImpactNote}
              </div>
            </CardBody>
          </Card>
        ))}
      </div>
    </div>
  );
}
