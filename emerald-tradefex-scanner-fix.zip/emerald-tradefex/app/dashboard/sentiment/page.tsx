import { SentimentService } from "@/lib/services/sentimentService";
import { NewsService } from "@/lib/services/newsService";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/Card";
import { BiasBadge } from "@/components/ui/BiasBadge";
import { SymbolSelect } from "@/components/ui/SymbolSelect";
import { SentimentBars } from "@/components/predictions/SentimentBars";

function SourceRow({ label, bias }: { label: string; bias: "BULLISH" | "BEARISH" | "NEUTRAL" }) {
  return (
    <div className="flex items-center justify-between border-b border-surface-border py-2.5 last:border-0">
      <span className="text-sm text-ink-muted">{label}</span>
      <BiasBadge bias={bias} size="sm" />
    </div>
  );
}

export default function SentimentPage({ searchParams }: { searchParams: { symbol?: string } }) {
  const symbol = searchParams.symbol ?? "EUR/USD";
  const sentiment = SentimentService.getSentiment(symbol);
  const news = NewsService.getFeed();

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="font-display text-2xl font-semibold text-ink">Market Sentiment</h1>
          <p className="text-sm text-ink-muted">Technical, news, retail and macro sentiment, blended into one read.</p>
        </div>
        <SymbolSelect symbol={symbol} />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-ink text-base">{symbol}</CardTitle>
            <BiasBadge bias={sentiment.aiComposite} size="sm" />
          </CardHeader>
          <CardBody>
            <SentimentBars sentiment={sentiment} />
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-ink text-base">Sentiment Sources</CardTitle>
          </CardHeader>
          <CardBody>
            <SourceRow label="Technical Sentiment" bias={sentiment.technical} />
            <SourceRow label="News Sentiment" bias={sentiment.news} />
            <SourceRow label="Retail Sentiment" bias={sentiment.retail} />
            <SourceRow label="Macro Sentiment" bias={sentiment.macro} />
          </CardBody>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-ink text-base">AI News Analyst</CardTitle>
        </CardHeader>
        <CardBody className="divide-y divide-surface-border">
          {news.map((item) => (
            <div key={item.id} className="py-4 first:pt-0 last:pb-0">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h4 className="text-sm font-medium text-ink">{item.headline}</h4>
                <BiasBadge bias={item.sentiment} size="sm" />
              </div>
              <div className="mt-1 text-xs text-ink-faint">
                {item.source} · {new Date(item.publishedAt).toLocaleString()} · {item.affectedAssets.join(", ")}
              </div>
              <p className="mt-2 text-sm text-ink-muted">{item.aiInterpretation}</p>
              <div className="mt-1 text-xs text-ink-faint">Confidence: {item.confidence}%</div>
            </div>
          ))}
        </CardBody>
      </Card>
    </div>
  );
}
