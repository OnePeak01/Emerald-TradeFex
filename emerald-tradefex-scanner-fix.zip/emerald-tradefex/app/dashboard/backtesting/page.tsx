"use client";

import { useState } from "react";
import { LineChart, Line, ResponsiveContainer, YAxis } from "recharts";
import { BacktestService, BacktestResult } from "@/lib/services/backtestService";
import { MarketDataService } from "@/lib/services/marketDataService";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/Card";

const STRATEGIES = ["AI Momentum", "Trend Continuation", "Mean Reversion", "Breakout"];
const TIMEFRAMES = ["15M", "1H", "4H", "1D"];

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-xs text-ink-faint">{label}</div>
      <div className="font-nums text-lg font-semibold text-ink">{value}</div>
    </div>
  );
}

export default function BacktestingPage() {
  const assets = MarketDataService.listAssets();
  const [symbol, setSymbol] = useState(assets[0].symbol);
  const [strategy, setStrategy] = useState(STRATEGIES[0]);
  const [timeframe, setTimeframe] = useState("4H");
  const [startingCapital, setStartingCapital] = useState(10000);
  const [result, setResult] = useState<BacktestResult | null>(null);

  const run = () => {
    setResult(BacktestService.runBacktest({ symbol, strategy, timeframe, startingCapital }));
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-ink">TradeFeX Quant Lab</h1>
        <p className="text-sm text-ink-muted">Backtest a strategy against historical structure before you trust it.</p>
      </div>

      <Card>
        <CardBody className="grid grid-cols-1 gap-4 pt-5 sm:grid-cols-2 lg:grid-cols-5">
          <div>
            <label className="mb-1.5 block text-xs text-ink-faint">Asset</label>
            <select
              value={symbol}
              onChange={(e) => setSymbol(e.target.value)}
              className="w-full rounded-lg border border-surface-border bg-surface-raised px-3 py-2 text-sm text-ink"
            >
              {assets.map((a) => (
                <option key={a.symbol} value={a.symbol}>
                  {a.symbol}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="mb-1.5 block text-xs text-ink-faint">Strategy</label>
            <select
              value={strategy}
              onChange={(e) => setStrategy(e.target.value)}
              className="w-full rounded-lg border border-surface-border bg-surface-raised px-3 py-2 text-sm text-ink"
            >
              {STRATEGIES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="mb-1.5 block text-xs text-ink-faint">Timeframe</label>
            <select
              value={timeframe}
              onChange={(e) => setTimeframe(e.target.value)}
              className="w-full rounded-lg border border-surface-border bg-surface-raised px-3 py-2 text-sm text-ink"
            >
              {TIMEFRAMES.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="mb-1.5 block text-xs text-ink-faint">Starting Capital</label>
            <input
              type="number"
              value={startingCapital}
              onChange={(e) => setStartingCapital(Number(e.target.value))}
              className="w-full rounded-lg border border-surface-border bg-surface-raised px-3 py-2 text-sm text-ink font-nums"
            />
          </div>
          <div className="flex items-end">
            <button
              onClick={run}
              className="w-full rounded-lg bg-emerald px-4 py-2 text-sm font-medium text-base transition-opacity hover:opacity-90"
            >
              Run Backtest
            </button>
          </div>
        </CardBody>
      </Card>

      {result && (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="text-ink text-base">Equity Curve</CardTitle>
            </CardHeader>
            <CardBody className="h-[220px] pt-3">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={result.equityCurve.map((v, i) => ({ i, v }))}>
                  <YAxis hide domain={["dataMin - 100", "dataMax + 100"]} />
                  <Line type="monotone" dataKey="v" stroke="#1FAE71" strokeWidth={2} dot={false} isAnimationActive />
                </LineChart>
              </ResponsiveContainer>
            </CardBody>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-ink text-base">Results</CardTitle>
            </CardHeader>
            <CardBody className="grid grid-cols-2 gap-6 sm:grid-cols-4">
              <Stat label="Total Trades" value={`${result.totalTrades}`} />
              <Stat label="Winning Trades" value={`${result.winningTrades}`} />
              <Stat label="Losing Trades" value={`${result.losingTrades}`} />
              <Stat label="Win Rate" value={`${result.winRate}%`} />
              <Stat label="Profit Factor" value={`${result.profitFactor}`} />
              <Stat label="Net Return" value={`${result.netReturnPercent}%`} />
              <Stat label="Max Drawdown" value={`${result.maxDrawdownPercent}%`} />
              <Stat label="Avg. R:R" value={`1 : ${result.averageRR}`} />
              <Stat label="Sharpe Ratio" value={`${result.sharpeRatio}`} />
            </CardBody>
          </Card>
        </>
      )}
    </div>
  );
}
