import { ShieldCheck, LogOut, Star, Clock, Mail } from "lucide-react";
import { getCurrentUser } from "@/lib/supabase/server";
import { isSupabaseConfigured } from "@/lib/supabase/config";
import { getWatchlistSymbols } from "@/lib/actions/watchlist";
import { signOut } from "@/lib/actions/auth";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/Card";
import { GoogleAuthButton } from "@/components/auth/GoogleAuthButton";

function initialsFor(name: string) {
  return name
    .split(/[\s@.]+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join("");
}

export default async function ProfilePage() {
  const configured = isSupabaseConfigured();
  const user = configured ? await getCurrentUser() : null;

  // Logged-out state: a real CTA, never a mocked-up profile.
  if (!user) {
    return (
      <div className="mx-auto max-w-lg py-10">
        <Card className="animate-rise-in overflow-hidden">
          <div className="bg-grid-fade px-6 pb-8 pt-10 text-center">
            <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl border border-emerald/30 bg-emerald-dim text-emerald shadow-glow">
              <ShieldCheck size={26} />
            </div>
            <h1 className="font-display text-xl font-semibold text-ink">Sign in to TradeFeX</h1>
            <p className="mx-auto mt-2 max-w-sm text-sm text-ink-muted">
              Create an account to sync your watchlist, receive alerts across devices, and track your AI forecast
              history in one place.
            </p>
          </div>
          <CardBody className="space-y-3 border-t border-surface-border pt-5">
            <GoogleAuthButton next="/dashboard/profile" />
            <div className="flex items-center gap-3 text-[11px] uppercase tracking-wide text-ink-faint">
              <div className="h-px flex-1 bg-surface-border" />
              or
              <div className="h-px flex-1 bg-surface-border" />
            </div>
            <a
              href="/auth/login?next=/dashboard/profile"
              className="block rounded-xl border border-surface-border px-4 py-3 text-center text-sm font-medium text-ink transition-all duration-150 hover:border-emerald/40 hover:text-emerald"
            >
              Sign in with email
            </a>
            <a
              href="/auth/signup?next=/dashboard/profile"
              className="block rounded-xl bg-emerald px-4 py-3 text-center text-sm font-semibold text-base transition-all duration-150 hover:brightness-110"
            >
              Create an account
            </a>
          </CardBody>
        </Card>
      </div>
    );
  }

  // Logged-in state: only real session fields — nothing fabricated.
  const displayName = (user.user_metadata?.display_name as string | undefined) || user.email || "Trader";
  const provider = user.app_metadata?.provider ?? "email";
  const memberSince = user.created_at
    ? new Date(user.created_at).toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" })
    : null;
  const watchlistSymbols = await getWatchlistSymbols();

  return (
    <div className="mx-auto max-w-2xl space-y-6 py-6">
      <Card className="animate-rise-in overflow-hidden">
        <div className="bg-grid-fade flex items-center gap-4 px-6 py-8">
          <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl border border-emerald/30 bg-emerald-dim font-display text-xl font-semibold text-emerald shadow-glow">
            {initialsFor(displayName)}
          </div>
          <div className="min-w-0">
            <h1 className="truncate font-display text-xl font-semibold text-ink">{displayName}</h1>
            <div className="mt-1 flex items-center gap-1.5 text-sm text-ink-muted">
              <Mail size={13} /> <span className="truncate">{user.email}</span>
            </div>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card>
          <CardBody className="pt-5">
            <div className="text-xs text-ink-faint">Member since</div>
            <div className="mt-1 flex items-center gap-1.5 text-sm font-medium text-ink">
              <Clock size={13} className="text-emerald" /> {memberSince ?? "—"}
            </div>
          </CardBody>
        </Card>
        <Card>
          <CardBody className="pt-5">
            <div className="text-xs text-ink-faint">Sign-in method</div>
            <div className="mt-1 text-sm font-medium capitalize text-ink">{provider}</div>
          </CardBody>
        </Card>
        <Card>
          <CardBody className="pt-5">
            <div className="text-xs text-ink-faint">Watchlist</div>
            <div className="mt-1 flex items-center gap-1.5 text-sm font-medium text-ink">
              <Star size={13} className="text-gold" /> {watchlistSymbols?.length ?? 0} symbols
            </div>
          </CardBody>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-ink text-base">Account</CardTitle>
        </CardHeader>
        <CardBody className="pt-3">
          <form action={signOut}>
            <button
              type="submit"
              className="flex items-center gap-2 rounded-lg border border-surface-border px-4 py-2.5 text-sm font-medium text-ink-muted transition-all duration-150 hover:border-bearish/40 hover:text-bearish"
            >
              <LogOut size={14} /> Sign out
            </button>
          </form>
        </CardBody>
      </Card>
    </div>
  );
}
