import { getCurrentUser } from "@/lib/supabase/server";
import { isSupabaseConfigured } from "@/lib/supabase/config";
import { getWatchlistSymbols } from "@/lib/actions/watchlist";
import { WatchlistClient } from "@/components/watchlist/WatchlistClient";

const DEFAULT_WATCHLIST = ["EUR/USD", "XAU/USD", "GBP/USD", "USD/JPY"];

export default async function WatchlistPage() {
  const configured = isSupabaseConfigured();
  const user = configured ? await getCurrentUser() : null;
  const persistedSymbols = user ? await getWatchlistSymbols() : null;

  return (
    <WatchlistClient
      initialSymbols={persistedSymbols ?? DEFAULT_WATCHLIST}
      isPersisted={Boolean(user)}
      isSupabaseConfigured={configured}
    />
  );
}
