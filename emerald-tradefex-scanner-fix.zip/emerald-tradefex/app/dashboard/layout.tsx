import { TopNav } from "@/components/nav/TopNav";
import { MobileNav } from "@/components/nav/MobileNav";
import { getCurrentUser } from "@/lib/supabase/server";
import { AlertService } from "@/lib/services/alertService";
import { AmbientBackground } from "@/components/ui/AmbientBackground";

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const supabaseUser = await getCurrentUser();
  const user = supabaseUser
    ? {
        email: supabaseUser.email ?? "",
        displayName: (supabaseUser.user_metadata?.display_name as string | undefined) || supabaseUser.email || "Trader"
      }
    : null;
  const alerts = AlertService.getRecent();

  return (
    <div className="relative isolate min-h-screen">
      <AmbientBackground matrix />
      <TopNav user={user} alerts={alerts} />
      <main className="relative mx-auto max-w-[1600px] px-6 pb-24 pt-6 lg:pb-10">{children}</main>
      <MobileNav />
    </div>
  );
}
