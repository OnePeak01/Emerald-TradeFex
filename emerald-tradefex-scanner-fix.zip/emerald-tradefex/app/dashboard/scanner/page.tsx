import { ScannerService } from "@/lib/services/scannerService";
import { ScannerClient } from "@/components/predictions/ScannerClient";

export default function ScannerPage() {
  const results = ScannerService.getTopSetups();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-ink">TradeFeX AI Scanner</h1>
        <p className="text-sm text-ink-muted">
          Continuously ranked market opportunities, sorted by AI confidence.
        </p>
      </div>
      <ScannerClient results={results} />
    </div>
  );
}
