"use client";

import { useEffect } from "react";
import { AlertTriangle, RotateCw } from "lucide-react";
import { Card, CardBody } from "@/components/ui/Card";

/**
 * Route-level error boundary for /dashboard/predictions. Sits underneath
 * app/dashboard/error.tsx and takes priority for anything thrown while
 * rendering this specific route (e.g. a market-data or AI-layer failure),
 * so the rest of the dashboard shell (nav, etc.) never goes down with it.
 */
export default function PredictionsError({
  error,
  reset
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("[dashboard/predictions] route error:", error);
  }, [error]);

  return (
    <div className="py-10">
      <Card className="mx-auto max-w-lg">
        <CardBody className="flex flex-col items-center gap-3 pt-6 text-center">
          <span className="flex h-12 w-12 items-center justify-center rounded-full bg-bearish-dim text-bearish">
            <AlertTriangle size={20} />
          </span>
          <h2 className="font-display text-base font-semibold text-ink">AI service temporarily unavailable</h2>
          <p className="max-w-sm text-sm text-ink-muted">
            We're unable to generate an AI forecast right now. Please try again in a moment.
          </p>
          {error.digest && <p className="text-xs text-ink-faint">Reference: {error.digest}</p>}
          <button
            onClick={reset}
            className="mt-1 flex items-center gap-2 rounded-lg bg-emerald px-4 py-2 text-sm font-medium text-base transition-opacity hover:opacity-90"
          >
            <RotateCw size={14} /> Try again
          </button>
        </CardBody>
      </Card>
    </div>
  );
}
