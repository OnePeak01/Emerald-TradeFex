import { Timeframe } from "@/lib/types";
import { MarketDataService } from "@/lib/services/marketDataService";
import { LiveMarketDataService } from "@/lib/services/marketDataService.server";
import { PredictionService } from "@/lib/services/predictionService";
import { PredictionControls } from "@/components/predictions/PredictionControls";
import { ForecastChart } from "@/components/predictions/ForecastChart";
import { WhyTradeFexAI } from "@/components/predictions/WhyTradeFexAI";
import { ConfidenceEngine } from "@/components/predictions/ConfidenceEngine";
import { ScenarioCard } from "@/components/predictions/ScenarioCard";
import { MultiTimeframeMatrix } from "@/components/predictions/MultiTimeframeMatrix";
import { LivePriceFigure } from "@/components/predictions/LivePriceFigure";
import { BiasBadge } from "@/components/ui/BiasBadge";
import { Card, CardBody } from "@/components/ui/Card";
import { AnimatedValue } from "@/components/ui/AnimatedValue";
import { SignalCard } from "@/components/predictions/SignalCard";
import { AiMarketChat } from "@/components/predictions/AiMarketChat";

const VALID_TIMEFRAMES: Timeframe[] = ["1S", "15S", "30S", "1M", "5M", "15M", "30M", "1H", "4H", "12H", "1D", "1W"];
const DEFAULT_TIMEFRAME: Timeframe = "1S";

export default async function PredictionsPage({
  searchParams
}: {
  searchParams: { symbol?: string; timeframe?: string };
}) {
  const symbol = searchParams.symbol ?? "EUR/USD";
  const timeframe = (VALID_TIMEFRAMES.includes(searchParams.timeframe as Timeframe)
    ? searchParams.timeframe
    : DEFAULT_TIMEFRAME) as Timeframe;

  const prediction = PredictionService.getPrediction(symbol, timeframe);
  const candles = MarketDataService.getCandles(symbol, timeframe, 120);
  const consensus = PredictionService.getMultiTimeframeConsensus(symbol);
  const liveQuote = await LiveMarketDataService.getLiveQuote(symbol);

  if (!prediction) {
    return (
      <div className="py-20 text-center text-ink-muted">Unknown asset symbol. Choose one from the list above.</div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="font-display text-2xl font-semibold text-ink">AI Predictions</h1>
          <p className="text-sm text-ink-muted">Probability-based forecasts generated from live market structure.</p>
        </div>
        <PredictionControls symbol={symbol} timeframe={timeframe} />
      </div>

      {/* Forecast header */}
      <Card>
        <CardBody className="grid grid-cols-2 gap-6 pt-5 sm:grid-cols-3 lg:grid-cols-6">
          <div>
            <LivePriceFigure
              symbol={symbol}
              initialPrice={liveQuote.price}
              initialChangePercent24h={liveQuote.changePercent24h}
            />
          </div>
          <div>
            <div className="text-xs text-ink-faint">AI Forecast</div>
            <BiasBadge bias={prediction.direction} size="sm" />
          </div>
          <div>
            <div className="text-xs text-ink-faint">Probability</div>
            <div className="font-nums text-xl font-semibold text-ink">
              <AnimatedValue value={prediction.probability} formatType="percent" />
            </div>
          </div>
          <div>
            <div className="text-xs text-ink-faint">Forecast Horizon</div>
            <div className="text-[15px] font-medium text-ink">{prediction.forecastHorizon}</div>
          </div>
          <div>
            <div className="text-xs text-ink-faint">Expected Range</div>
            <div className="font-nums text-[15px] font-medium text-ink">
              <AnimatedValue value={prediction.expectedRange[0]} formatType="price" symbol={symbol} />
              {" – "}
              <AnimatedValue value={prediction.expectedRange[1]} formatType="price" symbol={symbol} />
            </div>
          </div>
          <div>
            <div className="text-xs text-ink-faint">Risk</div>
            <div className="text-[15px] font-medium text-ink">{prediction.risk}</div>
          </div>
        </CardBody>
      </Card>

      {/* Chart */}
      <Card>
        <CardBody className="pt-5">
          <div className="mb-4 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm">
            <span className="text-ink-muted">
              Bullish Probability <span className="font-nums font-medium text-emerald">{prediction.probability}%</span>
            </span>
            <span className="text-ink-muted">
              Bearish Scenario{" "}
              <span className="font-nums font-medium text-bearish">{100 - prediction.probability}%</span>
            </span>
            <span className="text-ink-muted">
              Market Regime <span className="font-medium text-ink">{prediction.regime}</span>
            </span>
          </div>
          <ForecastChart candles={candles} prediction={prediction} timeframe={timeframe} />
        </CardBody>
      </Card>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <WhyTradeFexAI prediction={prediction} />
        <ConfidenceEngine prediction={prediction} />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <ScenarioCard prediction={prediction} />
        <MultiTimeframeMatrix
          symbol={symbol}
          consensus={consensus}
          overallBias={prediction.direction}
          overallConfidence={prediction.probability}
        />
      </div>

      <SignalCard prediction={prediction} />

      <AiMarketChat prediction={prediction} />
    </div>
  );
}
