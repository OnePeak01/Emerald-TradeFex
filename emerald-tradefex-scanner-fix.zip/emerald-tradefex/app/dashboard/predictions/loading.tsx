import { Card, CardBody } from "@/components/ui/Card";

function Pulse({ className = "" }: { className?: string }) {
  return <div className={`animate-pulse rounded-md bg-surface-raised ${className}`} />;
}

export default function PredictionsLoading() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div className="space-y-2">
          <Pulse className="h-7 w-48" />
          <Pulse className="h-4 w-72" />
        </div>
        <Pulse className="h-10 w-64" />
      </div>

      <Card>
        <CardBody className="grid grid-cols-2 gap-6 pt-5 sm:grid-cols-3 lg:grid-cols-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="space-y-2">
              <Pulse className="h-3 w-16" />
              <Pulse className="h-5 w-20" />
            </div>
          ))}
        </CardBody>
      </Card>

      <Card>
        <CardBody className="pt-5">
          <Pulse className="h-[420px] w-full" />
        </CardBody>
      </Card>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card>
          <CardBody className="pt-5">
            <Pulse className="h-40 w-full" />
          </CardBody>
        </Card>
        <Card>
          <CardBody className="pt-5">
            <Pulse className="h-40 w-full" />
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
