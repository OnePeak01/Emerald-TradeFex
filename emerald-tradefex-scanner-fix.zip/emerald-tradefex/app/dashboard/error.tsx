"use client";

import { useEffect } from "react";
import { AlertTriangle, RotateCw } from "lucide-react";

/**
 * Segment-level error boundary for everything under /dashboard.
 *
 * This is a safety net, not a substitute for fixing root causes: it exists
 * so that if something unexpected throws (a bad response, a dependency
 * hiccup, anything we didn't anticipate), the user sees a themed recovery
 * screen with a way back in, instead of the generic Next.js
 * "Application error" page with no way to proceed.
 */
export default function DashboardError({
  error,
  reset
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("[dashboard] segment error:", error);
  }, [error]);

  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 px-6 text-center">
      <span className="flex h-12 w-12 items-center justify-center rounded-full bg-bearish-dim text-bearish">
        <AlertTriangle size={20} />
      </span>
      <div>
        <h2 className="font-display text-lg font-semibold text-ink">Something went wrong</h2>
        <p className="mt-1 max-w-sm text-sm text-ink-muted">
          We hit an unexpected error loading this page. This has been logged — please try again in a moment.
        </p>
        {error.digest && <p className="mt-2 text-xs text-ink-faint">Reference: {error.digest}</p>}
      </div>
      <button
        onClick={reset}
        className="mt-2 flex items-center gap-2 rounded-lg bg-emerald px-4 py-2 text-sm font-medium text-base transition-opacity hover:opacity-90"
      >
        <RotateCw size={14} /> Try again
      </button>
    </div>
  );
}
