import type { Metadata } from "next";
import { Inter, Manrope } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });
const manrope = Manrope({ subsets: ["latin"], variable: "--font-manrope", display: "swap" });

export const metadata: Metadata = {
  title: "Emerald TradeFeX — Predict. Analyze. Trade Smarter.",
  description:
    "AI-powered market intelligence. Emerald TradeFeX analyzes market structure, momentum, sentiment and macroeconomic conditions to generate probability-based market forecasts."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${inter.variable} ${manrope.variable}`}>
      <body className="bg-base text-ink antialiased">{children}</body>
    </html>
  );
}
