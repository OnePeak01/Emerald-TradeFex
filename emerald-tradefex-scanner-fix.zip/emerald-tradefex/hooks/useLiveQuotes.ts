"use client";

import { useEffect, useState } from "react";

// How often we hit the live API (respects free-tier rate limits — Twelve
// Data's free plan allows 8 requests/minute; a single batched call every
// 20s is well inside that for one visitor).
const POLL_MS = 20_000;
// How often we nudge the displayed price between polls, purely cosmetic,
// so the UI never looks static even though the underlying data hasn't
// actually refreshed yet.
const TICK_MS = 1_400;
// Max jitter per tick, as a fraction of price. Small enough to never
// meaningfully drift from the last real quote.
const JITTER_FRACTION = 0.00012;

export interface LiveQuoteState {
  price: number;
  changePercent24h: number;
  isLive: boolean;
}

function jitter(price: number) {
  const delta = price * JITTER_FRACTION * (Math.random() * 2 - 1);
  return price + delta;
}

/** Ticking price + 24h change for every asset, keyed by symbol. */
export function useLiveQuotes(initial: Record<string, LiveQuoteState>) {
  const [quotes, setQuotes] = useState(initial);

  useEffect(() => {
    let cancelled = false;

    const poll = async () => {
      try {
        const res = await fetch("/api/market/quotes", { cache: "no-store" });
        if (!res.ok || cancelled) return;
        const data = await res.json();
        const next: Record<string, LiveQuoteState> = {};
        for (const q of data.quotes ?? []) {
          next[q.symbol] = { price: q.price, changePercent24h: q.changePercent24h, isLive: q.isLive };
        }
        if (!cancelled) setQuotes(next);
      } catch {
        // Offline or rate-limited — keep ticking around the last anchor.
      }
    };

    poll(); // don't wait a full interval for the first real update
    const pollId = setInterval(poll, POLL_MS);

    const tickId = setInterval(() => {
      setQuotes((prev) => {
        const next: Record<string, LiveQuoteState> = {};
        for (const symbol of Object.keys(prev)) {
          next[symbol] = { ...prev[symbol], price: jitter(prev[symbol].price) };
        }
        return next;
      });
    }, TICK_MS);

    return () => {
      cancelled = true;
      clearInterval(pollId);
      clearInterval(tickId);
    };
  }, []);

  return quotes;
}

/** Ticking price + 24h change for a single asset. */
export function useLiveQuote(symbol: string, initial: LiveQuoteState) {
  const [quote, setQuote] = useState(initial);

  useEffect(() => {
    setQuote(initial);
    let cancelled = false;

    const poll = async () => {
      try {
        const res = await fetch(`/api/market/quote?symbol=${encodeURIComponent(symbol)}`, { cache: "no-store" });
        if (!res.ok || cancelled) return;
        const data = await res.json();
        if (!cancelled && typeof data.price === "number") {
          setQuote({ price: data.price, changePercent24h: data.changePercent24h, isLive: data.isLive });
        }
      } catch {
        // keep last known value
      }
    };

    poll(); // don't wait a full interval for the first real update
    const pollId = setInterval(poll, POLL_MS);
    const tickId = setInterval(() => {
      setQuote((prev) => ({ ...prev, price: jitter(prev.price) }));
    }, TICK_MS);

    return () => {
      cancelled = true;
      clearInterval(pollId);
      clearInterval(tickId);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [symbol]);

  return quote;
}
