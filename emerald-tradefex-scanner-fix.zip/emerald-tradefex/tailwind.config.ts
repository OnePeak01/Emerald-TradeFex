import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        base: {
          DEFAULT: "#0A0C0B",
          raised: "#0F1210"
        },
        surface: {
          DEFAULT: "#121512",
          raised: "#171B18",
          border: "#232823"
        },
        emerald: {
          DEFAULT: "#1FAE71",
          deep: "#0F6E48",
          dim: "#123A29"
        },
        cyan: {
          DEFAULT: "#4FD1C5"
        },
        gold: {
          DEFAULT: "#C9A65B"
        },
        bearish: {
          DEFAULT: "#D9605C",
          dim: "#3A2321"
        },
        ink: {
          DEFAULT: "#E9ECE9",
          muted: "#8B948E",
          faint: "#5B6360"
        }
      },
      fontFamily: {
        display: ["var(--font-manrope)", "system-ui", "sans-serif"],
        body: ["var(--font-inter)", "system-ui", "sans-serif"]
      },
      boxShadow: {
        panel: "0 1px 0 0 rgba(255,255,255,0.03) inset, 0 12px 30px -18px rgba(0,0,0,0.6)",
        glow: "0 0 0 1px rgba(31,174,113,0.25), 0 0 24px -4px rgba(31,174,113,0.35)",
        "glow-card":
          "0 1px 0 0 rgba(255,255,255,0.04) inset, 0 0 0 1px rgba(233,236,233,0.06), 0 24px 60px -20px rgba(0,0,0,0.75)",
        "glow-ring": "0 0 0 1px rgba(31,174,113,0.4), 0 0 32px -6px rgba(79,209,197,0.35)"
      },
      backgroundImage: {
        "grid-fade":
          "linear-gradient(to bottom, rgba(31,174,113,0.06), transparent 60%)",
        "aurora-1":
          "radial-gradient(60% 50% at 20% 0%, rgba(31,174,113,0.22), transparent 70%)",
        "aurora-2":
          "radial-gradient(55% 45% at 85% 20%, rgba(79,209,197,0.16), transparent 70%)",
        "aurora-3":
          "radial-gradient(45% 40% at 50% 100%, rgba(201,166,91,0.08), transparent 70%)",
        "hairline-grid":
          "linear-gradient(rgba(233,236,233,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(233,236,233,0.05) 1px, transparent 1px)"
      },
      keyframes: {
        drift: {
          "0%, 100%": { transform: "translate3d(0,0,0) scale(1)" },
          "50%": { transform: "translate3d(2%, -3%, 0) scale(1.05)" }
        },
        "rise-in": {
          "0%": { opacity: "0", transform: "translateY(10px)" },
          "100%": { opacity: "1", transform: "translateY(0)" }
        }
      },
      animation: {
        drift: "drift 18s ease-in-out infinite",
        "drift-slow": "drift 26s ease-in-out infinite reverse",
        "rise-in": "rise-in 0.5s cubic-bezier(0.16,1,0.3,1) both"
      },
      transitionTimingFunction: {
        signature: "cubic-bezier(0.16, 1, 0.3, 1)"
      },
      transitionDuration: {
        250: "250ms"
      }
    }
  },
  plugins: []
};

export default config;
