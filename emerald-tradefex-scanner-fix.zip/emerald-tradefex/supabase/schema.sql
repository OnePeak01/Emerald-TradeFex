-- Emerald TradeFeX — Supabase schema
-- Run against a fresh Supabase project (SQL Editor, or `supabase db push`).
-- Order matters: tables reference earlier tables via foreign keys.

create extension if not exists "uuid-ossp";

-- ============================================================
-- 1. profiles — one row per authenticated user
-- ============================================================
create table profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  display_name text,
  avatar_url text,
  theme text not null default 'dark' check (theme in ('dark', 'light')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table profiles enable row level security;

create policy "Users can view their own profile"
  on profiles for select using (auth.uid() = id);
create policy "Users can update their own profile"
  on profiles for update using (auth.uid() = id);
create policy "Users can insert their own profile"
  on profiles for insert with check (auth.uid() = id);

-- Automatically create a profiles row whenever a new auth.users row is
-- created (i.e. right after sign-up), so the app never has to remember to
-- do it manually in application code.
create function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'display_name', split_part(new.email, '@', 1)));
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ============================================================
-- 2. assets — the tradable universe (reference data, public read)
-- ============================================================
create table assets (
  symbol text primary key,
  name text not null,
  asset_class text not null check (asset_class in ('forex', 'commodities', 'indices', 'crypto')),
  decimals smallint not null default 2,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

alter table assets enable row level security;
create policy "Assets are publicly readable" on assets for select using (true);

-- ============================================================
-- 3. market_prices — latest quote per asset (upserted by a price feed job)
-- ============================================================
create table market_prices (
  symbol text primary key references assets (symbol) on delete cascade,
  price numeric not null,
  change_percent_24h numeric not null default 0,
  updated_at timestamptz not null default now()
);

alter table market_prices enable row level security;
create policy "Market prices are publicly readable" on market_prices for select using (true);

create index idx_market_prices_updated_at on market_prices (updated_at desc);

-- ============================================================
-- 4. candles — OHLCV history per asset + timeframe
-- ============================================================
create table candles (
  id bigint generated always as identity primary key,
  symbol text not null references assets (symbol) on delete cascade,
  timeframe text not null check (timeframe in ('15S', '30S', '1M', '5M', '15M', '30M', '1H', '4H', '12H', '1D', '1W')),
  time timestamptz not null,
  open numeric not null,
  high numeric not null,
  low numeric not null,
  close numeric not null,
  volume numeric not null default 0,
  unique (symbol, timeframe, time)
);

alter table candles enable row level security;
create policy "Candles are publicly readable" on candles for select using (true);

create index idx_candles_symbol_tf_time on candles (symbol, timeframe, time desc);

-- ============================================================
-- 5. predictions — every AI forecast the platform has ever generated
-- ============================================================
create table predictions (
  id uuid primary key default uuid_generate_v4(),
  symbol text not null references assets (symbol) on delete cascade,
  timeframe text not null check (timeframe in ('15S', '30S', '1M', '5M', '15M', '30M', '1H', '4H', '12H', '1D', '1W')),
  direction text not null check (direction in ('BULLISH', 'BEARISH', 'NEUTRAL')),
  probability numeric not null check (probability between 0 and 100),
  confidence numeric not null check (confidence between 0 and 100),
  forecast_horizon text not null,
  expected_range_low numeric not null,
  expected_range_high numeric not null,
  risk_level text not null check (risk_level in ('LOW', 'MODERATE', 'HIGH', 'EXTREME')),
  market_regime text not null,
  factors jsonb not null,
  confidence_breakdown jsonb not null,
  scenario jsonb not null,
  explanation text not null,
  model_version text not null default 'mock-v1',
  created_at timestamptz not null default now()
);

alter table predictions enable row level security;
create policy "Predictions are publicly readable" on predictions for select using (true);

create index idx_predictions_symbol_tf_created on predictions (symbol, timeframe, created_at desc);

-- ============================================================
-- 6. prediction_outcomes — resolved result of a prediction (for track record)
-- ============================================================
create table prediction_outcomes (
  id uuid primary key default uuid_generate_v4(),
  prediction_id uuid not null references predictions (id) on delete cascade,
  outcome text not null check (outcome in ('CORRECT', 'INCORRECT', 'PENDING')),
  resolved_price numeric,
  resolved_at timestamptz not null default now(),
  unique (prediction_id)
);

alter table prediction_outcomes enable row level security;
create policy "Prediction outcomes are publicly readable" on prediction_outcomes for select using (true);

create index idx_outcomes_resolved_at on prediction_outcomes (resolved_at desc);

-- ============================================================
-- 7. technical_indicators — computed indicator snapshots per candle close
-- ============================================================
create table technical_indicators (
  id bigint generated always as identity primary key,
  symbol text not null references assets (symbol) on delete cascade,
  timeframe text not null,
  time timestamptz not null,
  rsi numeric,
  macd numeric,
  macd_signal numeric,
  ema_20 numeric,
  sma_50 numeric,
  bollinger_upper numeric,
  bollinger_lower numeric,
  support numeric,
  resistance numeric,
  unique (symbol, timeframe, time)
);

alter table technical_indicators enable row level security;
create policy "Technical indicators are publicly readable" on technical_indicators for select using (true);

create index idx_indicators_symbol_tf_time on technical_indicators (symbol, timeframe, time desc);

-- ============================================================
-- 8. market_sentiment — blended sentiment snapshot per asset
-- ============================================================
create table market_sentiment (
  id bigint generated always as identity primary key,
  symbol text not null references assets (symbol) on delete cascade,
  bullish_percent numeric not null,
  neutral_percent numeric not null,
  bearish_percent numeric not null,
  technical_bias text,
  news_bias text,
  retail_bias text,
  macro_bias text,
  ai_composite_bias text not null,
  captured_at timestamptz not null default now()
);

alter table market_sentiment enable row level security;
create policy "Market sentiment is publicly readable" on market_sentiment for select using (true);

create index idx_sentiment_symbol_captured on market_sentiment (symbol, captured_at desc);

-- ============================================================
-- 9. news — ingested news items with AI interpretation
-- ============================================================
create table news (
  id uuid primary key default uuid_generate_v4(),
  headline text not null,
  source text not null,
  url text,
  affected_assets text[] not null default '{}',
  sentiment text not null check (sentiment in ('BULLISH', 'BEARISH', 'NEUTRAL')),
  ai_interpretation text not null,
  confidence numeric not null check (confidence between 0 and 100),
  published_at timestamptz not null,
  created_at timestamptz not null default now()
);

alter table news enable row level security;
create policy "News is publicly readable" on news for select using (true);

create index idx_news_published_at on news (published_at desc);
create index idx_news_affected_assets on news using gin (affected_assets);

-- ============================================================
-- 10. economic_events — economic calendar
-- ============================================================
create table economic_events (
  id uuid primary key default uuid_generate_v4(),
  event_time timestamptz not null,
  currency text not null,
  event_name text not null,
  previous_value text,
  forecast_value text,
  actual_value text,
  impact text not null check (impact in ('LOW', 'MEDIUM', 'HIGH')),
  ai_impact_note text,
  created_at timestamptz not null default now()
);

alter table economic_events enable row level security;
create policy "Economic events are publicly readable" on economic_events for select using (true);

create index idx_economic_events_time on economic_events (event_time);

-- ============================================================
-- 11. watchlists — user-owned watchlist containers
-- ============================================================
create table watchlists (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles (id) on delete cascade,
  name text not null default 'My Markets',
  created_at timestamptz not null default now()
);

alter table watchlists enable row level security;
create policy "Users manage their own watchlists"
  on watchlists for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ============================================================
-- 12. watchlist_items — assets inside a watchlist
-- ============================================================
create table watchlist_items (
  id uuid primary key default uuid_generate_v4(),
  watchlist_id uuid not null references watchlists (id) on delete cascade,
  symbol text not null references assets (symbol) on delete cascade,
  added_at timestamptz not null default now(),
  unique (watchlist_id, symbol)
);

alter table watchlist_items enable row level security;
create policy "Users manage items in their own watchlists"
  on watchlist_items for all
  using (exists (select 1 from watchlists w where w.id = watchlist_id and w.user_id = auth.uid()))
  with check (exists (select 1 from watchlists w where w.id = watchlist_id and w.user_id = auth.uid()));

-- ============================================================
-- 13. alerts — user-owned alert rules + firing log
-- ============================================================
create table alerts (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles (id) on delete cascade,
  symbol text not null references assets (symbol) on delete cascade,
  alert_type text not null check (
    alert_type in ('CONFIDENCE_CHANGE', 'TREND_CHANGE', 'BREAKOUT', 'PREDICTION_INVALIDATED', 'ECONOMIC_EVENT')
  ),
  message text not null,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

alter table alerts enable row level security;
create policy "Users manage their own alerts"
  on alerts for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index idx_alerts_user_created on alerts (user_id, created_at desc);

-- ============================================================
-- 14. portfolios — user-owned paper portfolios (analysis only, no execution)
-- ============================================================
create table portfolios (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles (id) on delete cascade,
  name text not null default 'Paper Portfolio',
  starting_capital numeric not null default 10000,
  created_at timestamptz not null default now()
);

alter table portfolios enable row level security;
create policy "Users manage their own portfolios"
  on portfolios for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ============================================================
-- 15. positions — simulated positions inside a portfolio
-- ============================================================
create table positions (
  id uuid primary key default uuid_generate_v4(),
  portfolio_id uuid not null references portfolios (id) on delete cascade,
  symbol text not null references assets (symbol) on delete cascade,
  direction text not null check (direction in ('LONG', 'SHORT')),
  entry_price numeric not null,
  quantity numeric not null,
  status text not null default 'OPEN' check (status in ('OPEN', 'CLOSED')),
  closed_price numeric,
  opened_at timestamptz not null default now(),
  closed_at timestamptz
);

alter table positions enable row level security;
create policy "Users manage positions in their own portfolios"
  on positions for all
  using (exists (select 1 from portfolios p where p.id = portfolio_id and p.user_id = auth.uid()))
  with check (exists (select 1 from portfolios p where p.id = portfolio_id and p.user_id = auth.uid()));

create index idx_positions_portfolio on positions (portfolio_id, status);

-- ============================================================
-- 16. backtests — saved Quant Lab runs
-- ============================================================
create table backtests (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles (id) on delete cascade,
  symbol text not null references assets (symbol) on delete cascade,
  strategy text not null,
  timeframe text not null,
  start_date date not null,
  end_date date not null,
  starting_capital numeric not null,
  results jsonb not null,
  created_at timestamptz not null default now()
);

alter table backtests enable row level security;
create policy "Users manage their own backtests"
  on backtests for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index idx_backtests_user_created on backtests (user_id, created_at desc);

-- ============================================================
-- 17. ai_conversations — TradeFeX Intelligence assistant chat history
-- ============================================================
create table ai_conversations (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles (id) on delete cascade,
  role text not null check (role in ('user', 'assistant')),
  content text not null,
  context jsonb,
  created_at timestamptz not null default now()
);

alter table ai_conversations enable row level security;
create policy "Users manage their own AI conversation history"
  on ai_conversations for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index idx_ai_conversations_user_created on ai_conversations (user_id, created_at desc);

-- ============================================================
-- Seed reference data (assets only — prices/predictions are generated by
-- application services, see lib/services)
-- ============================================================
insert into assets (symbol, name, asset_class, decimals) values
  ('EUR/USD', 'Euro / US Dollar', 'forex', 5),
  ('GBP/USD', 'British Pound / US Dollar', 'forex', 5),
  ('USD/JPY', 'US Dollar / Japanese Yen', 'forex', 3),
  ('USD/CHF', 'US Dollar / Swiss Franc', 'forex', 5),
  ('AUD/USD', 'Australian Dollar / US Dollar', 'forex', 5),
  ('USD/CAD', 'US Dollar / Canadian Dollar', 'forex', 5),
  ('NZD/USD', 'New Zealand Dollar / US Dollar', 'forex', 5),
  ('EUR/GBP', 'Euro / British Pound', 'forex', 5),
  ('EUR/JPY', 'Euro / Japanese Yen', 'forex', 3),
  ('GBP/JPY', 'British Pound / Japanese Yen', 'forex', 3),
  ('EUR/CHF', 'Euro / Swiss Franc', 'forex', 5),
  ('AUD/JPY', 'Australian Dollar / Japanese Yen', 'forex', 3),
  ('NZD/JPY', 'New Zealand Dollar / Japanese Yen', 'forex', 3),
  ('EUR/AUD', 'Euro / Australian Dollar', 'forex', 5),
  ('GBP/AUD', 'British Pound / Australian Dollar', 'forex', 5),
  ('EUR/CAD', 'Euro / Canadian Dollar', 'forex', 5),
  ('GBP/CHF', 'British Pound / Swiss Franc', 'forex', 5),
  ('USD/SGD', 'US Dollar / Singapore Dollar', 'forex', 5),
  ('USD/HKD', 'US Dollar / Hong Kong Dollar', 'forex', 4),
  ('USD/MXN', 'US Dollar / Mexican Peso', 'forex', 4),
  ('USD/ZAR', 'US Dollar / South African Rand', 'forex', 4),
  ('USD/TRY', 'US Dollar / Turkish Lira', 'forex', 4),
  ('XAU/USD', 'Gold Spot', 'commodities', 2),
  ('XAG/USD', 'Silver Spot', 'commodities', 3),
  ('XPT/USD', 'Platinum Spot', 'commodities', 2),
  ('XPD/USD', 'Palladium Spot', 'commodities', 2),
  ('COPPER', 'Copper Futures', 'commodities', 3),
  ('WTI', 'WTI Crude Oil', 'commodities', 2),
  ('BRENT', 'Brent Crude Oil', 'commodities', 2),
  ('NATGAS', 'Natural Gas', 'commodities', 3),
  ('NASDAQ', 'Nasdaq 100', 'indices', 1),
  ('S&P 500', 'S&P 500', 'indices', 1),
  ('DOW JONES', 'Dow Jones Industrial Average', 'indices', 0),
  ('RUSSELL 2000', 'Russell 2000', 'indices', 1),
  ('FTSE 100', 'FTSE 100 (UK)', 'indices', 1),
  ('DAX', 'DAX 40 (Germany)', 'indices', 1),
  ('CAC 40', 'CAC 40 (France)', 'indices', 1),
  ('NIKKEI 225', 'Nikkei 225 (Japan)', 'indices', 0),
  ('HANG SENG', 'Hang Seng (Hong Kong)', 'indices', 0),
  ('ASX 200', 'S&P/ASX 200 (Australia)', 'indices', 1),
  ('BTC/USD', 'Bitcoin', 'crypto', 0),
  ('ETH/USD', 'Ethereum', 'crypto', 1),
  ('SOL/USD', 'Solana', 'crypto', 2),
  ('BNB/USD', 'BNB', 'crypto', 1),
  ('XRP/USD', 'XRP', 'crypto', 4),
  ('ADA/USD', 'Cardano', 'crypto', 4),
  ('DOGE/USD', 'Dogecoin', 'crypto', 4),
  ('AVAX/USD', 'Avalanche', 'crypto', 2),
  ('DOT/USD', 'Polkadot', 'crypto', 3),
  ('LINK/USD', 'Chainlink', 'crypto', 2),
  ('LTC/USD', 'Litecoin', 'crypto', 2),
  ('MATIC/USD', 'Polygon', 'crypto', 4),
  ('TON/USD', 'Toncoin', 'crypto', 3),
  ('UNI/USD', 'Uniswap', 'crypto', 2),
  ('ATOM/USD', 'Cosmos', 'crypto', 3),
  ('TRX/USD', 'TRON', 'crypto', 4),
  ('SHIB/USD', 'Shiba Inu', 'crypto', 8);
